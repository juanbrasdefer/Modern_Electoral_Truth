/*  FILE nes04run.sps                                                    */
/*  -----------------                                                    */ 
/*  2004 American National Election Study (2004.T)                       */
/*  SPSS run file                                                        */
/*  VERSION 20050816 (Aug 16, 2005)                                      */



/*  This 'run' file can be used to read into SPSS the raw ASCII data     */
/*  file for the 2004 NES Release file.                                  */

/*  If you have downloaded and decompressed the 2004 NES                 */
/*  'zip' file into a directory such as C:\ANES\nes2004\20050816, you    */
/*  should be able to run this file without modification to produce an   */
/*  SPSS system file.                                                    */

/*  Running this file should successfully create an SPSS system file     */
/*  named "nes2004.sav" in directory "C:\ANES\nes2004\20050816\".        */

/*  File 'nes04dat' is the raw data file used by readdata.               */
/*  File 'readdata' reads in the raw data as column input.               */
/*  File 'varlab' assigns variable labels.                               */
/*  File 'codlab'  assigns code labels from the formats to data values.  */
/*  File 'missval'  assigns missing data value assignments.              */

/* NOTE: missing data assignments  are commented out but can be restored */
/* by removing the asterisk (*) on the relevant line in the run setup    */
/* below.                                                                */


file handle nes04dat /name="C:\anes\nes2004\20050816\nes04dat.txt" LRECL=3347.
file handle readdata /name="C:\anes\nes2004\20050816\nes04col.sps".
file handle varlab   /name="C:\anes\nes2004\20050816\nes04lab.sps".
file handle codelab  /name="C:\anes\nes2004\20050816\nes04cod.sps".
file handle missval  /name="C:\anes\nes2004\20050816\nes04md.sps".

include file=readdata.
include file=varlab.
include file=codelab. 
*include file=missval.
save outfile="c:\anes\nes2004\20050816\nes2004.sav".



