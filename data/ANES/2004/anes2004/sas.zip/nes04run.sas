/*  FILE nes04run.sas                                                    */
/*  -----------------                                                    */ 
/*  2004 American National Election Study (2004.T)                       */
/*  SAS run file                                                         */
/*  VERSION 20050816 (Aug 16, 2005)                                      */


/*  This 'run' file can be used to read into SAS the raw ASCII data      */
/*  file for the 2004 NES Release file.                                  */

/*  If you have downloaded and decompressed the 2004 NES                 */
/*  'zip' file into a directory such as C:\ANES\nes2004\20050816, you    */
/*  should be able to run this file without modification to produce a    */
/*  SAS system file.                                                     */

/*  Running this file should successfully create a SAS system file       */
/*  named "nes2004" (with file name extension appropriate to the version */
/*  which you are running) in directory "C:\ANES\nes2004\20050816\".     */
/*  Libname 'nes2004' defines the location where the SAS dataset will    */
/*  be written.  Both libname and dataset are set to the recommended     */
/*  directory.                                                           */

/*  File 'formats' creates code labels to be used for the data values.   */
/*  File 'nes04dat' is the raw data file used by readdata.               */
/*  File 'readdata' reads in the raw data as column input.               */
/*  File 'varlab' assigns variable labels.                               */
/*  File 'codlab'  assigns code labels from the formats to data values.  */
/*  File 'missval'  assigns missing data value assignments.              */

/* NOTE: missing data assignments are commented out but can be restored  */
/* by removing the asterisk (*) on the relevant line below.              */
/* Format definitions and assignments are also commented out but can     */
/* be restored by removing the asterisk (*) on the formats and codelab   */
/* lines.                                                                */

libname LIBRARY "C:\anes\nes2004\20050816";
libname NES2004 "C:\anes\nes2004\20050816";
run;

filename formats  "C:\anes\nes2004\20050816\nes04fmt.sas";
filename dat2004  "C:\anes\nes2004\20050816\nes04dat.txt";
filename readdata "C:\anes\nes2004\20050816\nes04col.sas";
filename varlab   "C:\anes\nes2004\20050816\nes04lab.sas";
filename codelab  "C:\anes\nes2004\20050816\nes04cod.sas";
filename missval  "C:\anes\nes2004\20050816\nes04md.sas";

* %include formats  ;
%include readdata ;
%include varlab   ;
* %include codelab  ; 
* %include missval  ; 

run;


