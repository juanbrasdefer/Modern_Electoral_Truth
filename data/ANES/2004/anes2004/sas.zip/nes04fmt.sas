Proc Format Library=library;
VALUE V041001f  (MAX=60)
  0 = "0. Pre-election interview only"
  1 = "1. Both Pre-election and Post-election interviews"
;
VALUE V041101f  (MAX=60)
  1 = "1. One person in HH"
  2 = "2. Two persons in HH"
  3 = "3. Three persons in HH"
  4 = "4. Four persons in HH"
  5 = "5. Five persons in HH"
  6 = "6. Six persons in HH"
  7 = "7. Seven persons in HH"
  8 = "8. Eight persons in HH"
  9 = "9. Nine persons in HH"
;
VALUE V041102f  (MAX=60)
  1 = "1. One adult in HH"
  2 = "2. Two adults in HH"
  3 = "3. Three adults in HH"
  4 = "4. Four adults in HH"
  5 = "5. Five adults in HH"
  6 = "6. Six adults in HH"
;
VALUE V041102a  (MAX=60)
  1 = "1. One eligible adult in HH"
  2 = "2. Two eligible adults in HH"
  3 = "3. Three eligible adults in HH"
  4 = "4. Four eligible adults in HH"
  5 = "5. Five eligible adults in HH"
  6 = "6. Six eligible adults in HH"
;
VALUE V041102b  (MAX=60)
  0 = "0. No ineligible adult in HH"
  1 = "1. One ineligible adult in HH"
  2 = "2. Two ineligible adults in HH"
  3 = "3. Three ineligible adults in HH"
  4 = "4. Four ineligible adults in HH"
;
VALUE V041102c  (MAX=60)
  0 = "0. No female adult in HH"
  1 = "1. One female adult in HH"
  2 = "2. Two female adults in HH"
  3 = "3. Three female adults in HH"
  4 = "4. Four female adults in HH"
;
VALUE V041103f  (MAX=60)
  0 = "0. No children in HH"
  1 = "1. One child in HH"
  2 = "2. Two children in HH"
  3 = "3. Three children in HH"
  4 = "4. Four children in HH"
  5 = "5. Five children in HH"
  6 = "6. Six children in HH"
  7 = "7. Seven children in HH"
;
VALUE V041104f  (MAX=60)
  0 = "0. No female children in HH"
  1 = "1. One female child in HH"
  2 = "2. Two female children in HH"
  3 = "3. Three female children in HH"
  4 = "4. Four female children in HH"
  5 = "5. Five female children in HH"
  6 = "6. Six female children in HH"
  7 = "7. Seven female children in HH"
;
VALUE V041105f  (MAX=60)
  0 = "0. No child in HH under 5 years old"
  1 = "1. One child in HH under 5 years old"
  2 = "2. Two children in HH under 5 years old"
  3 = "3. Three children in HH under 5 years old"
;
VALUE V041106f  (MAX=60)
  0 = "0. No child in HH age 5-9"
  1 = "1. One child in HH age 5-9"
  2 = "2. Two children in HH age 5-9"
  3 = "3. Three children in HH age 5-9"
;
VALUE V041107f  (MAX=60)
  0 = "0. No child in HH age 10-13"
  1 = "1. One child in HH age 10-13"
  2 = "2. Two children in HH age 10-13"
  3 = "3. Three children in HH age 10-13"
  4 = "4. Four children in HH age 10-13"
;
VALUE V041108f  (MAX=60)
  0 = "0. No child in HH age 14-17"
  1 = "1. One child in HH age 14-17"
  2 = "2. Two children in HH age 14-17"
  3 = "3. Three children in HH age 14-17"
;
VALUE V041109f  (MAX=60)
  1 = "1. R is person number 1 (1st person in HH listing)"
  2 = "2. R is person number 2 (2nd person in HH listing)"
  3 = "3. R is person number 3 (3rd person in HH listing)"
  4 = "4. R is person number 4 (4th person in HH listing)"
  5 = "5. R is person number 5 (5th person in HH listing)"
  6 = "6. R is person number 6 (6th person in HH listing)"
  7 = "7. R is person number 7 (7th person in HH listing)"
  8 = "8. R is person number 8 (8th person in HH listing)"
;
VALUE V041109a  (MAX=60)
  1 = "1. Male"
  2 = "2. Female"
;
VALUE V041109b  (MAX=60)
  1  = "01. Self"
  2  = "02. Wife/female partner"
  3  = "03. Husband/male partner"
  4  = "04. Mother"
  5  = "05. Father"
  6  = "06. Sister"
  7  = "07. Brother"
  8  = "08. Daughter"
  9  = "09. Son"
  10 = "10. Grandmother"
  11 = "11. Grandfather"
  12 = "12. Roommate"
  13 = "13. Niece"
  14 = "14. Nephew"
  15 = "15. Aunt"
  16 = "16. Uncle"
  17 = "17. Granddaughter"
  18 = "18. Grandson"
  19 = "19. Mother-in-law/mother of partner"
  20 = "20. Father-in-law/father of partner"
  21 = "21. Daughter-in-law"
  22 = "22. Son-in-law"
  23 = "23. Sister-in-law"
  24 = "24. Brother-in-law"
  25 = "25. Live-in careperson"
  26 = "26. Other {SPECIFY}"
;
VALUE V041109c  (MAX=60)
  0 = "0. No child in HH is (step)son/daughter of R"
  1 = "1. 1 child in HH is (step)son/daughter of R"
  2 = "2. 2 children in HH are (step)sons/daughters of R"
  3 = "3. 3 children in HH are (step)sons/daughters of R"
  4 = "4. 4 children in HH are (step)sons/daughters of R"
  5 = "5. 5 children in HH are (step)sons/daughters of R"
  6 = "6. 6 children in HH are (step)sons/daughters of R"
;
VALUE V041109d  (MAX=60)
  0 = "0. No child in HH is (step)daughter of R"
  1 = "1. 1 child in HH is (step)daughter of R"
  2 = "2. 2 children in HH are (step)daughters of R"
  3 = "3. 3 children in HH are (step)daughters of R"
  4 = "4. 4 children in HH are (step)daughters of R"
  5 = "5. 5 children in HH are (step)daughters of R"
  6 = "6. 6 children in HH are (step)daughters of R"
;
VALUE V041110f  (MAX=60)
  10 = "10. 1 adult male HHR"
  11 = "11. 1 adult male HHR plus 1 adult non-relative"
  12 = "12. 1 adult male HHR plus 2 or more adult non-relatives"
  20 = "20. 1 adult female HHR"
  21 = "21. 1 adult female HHR plus 1 adult non-relative"
  22 = "22. 1 adult female HHR plus 2 or more adult non-relatives"
  30 = "30. 1 married couple: no children or all children living at"
  40 = "40. 1 married couple plus 1 other adult relative"
  50 = "50. 1 married couple plus 2 or more other adult relatives"
  51 = "51. 1 married couple plus 1 adult non-relative"
  52 = "52. 1 married couple plus 2 or more adult non-relatives"
  55 = "55. 1 married couple plus relative(s) and non-relative(s)"
  60 = "60. 1 adult male HHR plus 1 adult relative"
  70 = "70. 1 adult male HHR plus 2 or more adult relatives"
  75 = "75. 1 adult male HHR plus relative(s) and non-relative(s)"
  80 = "80. 1 adult female HHR plus 1 adult relative"
  90 = "90. 1 adult female HHR plus 2 or more relatives"
  95 = "95. 1 adult female HHR plus relative(s) and non-relative(s)"
;
VALUE V041111b  (MAX=60)
  1 = "1. Male"
  5 = "5. Female"
  0 = "0. NA"
;
VALUE V041111a  (MAX=60)
  00 = "00. NA"
;
VALUE V041112b  (MAX=60)
  1 = "1. Male"
  5 = "5. Female"
  0 = "0. NA"
;
VALUE V041112a  (MAX=60)
  00 = "00. NA"
;
VALUE V041113b  (MAX=60)
  1 = "1. Male"
  5 = "5. Female"
  0 = "0. NA"
;
VALUE V041113a  (MAX=60)
  00 = "00. NA"
;
VALUE V041114b  (MAX=60)
  1 = "1. Male"
  5 = "5. Female"
  0 = "0. NA"
;
VALUE V041114a  (MAX=60)
  00 = "00. NA"
;
VALUE V041115b  (MAX=60)
  1 = "1. Male"
  5 = "5. Female"
  0 = "0. NA"
;
VALUE V041115a  (MAX=60)
  00 = "00. NA"
;
VALUE V041116b  (MAX=60)
  1 = "1. Male"
  5 = "5. Female"
  0 = "0. NA"
;
VALUE V041116a  (MAX=60)
  00 = "00. NA"
;
VALUE V041202f  (MAX=60)
  01 = "01. Alabama"
  02 = "02. Alaska"
  04 = "04. Arizona"
  05 = "05. Arkansas"
  06 = "06. California"
  08 = "08. Colorado"
  09 = "09. Connecticut"
  10 = "10. Delaware"
  11 = "11. Washington DC"
  12 = "12. Florida"
  13 = "13. Georgia"
  15 = "15. Hawaii"
  16 = "16. Idaho"
  17 = "17. Illinois"
  18 = "18. Indiana"
  19 = "19. Iowa"
  20 = "20. Kansas"
  21 = "21. Kentucky"
  22 = "22. Louisiana"
  23 = "23. Maine"
  24 = "24. Maryland"
  25 = "25. Massachusetts"
  26 = "26. Michigan"
  27 = "27. Minnesota"
  28 = "28. Mississippi"
  29 = "29. Missouri"
  30 = "30. Montana"
  31 = "31. Nebraska"
  32 = "32. Nevada"
  33 = "33. New Hampshire"
  34 = "34. New Jersey"
  35 = "35. New Mexico"
  36 = "36. New York"
  37 = "37. North Carolina"
  38 = "38. North Dakota"
  39 = "39. Ohio"
  40 = "40. Oklahoma"
  41 = "41. Oregon"
  42 = "42. Pennsylvania"
  44 = "44. Rhode Island"
  45 = "45. South Carolina"
  46 = "46. South Dakota"
  47 = "47. Tennessee"
  48 = "48. Texas"
  49 = "49. Utah"
  50 = "50. Vermont"
  51 = "51. Virginia"
  53 = "53. Washington"
  54 = "54. West Virginia"
  55 = "55. Wisconsin"
  56 = "56. Wyoming"
;
VALUE V041203f  (MAX=60)
  01 = "01. Connecticut"
  02 = "02. Maine"
  03 = "03. Massachusetts"
  04 = "04. New Hampshire"
  05 = "05. Rhode Island"
  06 = "06. Vermont"
  11 = "11. Delaware"
  12 = "12. New Jersey"
  13 = "13. New York"
  14 = "14. Pennsylvania"
  21 = "21. Illinois"
  22 = "22. Indiana"
  23 = "23. Michigan"
  24 = "24. Ohio"
  25 = "25. Wisconsin"
  31 = "31. Iowa"
  32 = "32. Kansas"
  33 = "33. Minnesota"
  34 = "34. Missouri"
  35 = "35. Nebraska"
  36 = "36. North Dakota"
  37 = "37. South Dakota"
  40 = "40. Virginia"
  41 = "41. Alabama"
  42 = "42. Arkansas"
  43 = "43. Florida"
  44 = "44. Georgia"
  45 = "45. Louisiana"
  46 = "46. Mississippi"
  47 = "47. North Carolina"
  48 = "48. South Carolina"
  49 = "49. Texas"
  51 = "51. Kentucky"
  52 = "52. Maryland"
  53 = "53. Oklahoma"
  54 = "54. Tennessee"
  55 = "55. Washington DC"
  56 = "56. West Virginia"
  61 = "61. Arizona"
  62 = "62. Colorado"
  63 = "63. Idaho"
  64 = "64. Montana"
  65 = "65. Nevada"
  66 = "66. New Mexico"
  67 = "67. Utah"
  68 = "68. Wyoming"
  71 = "71. California"
  72 = "72. Oregon"
  73 = "73. Washington"
  81 = "81. Alaska"
  82 = "82. Hawaii"
;
VALUE V041205f (MAX=60)
  1 = "1. Northeast (CT,ME,MA,NH,NJ,NY,PA,RI,VT)"
  2 = "2. North Central (IL,IN,IA,KS,MI,MN,MO,NE,ND,OH,SD,WI)"
  3 = "3. South (AL,AR,DE,DC,FL,GA,KY,LA,MD,MS,NC,OK,SC,TN,TX,VA,WV"
  4 = "4. West (AK,AZ,CA,CO,HI,ID,MT,NM,NV,OR,UT,WA,WY)"
;
VALUE V041213f (MAX=60)
  1 = "1. Rural"
  5 = "5. Urban"
;
VALUE V042001f (MAX=60)
  1 = "1. A10 Pre and Pre patriotism module"
  2 = "2. A11 Pre and Pre patriotism module"
  3 = "3. A10 Pre and Post patriotism module"
  4 = "4. A11 Pre and Post patriotism module"
;
VALUE V042002f (MAX=60)
  09 = "09. September"
  10 = "10. October"
  11 = "11. November"
  00 = "00. NA"
;
VALUE V042003f (MAX=60)
  00 = "00. NA"
;
VALUE V042005f (MAX=60)
  1 = "1. September 2, 2004 version"
  2 = "2. September 8, 2004 version"
  3 = "3. September 16, 2004 version"
  4 = "4. September 29, 2004 version"
  0 = "0. NA"
;
VALUE V042006f (MAX=60)
  09 = "09. September"
  10 = "10. October"
  11 = "11. November"
  00 = "00. NA"
;
VALUE V042007f (MAX=60)
  00 = "00. NA"
;
VALUE V042009f (MAX=60)
  1 = "1. September 2, 2004 version"
  2 = "2. September 8, 2004 version"
  3 = "3. September 16, 2004 version"
  4 = "4. September 29, 2004 version"
  0 = "0. NA"
;
VALUE V042010a (MAX=60)
  0 = "0. NA"
;
VALUE V042010b (MAX=60)
  0 = "0. NA"
;
VALUE V042011f (MAX=60)
  1 = "1. IW conducted in 1 session"
  2 = "2. IW conducted in 2 sessions"
  3 = "3. IW conducted in 3 sessions"
  4 = "4. IW conducted in 4 sessions"
  0 = "0. NA"
;
VALUE V042012f (MAX=60)
  0 = "0. Pre IW conducted using a single version of the instrument"
  1 = "1. Pre IW conducted using more than a single version"
  9 = "9. NA"
;
VALUE V042013f (MAX=60)
  1 = "1. One interviewer conducted the entire interview"
  2 = "2. Two interviewers conducted the interview"
  0 = "0. NA"
;
VALUE V042015a (MAX=60)
  1 = "1. September 2, 2004 version"
  2 = "2. September 8, 2004 version"
  3 = "3. September 16, 2004 version"
  4 = "4. September 29, 2004 version"
  0 = "0. NA"
;
VALUE V042015b (MAX=60)
  1 = "1. September 2, 2004 version"
  2 = "2. September 8, 2004 version"
  3 = "3. September 16, 2004 version"
  4 = "4. September 29, 2004 version"
;
VALUE V042015c (MAX=60)
  1 = "1. September 2, 2004 version"
  2 = "2. September 8, 2004 version"
  3 = "3. September 16, 2004 version"
  4 = "4. September 29, 2004 version"
;
VALUE V042015d (MAX=60)
  1 = "1. September 2, 2004 version"
  2 = "2. September 8, 2004 version"
  3 = "3. September 16, 2004 version"
  4 = "4. September 29, 2004 version"
;
VALUE V042016a (MAX=60)
  00 = "00. Interview completed in 1 session"
  01 = "01. Media module (A1-A9)"
  02 = "02. Country on right track A10"
  03 = "03. Congressional approval (A13-A13a)"
  04 = "04. Thermometer series (B1-B1q)"
  05 = "05. Party likes-dislikes (C1-C2d5)"
  06 = "06. R finance questions (C4-C9)"
  07 = "07. Presidential candidate affects (D1-D2d1)"
  08 = "08. Liberal-conservative placements (E1-E6)"
  09 = "09. Who will win presidency (E7-E9a)"
  10 = "10. Economy question (F1-F6)"
  11 = "11. Interventionism questions (F7-F7a1)"
  12 = "12. Party handling of issues (G1-G3)"
  13 = "13. U.S. position and involvement in world (H1-H2)"
  14 = "14. Party ID (J1-J1b)"
  15 = "15. Presidential candidate traits (K1-K2h)"
  16 = "16. Iraq/Afghanistan questions (M1-M4)"
  17 = "17. Spending-services scales (N1-N1e)"
  18 = "18. Govt health insurance scale (N4-N4a1)"
  19 = "19. Guaranteed jobs-standard of living scales (N5-N5e)"
  20 = "20. Federal spending series (P1-P1m)"
  21 = "21. Tax level questions (P2a-P2a2)"
  22 = "22. Late abortion questions (P2c-P2c1)"
  23 = "23. Environment-jobs scale (P3-P3a1)"
  24 = "24. Demographics (W1-end of IW)"
;
VALUE V042016b (MAX=60)
  01 = "01. Media module (A1-A9)"
  02 = "02. Country on right track A10"
  03 = "03. Congressional approval (A13-A13a)"
  04 = "04. Thermometer series (B1-B1q)"
  05 = "05. Party likes-dislikes (C1-C2d5)"
  06 = "06. R finance questions (C4-C9)"
  07 = "07. Presidential candidate affects (D1-D2d1)"
  08 = "08. Liberal-conservative placements (E1-E6)"
  09 = "09. Who will win presidency (E7-E9a)"
  10 = "10. Economy question (F1-F6)"
  11 = "11. Interventionism questions (F7-F7a1)"
  12 = "12. Party handling of issues (G1-G3)"
  13 = "13. U.S. position and involvement in world (H1-H2)"
  14 = "14. Party ID (J1-J1b)"
  15 = "15. Presidential candidate traits (K1-K2h)"
  16 = "16. Iraq/Afghanistan questions (M1-M4)"
  17 = "17. Spending-services scales (N1-N1e)"
  18 = "18. Govt health insurance scale (N4-N4a1)"
  19 = "19. Guaranteed jobs-standard of living scales (N5-N5e)"
  20 = "20. Federal spending series (P1-P1m)"
  21 = "21. Tax level questions (P2a-P2a2)"
  22 = "22. Late abortion questions (P2c-P2c1)"
  23 = "23. Environment-jobs scale (P3-P3a1)"
  24 = "24. Demographics (W1-end of IW)"
;
VALUE V042016c (MAX=60)
  01 = "01. Media module (A1-A9)"
  02 = "02. Country on right track A10"
  03 = "03. Congressional approval (A13-A13a)"
  04 = "04. Thermometer series (B1-B1q)"
  05 = "05. Party likes-dislikes (C1-C2d5)"
  06 = "06. R finance questions (C4-C9)"
  07 = "07. Presidential candidate affects (D1-D2d1)"
  08 = "08. Liberal-conservative placements (E1-E6)"
  09 = "09. Who will win presidency (E7-E9a)"
  10 = "10. Economy question (F1-F6)"
  11 = "11. Interventionism questions (F7-F7a1)"
  12 = "12. Party handling of issues (G1-G3)"
  13 = "13. U.S. position and involvement in world (H1-H2)"
  14 = "14. Party ID (J1-J1b)"
  15 = "15. Presidential candidate traits (K1-K2h)"
  16 = "16. Iraq/Afghanistan questions (M1-M4)"
  17 = "17. Spending-services scales (N1-N1e)"
  18 = "18. Govt health insurance scale (N4-N4a1)"
  19 = "19. Guaranteed jobs-standard of living scales (N5-N5e)"
  20 = "20. Federal spending series (P1-P1m)"
  21 = "21. Tax level questions (P2a-P2a2)"
  22 = "22. Late abortion questions (P2c-P2c1)"
  23 = "23. Environment-jobs scale (P3-P3a1)"
  24 = "24. Demographics (W1-end of IW)"
;
VALUE V042020f (MAX=60)
  0 = "00. NA"
;
VALUE V042021f (MAX=60)
  0 = "0. Not a refusal conversion situation"
  1 = "1. Refusal conversion"
;
VALUE V042022f (MAX=60)
  1 = "1. All cases released at start of interviewing period"
;
VALUE V042023f (MAX=60)
  1 = "1. All interviews conducted face-to-face"
;
VALUE V042024f (MAX=60)
  1 = "1. Completed interview"
;
VALUE V042025f (MAX=60)
  000 = "000.00 NA"
;
VALUE V042026f (MAX=60)
  1 = "1. All interviews were conducted in English"
;
VALUE V042027f (MAX=60)
  0 = "0. Not selected for verification"
  2 = "2. Verified, no inconsistencies"
  3 = "3. Verified with discrepancies"
  4 = "4. Failed verification"
  5 = "5. Unable to verify (unable to contact respondent)"
  6 = "6. Verification limit met (used when the case if flagged for"
;
VALUE V042028f (MAX=60)
  0 = "0. Not flagged for evaluation"
  1 = "1. Flagged for evaluation; not evaluated"
  2 = "2. Evaluated"
;
VALUE V042029f (MAX=60)
  1 = "1. Yes, tape-recorded"
  5 = "5. No"
;
VALUE V042030f (MAX=60)
  20 = "20. $20"
  50 = "50. $50"
;
VALUE V042031f (MAX=60)
  00 = "00. Respondent refused payment"
  20 = "20. $20"
  50 = "50. $50"
  99 = "99. NA"
;
VALUE V042033f (MAX=60)
  1 = "1. All respondents paid by check"
;
VALUE V042034f (MAX=60)
  1 = "1. All respondents received $5 cash and a magnet"
;
VALUE V042035f (MAX=60)
  0 = "0. Persuasion letters not documented"
;
VALUE V042036a  (MAX=60)
  0 = "0. Positive comment not coded at any call"
  1 = "1. Positive comment coded for at least one call"
  9 = "9. NA"
;
VALUE V042036b  (MAX=60)
  0 = "0. Time-delay comment not coded at any call"
  1 = "1. Time-delay comment coded for at least one call"
  9 = "9. NA"
;
VALUE V042036c  (MAX=60)
  0 = "0. Negative comment not coded at any call"
  1 = "1. Negative comment coded for at least one call"
  9 = "9. NA"
;
VALUE V042036d  (MAX=60)
  0 = "0. Eligibility comment not coded at any call"
  1 = "1. Eligibility comment coded for at least one call"
  9 = "9. NA"
;
VALUE V042036e  (MAX=60)
  0 = "0. Privacy comment not coded at any call"
  1 = "1. Privacy comment coded for at least one call"
  9 = "9. NA"
;
VALUE V042036f  (MAX=60)
  0 = "0. Political disinterest comment not coded at any call"
  1 = "1. Political disinterest comment coded for at least one call"
  9 = "9. NA"
;
VALUE V042037a  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037b  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037c  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037d  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037e  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037f  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037g  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037h  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037j  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037k  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037m  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037n  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037p  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037q  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037r  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037s  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037t  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037u  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037v  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037w  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042037y  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042038f (MAX=60)
  0 = "0. Respondent did not initially refuse"
  1 = "1. Respondent initial refusal"
;
VALUE V042039f (MAX=60)
  0 = "0. Informant did not initially refuse"
  1 = "1. Informant initial refusal"
;
VALUE V042040f  (MAX=60)
  1 = "1. Mobile home"
  2 = "2. Detached single family"
  3 = "3. Multi-family"
  4 = "4. Apartment house"
  5 = "5. Condo complex"
  7 = "7. Other {SPECIFY}"
  0 = "0. NA"
;
VALUE V042041f  (MAX=60)
  1 = "1. Single family home"
  2 = "2. Structure with 2 to 9 units"
  3 = "3. Structure with 10 to 49 units"
  4 = "4. Structure with 50 or more units"
  7 = "7. Other {SPECIFY}"
  0 = "0. NA"
;
VALUE V042042f  (MAX=60)
  1 = "1. Entirely residential"
  2 = "2. Primarily residential with some commercial or other"
  3 = "3. Primarily commercial or other non-residential"
  0 = "0. NA"
;
VALUE V042043f  (MAX=60)
  1 = "1. Rural area"
  2 = "2. Small town"
  3 = "3. Suburb"
  4 = "4. Large city"
  5 = "5. Inner city"
  0 = "0. NA"
;
VALUE V042044f  (MAX=60)
  1 = "1. Yes {SPECIFY}"
  5 = "5. No"
  0 = "0. NA"
;
VALUE V042044a  (MAX=60)
  1 = "1. Democratic Presidential candidate"
  2 = "2. Republican Presidential candidate"
  3 = "3. Congressional candidate"
  4 = "4. Candidate for governor"
  5 = "5. 1 or more local candidates"
  7 = "7. Other non-presidential candidate, NA what level"
  0 = "0. NA"
;
VALUE V042044b  (MAX=60)
  1 = "1. Democratic Presidential candidate"
  2 = "2. Republican Presidential candidate"
  3 = "3. Congressional candidate"
  4 = "4. Candidate for governor"
  5 = "5. 1 or more local candidates"
  7 = "7. Other non-presidential candidate, NA what level"
;
VALUE V042045x  (MAX=60)
  0 = "0. None of the specified impediments coded at any call and"
  1 = "1. 1 or more specified impediments coded"
  9 = "9. NA"
;
VALUE V042045a  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042045b  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042045c  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042045d  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042046x  (MAX=60)
  0 = "0. None of the specified security measures coded at any call"
  1 = "1. 1 or more specified impediments coded"
  9 = "9. NA"
;
VALUE V042046a  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042046b  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042046c  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042046d  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042046e  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
  0 = "0. NA"
;
VALUE V042047f  (MAX=60)
  1 = "1. Yes"
  2 = "2. No, but building is locked/subdivision is gated and locke"
  5 = "5. No"
  0 = "0. NA"
;
VALUE V042047a  (MAX=60)
  1 = "1. Building manager or other gatekeeper must let you in the"
  2 = "2. Building manager or other gatekeeper must get permission"
  7 = "7. Other {SPECIFY}"
  0 = "0. NA"
;
VALUE V042048a  (MAX=60)
  0 = "0. Gatekeeper noted at neither PreAdmin.45c nor PreAdmin.47"
  1 = "1. Gatekeeper noted at PreAdmin.45c but not at PreAdmin.47"
  2 = "2. Gatekeeper noted at PreAdmin.47 but not at PreAdmin.45c"
  3 = "3. Gatekeeper noted at both PreAdmin.45c and PreAdmin.47"
  9 = "9. NA in both PreAdmin.45c and PreAdmin.47"
;
VALUE V042048b  (MAX=60)
  0 = "0. Locked status noted at neither PreAdmin.45b nor PreAdmin."
  1 = "1. Locked status noted at PreAdmin.45b but not at PreAdmin."
  2 = "2. Locked status noted at PreAdmin.47 but not at PreAdmin.45"
  3 = "3. Locked status noted at both PreAdmin.45b and PreAdmin.47"
  9 = "9. NA in both PreAdmin.45b and PreAdmin.47"
;
VALUE V042201f (MAX=60)
  0 = "0. No error in Pre application"
  1 = "1. Error in E8 (skipped E8a)"
  2 = "2. Error in E9 (skipped E9a)"
  3 = "3. Error in E8 and E9 (skipped E8a and E9a)"
;
VALUE V042202f (MAX=60)
  0 = "0. No error; F3-F6 not skipped"
  1 = "1. Error; F3-F6 skipped"
;
VALUE V042401f (MAX=60)
  1 = "1. President Bush likes-dislikes administered first (A3-A4)"
  2 = "2. John Kerry likes-dislikes administered first (A5-A6)"
;
VALUE V042402f (MAX=60)
  1 = "1. John Kerry thermometer administered first (B1b)"
  2 = "2. Ralph Nader thermometer administered first (B1c)"
;
VALUE V042403a (MAX=60)
  1 = "1. Administered as 1st name"
  2 = "2. Administered as 2nd name"
  3 = "3. Administered as 3rd name"
  4 = "4. Administered as 4th name"
  5 = "5. Administered as 5th name"
  6 = "6. Administered as 6th name"
  7 = "7. Administered as 7th name"
  8 = "8. Administered as 8th name"
;
VALUE V042403b (MAX=60)
  1 = "1. Administered as 1st name"
  2 = "2. Administered as 2nd name"
  3 = "3. Administered as 3rd name"
  4 = "4. Administered as 4th name"
  5 = "5. Administered as 5th name"
  6 = "6. Administered as 6th name"
  7 = "7. Administered as 7th name"
  8 = "8. Administered as 8th name"
;
VALUE V042403c (MAX=60)
  1 = "1. Administered as 1st name"
  2 = "2. Administered as 2nd name"
  3 = "3. Administered as 3rd name"
  4 = "4. Administered as 4th name"
  5 = "5. Administered as 5th name"
  6 = "6. Administered as 6th name"
  7 = "7. Administered as 7th name"
  8 = "8. Administered as 8th name"
;
VALUE V042403d (MAX=60)
  1 = "1. Administered as 1st name"
  2 = "2. Administered as 2nd name"
  3 = "3. Administered as 3rd name"
  4 = "4. Administered as 4th name"
  5 = "5. Administered as 5th name"
  6 = "6. Administered as 6th name"
  7 = "7. Administered as 7th name"
  8 = "8. Administered as 8th name"
;
VALUE V042403e (MAX=60)
  1 = "1. Administered as 1st name"
  2 = "2. Administered as 2nd name"
  3 = "3. Administered as 3rd name"
  4 = "4. Administered as 4th name"
  5 = "5. Administered as 5th name"
  6 = "6. Administered as 6th name"
  7 = "7. Administered as 7th name"
  8 = "8. Administered as 8th name"
;
VALUE V042403f (MAX=60)
  1 = "1. Administered as 1st name"
  2 = "2. Administered as 2nd name"
  3 = "3. Administered as 3rd name"
  4 = "4. Administered as 4th name"
  5 = "5. Administered as 5th name"
  6 = "6. Administered as 6th name"
  7 = "7. Administered as 7th name"
  8 = "8. Administered as 8th name"
;
VALUE V042403g (MAX=60)
  1 = "1. Administered as 1st name"
  2 = "2. Administered as 2nd name"
  3 = "3. Administered as 3rd name"
  4 = "4. Administered as 4th name"
  5 = "5. Administered as 5th name"
  6 = "6. Administered as 6th name"
  7 = "7. Administered as 7th name"
  8 = "8. Administered as 8th name"
;
VALUE V042403h (MAX=60)
  1 = "1. Administered as 1st name"
  2 = "2. Administered as 2nd name"
  3 = "3. Administered as 3rd name"
  4 = "4. Administered as 4th name"
  5 = "5. Administered as 5th name"
  6 = "6. Administered as 6th name"
  7 = "7. Administered as 7th name"
  8 = "8. Administered as 8th name"
;
VALUE V042404f (MAX=60)
  1 = "1. Democratic party thermometer administered first (B1n)"
  2 = "2. Republican party thermometer administered first (B1p)"
;
VALUE V042405f (MAX=60)
  1 = "1. Democratic party likes-dislikes administered first (C1)"
  2 = "2. Republican party likes-dislikes administered first (C2)"
;
VALUE V042406f (MAX=60)
  1 = "1. President Bush affects administered first (D1 series)"
  2 = "2. John Kerry affects administered first (D2 series)"
;
VALUE V042407a (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
;
VALUE V042407b (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
;
VALUE V042407c (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
;
VALUE V042407d (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
;
VALUE V042408a (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
;
VALUE V042408b (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
;
VALUE V042408c (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
;
VALUE V042408d (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
;
VALUE V042409f (MAX=60)
  1 = "1. John Kerry placement administered first (K3)"
  2 = "2. Ralph Nader placement administered first (K4)"
;
VALUE V042410f (MAX=60)
  1 = "1. Democratic party placement administered first (E5)"
  2 = "2. Republican party placement administered first (E6)"
;
VALUE V042411f (MAX=60)
  1 = "1. Unemployment questions F3-F4 administered first"
  2 = "2. Inflation questions F5-F6 administered first"
;
VALUE V042412f (MAX=60)
  1 = "1. Democratic party first in question text"
  2 = "2. Republican party first in question text"
;
VALUE V042413f (MAX=60)
  1 = "1. President Bush traits administered first (K1 series)"
  2 = "2. John Kerry traits administered first (K2 series)"
;
VALUE V042414a (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
;
VALUE V042414b (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
;
VALUE V042414c (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
;
VALUE V042414d (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
;
VALUE V042414e (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
;
VALUE V042414f (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
;
VALUE V042414g (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
;
VALUE V042415a (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
;
VALUE V042415b (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
;
VALUE V042415c (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
;
VALUE V042415d (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
;
VALUE V042415e (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
;
VALUE V042415f (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
;
VALUE V042415g (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
;
VALUE V042416f (MAX=60)
  1 = "1. George Bush placement administered first (N1b)"
  2 = "2. John Kerry placement administered first (N1c)"
;
VALUE V042417f (MAX=60)
  1 = "1. Democratic party placement administered first (N1d)"
  2 = "2. Republican party placement administered first (N1e)"
;
VALUE V042418f (MAX=60)
  1 = "1. George Bush placement administered first N2b)"
  2 = "2. John Kerry placement administered first (N2c)"
;
VALUE V042419f (MAX=60)
  1 = "1. Democratic party placement administered first (N2d)"
  2 = "2. Republican party placement administered first (N2e)"
;
VALUE V042420f (MAX=60)
  1 = "1. George Bush placement administered first (N5b)"
  2 = "2. John Kerry placement administered first (N5c)"
;
VALUE V042421f (MAX=60)
  1 = "1. Democratic party placement administered first (N5d)"
  2 = "2. Republican party placement administered first (N5e)"
;
VALUE V042422f (MAX=60)
  1 = "1. George Bush placement administered first (N6b)"
  2 = "2. John Kerry placement administered first (N6c)"
;
VALUE V042423f (MAX=60)
  1 = "1. Democratic party placement administered first (N6d)"
  2 = "2. Republican party placement administered first (N6e)"
;
VALUE V042424a (MAX=60)
  01 = "01. Administered 1st"
  02 = "02. Administered 2nd"
  03 = "03. Administered 3rd"
  04 = "04. Administered 4th"
  05 = "05. Administered 5th"
  06 = "06. Administered 6th"
  07 = "07. Administered 7th"
  08 = "08. Administered 8th"
  09 = "09. Administered 9th"
  10 = "10. Administered 10th"
;
VALUE V042424b (MAX=60)
  01 = "01. Administered 1st"
  02 = "02. Administered 2nd"
  03 = "03. Administered 3rd"
  04 = "04. Administered 4th"
  05 = "05. Administered 5th"
  06 = "06. Administered 6th"
  07 = "07. Administered 7th"
  08 = "08. Administered 8th"
  09 = "09. Administered 9th"
  10 = "10. Administered 10th"
;
VALUE V042424c (MAX=60)
  01 = "01. Administered 1st"
  02 = "02. Administered 2nd"
  03 = "03. Administered 3rd"
  04 = "04. Administered 4th"
  05 = "05. Administered 5th"
  06 = "06. Administered 6th"
  07 = "07. Administered 7th"
  08 = "08. Administered 8th"
  09 = "09. Administered 9th"
  10 = "10. Administered 10th"
;
VALUE V042424d (MAX=60)
  01 = "01. Administered 1st"
  02 = "02. Administered 2nd"
  03 = "03. Administered 3rd"
  04 = "04. Administered 4th"
  05 = "05. Administered 5th"
  06 = "06. Administered 6th"
  07 = "07. Administered 7th"
  08 = "08. Administered 8th"
  09 = "09. Administered 9th"
  10 = "10. Administered 10th"
;
VALUE V042424e (MAX=60)
  01 = "01. Administered 1st"
  02 = "02. Administered 2nd"
  03 = "03. Administered 3rd"
  04 = "04. Administered 4th"
  05 = "05. Administered 5th"
  06 = "06. Administered 6th"
  07 = "07. Administered 7th"
  08 = "08. Administered 8th"
  09 = "09. Administered 9th"
  10 = "10. Administered 10th"
;
VALUE V042424f (MAX=60)
  01 = "01. Administered 1st"
  02 = "02. Administered 2nd"
  03 = "03. Administered 3rd"
  04 = "04. Administered 4th"
  05 = "05. Administered 5th"
  06 = "06. Administered 6th"
  07 = "07. Administered 7th"
  08 = "08. Administered 8th"
  09 = "09. Administered 9th"
  10 = "10. Administered 10th"
;
VALUE V042424g (MAX=60)
  01 = "01. Administered 1st"
  02 = "02. Administered 2nd"
  03 = "03. Administered 3rd"
  04 = "04. Administered 4th"
  05 = "05. Administered 5th"
  06 = "06. Administered 6th"
  07 = "07. Administered 7th"
  08 = "08. Administered 8th"
  09 = "09. Administered 9th"
  10 = "10. Administered 10th"
;
VALUE V042424h (MAX=60)
  01 = "01. Administered 1st"
  02 = "02. Administered 2nd"
  03 = "03. Administered 3rd"
  04 = "04. Administered 4th"
  05 = "05. Administered 5th"
  06 = "06. Administered 6th"
  07 = "07. Administered 7th"
  08 = "08. Administered 8th"
  09 = "09. Administered 9th"
  10 = "10. Administered 10th"
;
VALUE V042424j (MAX=60)
  01 = "01. Administered 1st"
  02 = "02. Administered 2nd"
  03 = "03. Administered 3rd"
  04 = "04. Administered 4th"
  05 = "05. Administered 5th"
  06 = "06. Administered 6th"
  07 = "07. Administered 7th"
  08 = "08. Administered 8th"
  09 = "09. Administered 9th"
  10 = "10. Administered 10th"
;
VALUE V042424k (MAX=60)
  01 = "01. Administered 1st"
  02 = "02. Administered 2nd"
  03 = "03. Administered 3rd"
  04 = "04. Administered 4th"
  05 = "05. Administered 5th"
  06 = "06. Administered 6th"
  07 = "07. Administered 7th"
  08 = "08. Administered 8th"
  09 = "09. Administered 9th"
  10 = "10. Administered 10th"
;
VALUE V042425f (MAX=60)
  1 = "1. George Bush placement administered first (P3b)"
  2 = "2. John Kerry placement administered first (P3c)"
;
VALUE V042426f (MAX=60)
  1 = "1. George Bush placement administered first (P5b)"
  2 = "2. John Kerry placement administered first (P5c)"
;
VALUE V042427f (MAX=60)
  1 = "1. George Bush placement administered first (P6b)"
  2 = "2. John Kerry placement administered first (P6c)"
;
VALUE V042428f (MAX=60)
  1 = "1. Democratic party placement administered first (P6d)"
  2 = "2. Republican party placement administered first (P6e)"
;
VALUE V043001f  (MAX=60)
  1 = "1. Very much interested"
  3 = "3. Somewhat interested"
  5 = "5. Not much interested"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043002f  (MAX=60)
  1 = "1. Yes, voted"
  5 = "5. No, didn't vote"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043003f  (MAX=60)
  1 = "1. Al Gore"
  3 = "3. George W. Bush"
  5 = "5. Pat Buchanan"
  6 = "6. Ralph Nader"
  7 = "7. Other (SPECIFY)"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043004f  (MAX=60)
  1 = "1. Fair"
  5 = "5. Unfair"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043005f  (MAX=60)
  1 = "1. Fair - strongly"
  2 = "2. Fair - not strongly"
  4 = "4. Unfair - not strongly"
  5 = "5. Unfair - strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043006f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043007f  (MAX=60)
  0 = "0. No mentions (5,8 in A3a; 8880,8888,8889 in A3b1)"
  1 = "1. One mention"
  2 = "2. Two mentions"
  3 = "3. Three mentions"
  4 = "4. Four mentions"
  5 = "5. Five mentions"
  9 = "9. RF (9 in A3a)"
;
VALUE V043007a  (MAX=60)
  8877 = "8877. Other miscellaneous"
  8880 = "8880. No text; 'none'; 'no'; other uncodeable"
  8888 = "8888. DK"
  8889 = "8889. RF"
;
VALUE V043008f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't Know"
  9 = "9. Refused"
;
VALUE V043009f  (MAX=60)
  0 = "0. No mentions (5,8 in A4a; 8880,8888,8889 in A4b1)"
  1 = "1. One mention"
  2 = "2. Two mentions"
  3 = "3. Three mentions"
  4 = "4. Four mentions"
  5 = "5. Five mentions"
  9 = "9. RF (9 in A4a)"
;
VALUE V043009a  (MAX=60)
  8877 = "8877. Other miscellaneous"
  8880 = "8880. No text; 'none'; 'no'; other uncodeable"
  8888 = "8888. DK"
  8889 = "8889. RF"
;
VALUE V043010f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043011f  (MAX=60)
  0 = "0. No mentions (5,8 in A5a; 8880,8888,8889 in A5b1)"
  1 = "1. One mention"
  2 = "2. Two mentions"
  3 = "3. Three mentions"
  4 = "4. Four mentions"
  5 = "5. Five mentions"
  9 = "9. RF (9 in A5a)"
;
VALUE V043011a  (MAX=60)
  8877 = "8877. Other miscellaneous"
  8880 = "8880. No text; 'none'; 'no'; other uncodeable"
  8888 = "8888. DK"
  8889 = "8889. RF"
;
VALUE V043012f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043013f  (MAX=60)
  0 = "0. No mentions (5,8 in A6a; 8880,8888,8889 in A6b1)"
  1 = "1. One mention"
  2 = "2. Two mentions"
  3 = "3. Three mentions"
  4 = "4. Four mentions"
  5 = "5. Five mentions"
  9 = "9. RF (9 in A6a)"
;
VALUE V043013a  (MAX=60)
  8877 = "8877. Other miscellaneous"
  8880 = "8880. No text; 'none'; 'no'; other uncodeable"
  8888 = "8888. DK"
  8889 = "8889. RF"
;
VALUE V043014f  (MAX=60)
  0 = "0. None"
  1 = "1. One day"
  2 = "2. Two days"
  3 = "3. Three days"
  4 = "4. Four days"
  5 = "5. Five days"
  6 = "6. Six days"
  7 = "7. Every day"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043015f  (MAX=60)
  1 = "1. A great deal"
  2 = "2. Quite a bit"
  3 = "3. Some"
  4 = "4. Very little"
  5 = "5. None"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043016f  (MAX=60)
  0 = "0. None"
  1 = "1. One day"
  2 = "2. Two days"
  3 = "3. Three days"
  4 = "4. Four days"
  5 = "5. Five days"
  6 = "6. Six days"
  7 = "7. Every day"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043017f  (MAX=60)
  0 = "0. None"
  1 = "1. One day"
  2 = "2. Two days"
  3 = "3. Three days"
  4 = "4. Four days"
  5 = "5. Five days"
  6 = "6. Six days"
  7 = "7. Every day"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043018f  (MAX=60)
  1 = "1. A great deal"
  2 = "2. Quite a bit"
  3 = "3. Some"
  4 = "4. Very little"
  5 = "5. None"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043019f  (MAX=60)
  0 = "0. None"
  1 = "1. One day"
  2 = "2. Two days"
  3 = "3. Three days"
  4 = "4. Four days"
  5 = "5. Five days"
  6 = "6. Six days"
  7 = "7. Every day"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043020f  (MAX=60)
  0 = "0. None"
  1 = "1. One day"
  2 = "2. Two days"
  3 = "3. Three days"
  4 = "4. Four days"
  5 = "5. Five days"
  6 = "6. Six days"
  7 = "7. Every day"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043021f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043022f  (MAX=60)
  1 = "1. A great deal"
  2 = "2. Quite a bit"
  3 = "3. Some"
  4 = "4. Very little"
  5 = "5. None"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043023f  (MAX=60)
  1 = "1. Right direction"
  5 = "5. Wrong track"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043024f  (MAX=60)
  1 = "1. Approve"
  5 = "5. Disapprove"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043025f  (MAX=60)
  1 = "1. Approve strongly"
  2 = "2. Approve not strongly"
  4 = "4. Disapprove not strongly"
  5 = "5. Disapprove strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043026f  (MAX=60)
  1 = "1. Approve"
  5 = "5. Disapprove"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043027f  (MAX=60)
  1 = "1. Approve strongly"
  2 = "2. Approve not strongly"
  4 = "4. Disapprove not strongly"
  5 = "5. Disapprove strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043028f  (MAX=60)
  1 = "1. Approve"
  5 = "5. Disapprove"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043029f  (MAX=60)
  1 = "1. Approve strongly"
  2 = "2. Approve not strongly"
  4 = "4. Disapprove not strongly"
  5 = "5. Disapprove strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043030f  (MAX=60)
  1 = "1. Approve"
  5 = "5. Disapprove"
  8 = "8. DK"
  9 = "9. RF"
;
VALUE V043031f  (MAX=60)
  1 = "1. Approve strongly"
  2 = "2. Approve not strongly"
  4 = "4. Disapprove not strongly"
  5 = "5. Disapprove strongly"
  8 = "8. DK"
  9 = "9. RF"
;
VALUE V043032f  (MAX=60)
  1 = "1. Approve"
  5 = "5. Disapprove"
  8 = "8. DK"
  9 = "9. RF"
;
VALUE V043033f  (MAX=60)
  1 = "1. Approve strongly"
  2 = "2. Approve not strongly"
  4 = "4. Disapprove not strongly"
  5 = "5. Disapprove strongly"
  8 = "8. DK"
  9 = "9. RF"
;
VALUE V043034f  (MAX=60)
  1 = "1. Right direction"
  5 = "5. Wrong track"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043034x  (MAX=60)
  1 = "1. Right direction"
  5 = "5. Wrong track"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043035f  (MAX=60)
  1 = "1. Very much"
  2 = "2. Pretty much"
  3 = "3. Not very much"
  4 = "4. Not at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043036f  (MAX=60)
  1 = "1. Approve"
  5 = "5. Disapprove"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043037f  (MAX=60)
  1 = "1. Approve strongly"
  2 = "2. Approve not strongly"
  4 = "4. Disapprove not strongly"
  5 = "5. Disapprove strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043038f  (MAX=60)
  777 = "777. Don't recognize"
  888 = "888. Don't know where to rate"
  889 = "889. Refused"
;
VALUE V043039f  (MAX=60)
  777 = "777. Don't recognize"
  888 = "888. Don't know where to rate"
  889 = "889. Refused"
;
VALUE V043040f  (MAX=60)
  777 = "777. Don't recognize"
  888 = "888. Don't know where to rate"
  889 = "889. Refused"
;
VALUE V043041f  (MAX=60)
  777 = "777. Don't recognize"
  888 = "888. Don't know where to rate"
  889 = "889. Refused"
;
VALUE V043042f  (MAX=60)
  777 = "777. Don't recognize"
  888 = "888. Don't know where to rate"
  889 = "889. Refused"
;
VALUE V043043f  (MAX=60)
  777 = "777. Don't recognize"
  888 = "888. Don't know where to rate"
  889 = "889. Refused"
;
VALUE V043044f  (MAX=60)
  777 = "777. Don't recognize"
  888 = "888. Don't know where to rate"
  889 = "889. Refused"
;
VALUE V043045f  (MAX=60)
  777 = "777. Don't recognize"
  888 = "888. Don't know where to rate"
  889 = "889. Refused"
;
VALUE V043046f  (MAX=60)
  777 = "777. Don't recognize"
  888 = "888. Don't know where to rate"
  889 = "889. Refused"
;
VALUE V043047f  (MAX=60)
  777 = "777. Don't recognize"
  888 = "888. Don't know where to rate"
  889 = "889. Refused"
;
VALUE V043048f  (MAX=60)
  777 = "777. Don't recognize"
  888 = "888. Don't know where to rate"
  889 = "889. Refused"
;
VALUE V043049f  (MAX=60)
  777 = "777. Don't recognize"
  888 = "888. Don't know where to rate"
  889 = "889. Refused"
;
VALUE V043050f  (MAX=60)
  777 = "777. Don't recognize"
  888 = "888. Don't know where to rate"
  889 = "889. Refused"
;
VALUE V043051f  (MAX=60)
  777 = "777. Don't recognize"
  888 = "888. Don't know where to rate"
  889 = "889. Refused"
;
VALUE V043052f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043053f  (MAX=60)
  0 = "0. No mentions (5,8 in C1a; 8880,8888,8889 in C1b1)"
  1 = "1. One mention"
  2 = "2. Two mentions"
  3 = "3. Three mentions"
  4 = "4. Four mentions"
  5 = "5. Five mentions"
  9 = "9. RF (9 in C1a)"
;
VALUE V043053a  (MAX=60)
  8877 = "8877. Other miscellaneous"
  8880 = "8880. No text; 'none'; 'no'; other uncodeable"
  8888 = "8888. DK"
  8889 = "8889. RF"
;
VALUE V043054f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043055f  (MAX=60)
  0 = "0. No mentions (5,8 in C1c; 8880,8888,8889 in C1d1)"
  1 = "1. One mention"
  2 = "2. Two mentions"
  3 = "3. Three mentions"
  4 = "4. Four mentions"
  5 = "5. Five mentions"
  9 = "9. RF (9 in C1c)"
;
VALUE V043055a  (MAX=60)
  8877 = "8877. Other miscellaneous"
  8880 = "8880. No text; 'none'; 'no'; other uncodeable"
  8888 = "8888. DK"
  8889 = "8889. RF"
;
VALUE V043056f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043057f  (MAX=60)
  0 = "0. No mentions (5,8 in C2a; 8880,8888,8889 in C2b1)"
  1 = "1. One mention"
  2 = "2. Two mentions"
  3 = "3. Three mentions"
  4 = "4. Four mentions"
  5 = "5. Five mentions"
  9 = "9. RF (9 in C2a)"
;
VALUE V043057a  (MAX=60)
  8877 = "8877. Other miscellaneous"
  8880 = "8880. No text; 'none'; 'no'; other uncodeable"
  8888 = "8888. DK"
  8889 = "8889. RF"
;
VALUE V043058f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043059f  (MAX=60)
  0 = "0. No mentions (5,8 in C2c; 8880,8888,8889 in C2d1)"
  1 = "1. One mention"
  2 = "2. Two mentions"
  3 = "3. Three mentions"
  4 = "4. Four mentions"
  5 = "5. Five mentions"
  9 = "9. RF (9 in C2c)"
;
VALUE V043059a  (MAX=60)
  8877 = "8877. Other miscellaneous"
  8880 = "8880. No text; 'none'; 'no'; other uncodeable"
  8888 = "8888. DK"
  8889 = "8889. RF"
;
VALUE V043060f  (MAX=60)
  1 = "1. Better when one party controls both"
  3 = "3. Better when control is split"
  5 = "5. It doesn't matter"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043061f  (MAX=60)
  1 = "1. Better"
  3 = "3. Worse"
  5 = "5. The same [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043062f  (MAX=60)
  1 = "1. Much better"
  2 = "2. Somewhat better"
  3 = "3. Same (5 in C4)"
  4 = "4. Somewhat worse"
  5 = "5. Much worse"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043063f  (MAX=60)
  1 = "1. Better"
  3 = "3. Worse"
  5 = "5. The same"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043064f  (MAX=60)
  1 = "1. Much better"
  2 = "2. Somewhat better"
  3 = "3. Same (5 in C5)"
  4 = "4. Somewhat worse"
  5 = "5. Much worse"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043065f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043066f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043067f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043068f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043069f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043070f  (MAX=60)
  1 = "1. Very often"
  2 = "2. Fairly often"
  3 = "3. Occasionally"
  4 = "4. Rarely"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043071f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043072f  (MAX=60)
  1 = "1. Very often"
  2 = "2. Fairly often"
  3 = "3. Occasionally"
  4 = "4. Rarely"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043073f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043074f  (MAX=60)
  1 = "1. Very often"
  2 = "2. Fairly often"
  3 = "3. Occasionally"
  4 = "4. Rarely"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043075f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043076f  (MAX=60)
  1 = "1. Very often"
  2 = "2. Fairly often"
  3 = "3. Occasionally"
  4 = "4. Rarely"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043077f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043078f  (MAX=60)
  1 = "1. Very often"
  2 = "2. Fairly often"
  3 = "3. Occasionally"
  4 = "4. Rarely"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043079f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043080f  (MAX=60)
  1 = "1. Very often"
  2 = "2. Fairly often"
  3 = "3. Occasionally"
  4 = "4. Rarely"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043081f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043082f  (MAX=60)
  1 = "1. Very often"
  2 = "2. Fairly often"
  3 = "3. Occasionally"
  4 = "4. Rarely"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043083f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043084f  (MAX=60)
  1 = "1. Very often"
  2 = "2. Fairly often"
  3 = "3. Occasionally"
  4 = "4. Rarely"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043085f  (MAX=60)
  01 = "01. Extremely liberal"
  02 = "02. Liberal"
  03 = "03. Slightly liberal"
  04 = "04. Moderate; middle of the road"
  05 = "05. Slightly conservative"
  06 = "06. Conservative"
  07 = "07. Extremely conservative"
  80 = "80. Haven't thought much [DO NOT PROBE]"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043085a  (MAX=60)
  1 = "1. Liberal"
  3 = "3. Conservative"
  5 = "5. Moderate [VOL]"
  8 = "8. Don't know"
  9 = "9. RF"
;
VALUE V043086f  (MAX=60)
  1 = "1. Liberal"
  3 = "3. Moderate"
  5 = "5. Conservative"
  7 = "7. Refused to choose"
  8 = "8. Don't know"
;
VALUE V043087f  (MAX=60)
  1 = "1. Extremely liberal"
  2 = "2. Liberal"
  3 = "3. Slightly liberal"
  4 = "4. Moderate; middle of the road"
  5 = "5. Slightly conservative"
  6 = "6. Conservative"
  7 = "7. Extremely conservative"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043088f  (MAX=60)
  1 = "1. Extremely liberal"
  2 = "2. Liberal"
  3 = "3. Slightly liberal"
  4 = "4. Moderate; middle of the road"
  5 = "5. Slightly conservative"
  6 = "6. Conservative"
  7 = "7. Extremely conservative"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043089f  (MAX=60)
  1 = "1. Extremely liberal"
  2 = "2. Liberal"
  3 = "3. Slightly liberal"
  4 = "4. Moderate; middle of the road"
  5 = "5. Slightly conservative"
  6 = "6. Conservative"
  7 = "7. Extremely conservative"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043090f  (MAX=60)
  1 = "1. Extremely liberal"
  2 = "2. Liberal"
  3 = "3. Slightly liberal"
  4 = "4. Moderate; middle of the road"
  5 = "5. Slightly conservative"
  6 = "6. Conservative"
  7 = "7. Extremely conservative"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043091f  (MAX=60)
  1 = "1. Extremely liberal"
  2 = "2. Liberal"
  3 = "3. Slightly liberal"
  4 = "4. Moderate; middle of the road"
  5 = "5. Slightly conservative"
  6 = "6. Conservative"
  7 = "7. Extremely conservative"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043092f  (MAX=60)
  1 = "1. Care a good deal"
  3 = "3. Don't care very much"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043093f  (MAX=60)
  1 = "1. John Kerry"
  3 = "3. George W. Bush"
  5 = "5. Ralph Nader"
  7 = "7. Other (SPECIFY) [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043094f  (MAX=60)
  00 = "00. Will be close - DK winner"
  11 = "11. Will be close - Kerry will win"
  12 = "12. Will be close - Bush will win"
  13 = "13. Will be close - Nader will win"
  14 = "14. Will be close - other candidate will win"
  25 = "25. Win by quite a bit - Kerry"
  26 = "26. Win by quite a bit - Bush"
  27 = "27. Win by quite a bit - Nader"
  28 = "28. Win by quite a bit - other candidate"
  29 = "29. Win by quite a bit - DK who"
  88 = "88. Don't know"
  89 = "89. Refused"
  99 = "99. NA"
;
VALUE V043095f  (MAX=60)
  1 = "1. John Kerry"
  3 = "3. George W. Bush"
  5 = "5. Ralph Nader"
  7 = "7. Other (SPECIFY) [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043096f  (MAX=60)
  00 = "00. Will be close - DK winner"
  11 = "11. Will be close - Kerry will win"
  12 = "12. Will be close - Bush will win"
  13 = "13. Will be close - Nader will win"
  14 = "14. Will be close - other candidate will win"
  25 = "25. Win by quite a bit - Kerry"
  26 = "26. Win by quite a bit - Bush"
  27 = "27. Win by quite a bit - Nader"
  28 = "28. Win by quite a bit - other candidate"
  29 = "29. Win by quite a bit - DK who"
  88 = "88. Don't know"
  89 = "89. Refused"
  99 = "99. NA"
;
VALUE V043097f  (MAX=60)
  1 = "1. Gotten better"
  3 = "3. Stayed about the same"
  5 = "5. Gotten worse"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043098f  (MAX=60)
  1 = "1. Much better"
  2 = "2. Somewhat better"
  3 = "3. Same (3 in F1)"
  4 = "4. Somewhat worse"
  5 = "5. Much worse"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043099f  (MAX=60)
  1 = "1. Get better"
  3 = "3. Stay about the same"
  5 = "5. Get worse"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043100f  (MAX=60)
  1 = "1. Much better"
  2 = "2. Somewhat better"
  3 = "3. Same (3 in F2)"
  4 = "4. Somewhat worse"
  5 = "5. Much worse"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043101f  (MAX=60)
  1 = "1. Better"
  3 = "3. Stayed same"
  5 = "5. Worse"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043102f  (MAX=60)
  1 = "1. Much better"
  2 = "2. Somewhat better"
  3 = "3. Same (3 in F3)"
  4 = "4. Somewhat worse"
  5 = "5. Much worse"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043103f  (MAX=60)
  1 = "1. More unemployment"
  3 = "3. About the same"
  5 = "5. Less unemployment"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043104f  (MAX=60)
  1 = "1. Better"
  3 = "3. Stayed same"
  5 = "5. Worse"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043105f  (MAX=60)
  1 = "1. Much better"
  2 = "2. Somewhat better"
  3 = "3. Same (3 in F5)"
  4 = "4. Somewhat worse"
  5 = "5. Much worse"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043106f  (MAX=60)
  1 = "1. Higher inflation"
  3 = "3. About the same"
  5 = "5. Lower inflation"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043107f  (MAX=60)
  01 = "01. U.S. should solve with diplomacy and international press"
  07 = "07. U.S. must be ready to use military force"
  80 = "80. Haven't thought much about this"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043108f  (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not too important"
  5 = "5. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043109f  (MAX=60)
  1 = "1. Democrats"
  3 = "3. Republicans"
  5 = "5. Wouldn't be much difference between them/no difference"
  7 = "7. Neither party [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043110f  (MAX=60)
  1 = "1. Democrats"
  3 = "3. Republicans"
  5 = "5. About the same by both"
  7 = "7. Neither party [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043111f  (MAX=60)
  1 = "1. Democrats"
  3 = "3. Republicans"
  5 = "5. About the same by both"
  7 = "7. Neither party [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043112f  (MAX=60)
  1 = "1. Weaker"
  3 = "3. Stayed about the same"
  5 = "5. Stronger"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043113f  (MAX=60)
  1 = "1. Agree"
  5 = "5. Disagree"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043114f  (MAX=60)
  1 = "1. Republican"
  2 = "2. Democrat"
  3 = "3. Independent"
  4 = "4. Other party (SPECIFY)"
  5 = "5. No preference"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043114a  (MAX=60)
  1 = "1. Strong"
  5 = "5. Not very strong"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043115f  (MAX=60)
  1 = "1. Closer to Republican"
  3 = "3. Neither [VOL]"
  5 = "5. Closer to Democratic"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043116f  (MAX=60)
  0 = "0. Strong Democrat (2/1/.)"
  1 = "1. Weak Democrat (2/5-8-9/.)"
  2 = "2. Independent-Democrat (3-4-5/./5)"
  3 = "3. Independent-Independent"
  4 = "4. Independent-Republican (3-4-5/./1)"
  5 = "5. Weak Republican (1/5-8-9/.)"
  6 = "6. Strong Republican (1/1/.)"
  7 = "7. Other; minor party; refuses to say"
  8 = "8. Apolitical (5/./3-8-9 if apolitical)"
  9 = "9. DK (8/./.)"
;
VALUE V043117f  (MAX=60)
  1 = "1. Extremely well"
  2 = "2. Quite well"
  3 = "3. Not too well"
  4 = "4. Not well at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043118f  (MAX=60)
  1 = "1. Extremely well"
  2 = "2. Quite well"
  3 = "3. Not too well"
  4 = "4. Not well at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043119f  (MAX=60)
  1 = "1. Extremely well"
  2 = "2. Quite well"
  3 = "3. Not too well"
  4 = "4. Not well at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043120f  (MAX=60)
  1 = "1. Extremely well"
  2 = "2. Quite well"
  3 = "3. Not too well"
  4 = "4. Not well at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043121f  (MAX=60)
  1 = "1. Extremely well"
  2 = "2. Quite well"
  3 = "3. Not too well"
  4 = "4. Not well at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043122f  (MAX=60)
  1 = "1. Extremely well"
  2 = "2. Quite well"
  3 = "3. Not too well"
  4 = "4. Not well at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043123f  (MAX=60)
  1 = "1. Extremely well"
  2 = "2. Quite well"
  3 = "3. Not too well"
  4 = "4. Not well at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043124f  (MAX=60)
  1 = "1. Extremely well"
  2 = "2. Quite well"
  3 = "3. Not too well"
  4 = "4. Not well at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043125f  (MAX=60)
  1 = "1. Extremely well"
  2 = "2. Quite well"
  3 = "3. Not too well"
  4 = "4. Not well at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043126f  (MAX=60)
  1 = "1. Extremely well"
  2 = "2. Quite well"
  3 = "3. Not too well"
  4 = "4. Not well at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043127f  (MAX=60)
  1 = "1. Extremely well"
  2 = "2. Quite well"
  3 = "3. Not too well"
  4 = "4. Not well at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043128f  (MAX=60)
  1 = "1. Extremely well"
  2 = "2. Quite well"
  3 = "3. Not too well"
  4 = "4. Not well at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043129f  (MAX=60)
  1 = "1. Extremely well"
  2 = "2. Quite well"
  3 = "3. Not too well"
  4 = "4. Not well at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043130f  (MAX=60)
  1 = "1. Extremely well"
  2 = "2. Quite well"
  3 = "3. Not too well"
  4 = "4. Not well at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043131f  (MAX=60)
  1 = "1. Worth it"
  5 = "5. Not worth it"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043132f  (MAX=60)
  1 = "1. Approve"
  5 = "5. Disapprove"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043133f  (MAX=60)
  1 = "1. Approve strongly"
  2 = "2. Approve not strongly"
  4 = "4. Disapprove not strongly"
  5 = "5. Disapprove strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043134f  (MAX=60)
  1 = "1. Worth it"
  5 = "5. Not worth it"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043135f  (MAX=60)
  1 = "1. Increased"
  3 = "3. Decreased"
  5 = "5. Stayed about the same"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043136f  (MAX=60)
  01 = "01. Govt should provide many fewer services"
  07 = "07. Govt should provide many more services"
  80 = "80. Haven't thought much about this"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043137f  (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not too important"
  5 = "5. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043138f  (MAX=60)
  1 = "1. Govt should provide many fewer services"
  7 = "7. Govt should provide many more services"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043139f  (MAX=60)
  1 = "1. Govt should provide many fewer services"
  7 = "7. Govt should provide many more services"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043140f  (MAX=60)
  1 = "1. Govt should provide many fewer services"
  7 = "7. Govt should provide many more services"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043141f  (MAX=60)
  1 = "1. Govt should provide many fewer services"
  7 = "7. Govt should provide many more services"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043142f  (MAX=60)
  01 = "01. Govt should decrease defense spending"
  07 = "07. Govt should increase defense spending"
  80 = "80. Haven't thought much about this"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043143f  (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not too important"
  5 = "5. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043144f  (MAX=60)
  1 = "1. Govt should decrease defense spending"
  7 = "7. Govt should increase defense spending"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043145f  (MAX=60)
  1 = "1. Govt should decrease defense spending"
  7 = "7. Govt should increase defense spending"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043146f  (MAX=60)
  1 = "1. Govt should decrease defense spending"
  7 = "7. Govt should increase defense spending"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043147f  (MAX=60)
  1 = "1. Govt should decrease defense spending"
  7 = "7. Govt should increase defense spending"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043148f  (MAX=60)
  1 = "1. Favor"
  3 = "3. Oppose"
  5 = "5. Other/neither/depends {SPECIFY}"
  7 = "7. Haven't thought about"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043149f  (MAX=60)
  1 = "1. Favored strongly"
  2 = "2. Favored not strongly"
  4 = "4. Opposed not strongly"
  5 = "5. Opposed strongly"
  7 = "7. Other/neither/depends (5 in N3)"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. Haven't thought about it (7 in N3)"
;
VALUE V043150f  (MAX=60)
  01 = "01. Govt insurance plan"
  07 = "07. Private insurance plan"
  80 = "80. Haven't thought much"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043151f  (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not too important"
  5 = "5. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043152f  (MAX=60)
  01 = "01. Govt should see to jobs and standard of living"
  07 = "07. Govt should let each person get ahead on own"
  80 = "80. Haven't thought much about this"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043153f  (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not too important"
  5 = "5. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043154f  (MAX=60)
  1 = "1. Govt should see to jobs and standard of living"
  7 = "7. Govt should let each person get ahead on own"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043155f  (MAX=60)
  1 = "1. Govt should see to jobs and standard of living"
  7 = "7. Govt should let each person get ahead on own"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043156f  (MAX=60)
  1 = "1. Govt should see to jobs and standard of living"
  7 = "7. Govt should let each person get ahead on own"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043157f  (MAX=60)
  1 = "1. Govt should see to jobs and standard of living"
  7 = "7. Govt should let each person get ahead on own"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043158f  (MAX=60)
  01 = "01. Govt should help blacks"
  07 = "07. Blacks should help themselves"
  80 = "80. Haven't thought much about this"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043159f  (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not too important"
  5 = "5. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043160f  (MAX=60)
  1 = "1. Govt should help blacks"
  7 = "7. Blacks should help themselves"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043161f  (MAX=60)
  1 = "1. Govt should help blacks"
  7 = "7. Blacks should help themselves"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043162f  (MAX=60)
  1 = "1. Govt should help blacks"
  7 = "7. Blacks should help themselves"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043163f  (MAX=60)
  1 = "1. Govt should help blacks"
  7 = "7. Blacks should help themselves"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043164f  (MAX=60)
  1 = "1. Increased"
  3 = "3. Decreased"
  5 = "5. Kept about the same"
  7 = "7. Cut out entirely [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043165f  (MAX=60)
  1 = "1. Increased"
  3 = "3. Decreased"
  5 = "5. Kept about the same"
  7 = "7. Cut out entirely [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043166f  (MAX=60)
  1 = "1. Increased"
  3 = "3. Decreased"
  5 = "5. Kept about the same"
  7 = "7. Cut out entirely [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043167f  (MAX=60)
  1 = "1. Increased"
  3 = "3. Decreased"
  5 = "5. Kept about the same"
  7 = "7. Cut out entirely [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043168f  (MAX=60)
  1 = "1. Increased"
  3 = "3. Decreased"
  5 = "5. Kept about the same"
  7 = "7. Cut out entirely [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043169f  (MAX=60)
  1 = "1. Increased"
  3 = "3. Decreased"
  5 = "5. Kept about the same"
  7 = "7. Cut out entirely [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043170f  (MAX=60)
  1 = "1. Increased"
  3 = "3. Decreased"
  5 = "5. Kept about the same"
  7 = "7. Cut out entirely [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043171f  (MAX=60)
  1 = "1. Increased"
  3 = "3. Decreased"
  5 = "5. Kept about the same"
  7 = "7. Cut out entirely [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043172f  (MAX=60)
  1 = "1. Increased"
  3 = "3. Decreased"
  5 = "5. Kept about the same"
  7 = "7. Cut out entirely [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043173f  (MAX=60)
  1 = "1. Increased"
  3 = "3. Decreased"
  5 = "5. Kept about the same"
  7 = "7. Cut out entirely [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043174f  (MAX=60)
  1 = "1. Increased"
  3 = "3. Decreased"
  5 = "5. Kept about the same"
  7 = "7. Cut out entirely [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043175f  (MAX=60)
  1 = "1. More than should pay"
  3 = "3. About right"
  5 = "5. Less than should pay"
  7 = "7. Don't pay at all {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043176f  (MAX=60)
  1 = "1. More than should pay"
  3 = "3. About right"
  5 = "5. Less than should pay"
  7 = "7. Don't pay at all {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043177f  (MAX=60)
  1 = "1. More than should pay"
  3 = "3. About right"
  5 = "5. Less than should pay"
  7 = "7. Don't pay at all {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043178f  (MAX=60)
  1. = "1. Favor"
  5. = "5. Oppose"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043179f  (MAX=60)
  1 = "1. Favor strongly"
  2 = "2. Favor not strongly"
  4 = "4. Oppose not strongly"
  5 = "5. Oppose strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043180f  (MAX=60)
  1 = "1. Favor"
  5 = "5. Oppose"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043181f  (MAX=60)
  1 = "1. Favor strongly"
  2 = "2. Favor not strongly"
  4 = "4. Oppose not strongly"
  5 = "5. Oppose strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043182f  (MAX=60)
  01 = "01. Protect environment, even if it costs jobs"
  07 = "07. Jobs & standard of living more important"
  80 = "80. Haven't thought much about this"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043183f  (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not too important"
  5 = "5. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043184f  (MAX=60)
  1 = "1. Protect environment, even if it costs jobs"
  7 = "7. Jobs & standard of living more important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043185f  (MAX=60)
  1 = "1. Protect environment, even if it costs jobs"
  7 = "7. Jobs & standard of living more important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043186f  (MAX=60)
  1 = "1. Favor"
  5 = "5. Oppose"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043187f  (MAX=60)
  1 = "1. Favor strongly"
  2 = "2. Favor not strongly"
  4 = "4. Oppose not strongly"
  5 = "5. Oppose strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043188f  (MAX=60)
  1 = "1. More difficult"
  3 = "3. Make it easier"
  5 = "5. Keep these rules about the same"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043189f  (MAX=60)
  1 = "1. A lot more difficult"
  2 = "2. Somewhat more difficult"
  3 = "3. About the same (5 in P5a)"
  4 = "4. Somewhat easier"
  5 = "5. A lot easier"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043190f  (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not too important"
  5 = "5. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043191f  (MAX=60)
  1 = "1. More difficult"
  3 = "3. Make it easier"
  5 = "5. Keep these rules about the same"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043192f  (MAX=60)
  1 = "1. A lot more difficult"
  2 = "2. Somewhat more difficult"
  3 = "3. About the same (5 in P5b)"
  4 = "4. Somewhat easier"
  5 = "5. A lot easier"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043193f  (MAX=60)
  1 = "1. More difficult"
  3 = "3. Make it easier"
  5 = "5. Keep these rules about the same"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043194f  (MAX=60)
  1 = "1. A lot more difficult"
  2 = "2. Somewhat more difficult"
  3 = "3. About the same (5 in P5c)"
  4 = "4. Somewhat easier"
  5 = "5. A lot easier"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043195f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043196f  (MAX=60)
  01 = "01. Women and men should have equal roles"
  07 = "07. A woman's place is in the home"
  80 = "80. Haven't thought much about this"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043197f  (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not too important"
  5 = "5. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043198f  (MAX=60)
  1 = "1. Women and men should have equal roles"
  7 = "7. A woman's place is in the home"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043199f  (MAX=60)
  1 = "1. Women and men should have equal roles"
  7 = "7. A woman's place is in the home"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043200f  (MAX=60)
  1 = "1. Women and men should have equal roles"
  7 = "7. A woman's place is in the home"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043201f  (MAX=60)
  1 = "1. Women and men should have equal roles"
  7 = "7. A woman's place is in the home"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043202f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043203f  (MAX=60)
  1 = "1. John Kerry"
  2 = "2. George W. Bush"
  3 = "3. Ralph Nader"
  5 = "5. None (if voter, will not vote for president) [VOL]"
  7 = "7. Other (SPECIFY)"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043204f  (MAX=60)
  00 = "00. No preference"
  11 = "11. Not strong - Kerry"
  12 = "12. Not strong - Bush"
  13 = "13. Not strong - Nader"
  14 = "14. Not strong - other candidate"
  25 = "25. Strong - Kerry"
  26 = "26. Strong - Bush"
  27 = "27. Strong - Nader"
  28 = "28. Strong - other candidate"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043205f  (MAX=60)
  1 = "1. Extremely good"
  2 = "2. Very good"
  3 = "3. Somewhat good"
  4 = "4. Not very good"
  7 = "7. Don't feel anything [VOL]"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043206f  (MAX=60)
  1 = "1. Agree"
  3 = "3. Neither agree nor disagree"
  5 = "5. Disagree"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043207f  (MAX=60)
  1 = "1. Agree"
  3 = "3. Neither agree nor disagree"
  5 = "5. Disagree"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043208f  (MAX=60)
  1 = "1. Extremely strong"
  2 = "2. Very strong"
  4 = "4. Somewhat strong"
  5 = "5. Not very strong"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043209f  (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not too important"
  5 = "5. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043210f  (MAX=60)
  1 = "1. Should be allowed"
  3 = "3. Should not be allowed"
  5 = "5. Should not be allowed to marry but should be allowed"
  7 = "7. Other [VOL] (SPECIFY)"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043211f  (MAX=60)
  1 = "1. Increased"
  3 = "3. Decreased"
  5 = "5. Stayed about the same"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043212f  (MAX=60)
  1 = "1. Increased lot"
  2 = "2. Increased a little"
  3 = "3. Same (5 in S2)"
  4 = "4. Decreased a little"
  5 = "5. Decreased a lot"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043213f  (MAX=60)
  1 = "1. Better"
  3 = "3. Worse"
  5 = "5. The same"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043214f  (MAX=60)
  1 = "1. Much better"
  2 = "2. Somewhat better"
  3 = "3. Same (5 in S3)"
  4 = "4. Somewhat worse"
  5 = "5. Much worse"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043215f  (MAX=60)
  1 = "1. More secure"
  3 = "3. Less secure"
  5 = "5. No change"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043216f  (MAX=60)
  1 = "1. Much more secure"
  2 = "2. Somewhat more secure"
  3 = "3. Same (5 in S4)"
  4 = "4. Somewhat less secure"
  5 = "5. Much less secure"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043217f  (MAX=60)
  1 = "1. Better"
  3 = "3. Worse"
  5 = "5. Stayed about the same"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043218f  (MAX=60)
  1 = "1. Much better"
  2 = "2. Somewhat better"
  3 = "3. Same (5 in S5)"
  4 = "4. Somewhat worse"
  5 = "5. Much worse"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043219f  (MAX=60)
  1 = "1. Important"
  5 = "5. Not important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043220f  (MAX=60)
  0 = "0. R says religion not important (5 in W1)"
  1 = "1. Some"
  3 = "3. Quite a bit"
  5 = "5. A great deal"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043221f  (MAX=60)
  1 = "1. Several times a day"
  2 = "2. Once a day"
  3 = "3. A few times a week"
  4 = "4. Once a week or less"
  5 = "5. Never"
  7 = "7. Other (SPECIFY)"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043222f  (MAX=60)
  1 = "1. The Bible is the actual word of God and is to"
  2 = "2. The Bible is the word of God but not everything in it"
  3 = "3. The Bible is a book written by men and is not the"
  7 = "7. Other (SPECIFY)"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043223f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043224f  (MAX=60)
 1 = "1. Every week"
 2 = "2. Almost every week"
 3 = "3. Once or twice a month"
 4 = "4. A few times a year"
 5 = "5. Never"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043225f  (MAX=60)
 1 = "1. Once a week"
 2 = "2. More often than once a week"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043226f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043227f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043228f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043229f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
 0 = "0. NA"
;
VALUE V043230a  (MAX=60)
 1 = "1. Protestant"
 2 = "2. Catholic"
 3 = "3. Jewish"
 7 = "7. Other"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043230b  (MAX=60)
 1 = "1. Protestant"
 2 = "2. Catholic"
 3 = "3. Jewish"
 7 = "7. Other"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043231f  (MAX=60)
 1 = "1. Baptist"
 2 = "2. Episcopalian/Anglican/Church of England"
 3 = "3. Lutheran"
 4 = "4. Methodist"
 5 = "5. Just Protestant"
 6 = "6. Presbyterian"
 7 = "7. Reformed"
 8 = "8. Brethren"
 9 = "9. Evangelical United Brethren"
 10 = "10. Christian or just Christian"
 11 = "11. Christian Scientist"
 12 = "12. Church (or Churches) of Christ"
 13 = "13. United Church of Christ "
 14 = "14. Disciples of Christ"
 15 = "15. Church of God "
 16 = "16. Assembly of God "
 17 = "17. Congregationalist "
 18 = "18. Holiness "
 19 = "19. Pentacostal"
 20 = "20. Friends, Quaker"
 21 = "21. Orthodox (SPECIFY)"
 22 = "22. Non-denominational - Protestant"
 23 = "23. Mormons "
 24 = "24. Jehovah's Witnesses "
 25 = "25. Latter Day Saints "
 26 = "26. Unitarian/Universalist"
 27 = "27. Buddhist"
 28 = "28. Hindu "
 29 = "29. Muslim/Islam"
 30 = "30. Native American "
 80 = "80. Other (SPECIFY)"
 88 = "88. Don't know"
 89 = "89. Refused"
;
VALUE V043232f  (MAX=60)
 1 = "1. Southern Baptist Convention"
 2 = "2. American Baptist Churches in USA"
 3 = "3. American Baptist Association"
 4 = "4. Independent Baptist"
 7 = "7. Other (SPECIFY)"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043233f  (MAX=60)
 1 = "1. Larger Baptist group (SPECIFY)"
 2 = "2. Local"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043234f  (MAX=60)
 1 = "1. Evangelical Lutheran Church"
 2 = "2. Missouri Synod"
 7 = "7. Other (SPECIFY)"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043235f  (MAX=60)
 1 = "1. United Methodist Church"
 2 = "2. African Methodist Episcopal"
 7 = "7. Other (SPECIFY)"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043236f  (MAX=60)
 1 = "1. Presbyterian Church USA (formerly"
 7 = "7. Other (SPECIFY)"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043237f  (MAX=60)
 1 = "1. Christian Reformed Church"
 2 = "2. The Reformed Church in America"
 7 = "7. Other (SPECIFY)"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043238f  (MAX=60)
 1 = "1. Church of the Brethren"
 2 = "2. The Plymouth Brethren"
 7 = "7. Other (SPECIFY)"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043239f  (MAX=60)
 1 = "1. Disciples of Christ"
 2 = "2. I am just a Christian"
 7 = "7. Other (SPECIFY)"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043240f  (MAX=60)
 1 = "1. Church of Christ"
 2 = "2. United Church of Christ"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043241f  (MAX=60)
 1 = "1. Anderson, Indiana"
 2 = "2. Cleveland, Tennessee"
 3 = "3. Church of God in Christ"
 7 = "7. Other (SPECIFY)"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043244f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
 0 = "0. NA"
;
VALUE V043245a  (MAX=60)
 1 = "1. Orthodox"
 2 = "2. Conservative"
 3 = "3. Reform"
 7 = "7. Other (SPECIFY)"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043245b  (MAX=60)
 1 = "1. Orthodox"
 2 = "2. Conservative"
 3 = "3. Reform"
 7 = "7. Other (SPECIFY)"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V043247f  (MAX=60)
 1 = "1. Protestant"
 2 = "2. Catholic"
 3 = "3. Eastern Orthodox (Christian)"
 4 = "4. Jewish"
 6 = "6. Other"
 7 = "7. None"
 8 = "8. DK"
 9 = "9. RF"
 0 = "0. NA"
;
VALUE V043247a  (MAX=60)
 01= "01. General Protestant/Christian"
 02= "02. Adventist"
 03= "03. Anglican"
 04= "04. Baptist"
 05= "05. Congregational"
 06= "06. European Free Church (Anabaptist)"
 07= "07. Holiness"
 08= "08. Independent Fundamentalist"
 09= "09. Lutheran"
 10= "10. Methodist"
 11= "11. Pentecostal"
 12= "12. Presbyterian"
 13= "13. Reformed"
 14= "14. Restorationist"
 15= "15. Non-traditional Protestant"
 16= "16. Roman Catholic"
 17= "17. Jewish"
 18= "18. Eastern Orthodox"
 19= "19. Non Judeo-Christian religion"
 20= "20. More than 1 major religion"
 77= "77. None"
 88= "88. DK"
 89= "89. RF"
 00= "00. NA"
;
VALUE V043248f  (MAX=60)
  010 = "010. Protestant, no denomination given"
  020 = "020. Non-denominational Protestant"
  030 = "030. Community church"
  040 = "040. Inter-denominational Protestant"
  099 = "099. Christian (NFS); "just Christian""
  100 = "100. 7th Day Adventist"
  109 = "109. Adventist (NFS)"
  110 = "110. Episcopalian; Anglican"
  111 = "111. Independent Anglican, Episcopalian"
  120 = "120. American Baptist Association"
  121 = "121. American Baptist Churches U.S.A."
  122 = "122. Baptist Bible Fellowship"
  123 = "123. Baptist General Conference"
  124 = "124. Baptist Missionary Association of America"
  125 = "125. Conservative Baptist Association of America"
  126 = "126. General Association of Regular Baptist Churches"
  127 = "127. National Association of Free Will Baptists"
  128 = "128. Primitive Baptists"
  129 = "129. National Baptist Convention in the U.S.A."
  130 = "130. National Baptist Convention of America"
  131 = "131. National Primitive Baptist Convention of the U.S.A."
  132 = "132. Progressive National Baptist Convention"
  134 = "134. Reformed Baptist (Calvinist)"
  135 = "135. Southern Baptist Convention"
  147 = "147. Fundamental Baptist (no denom. ties)"
  148 = "148. Local (independent) Baptist churches with"
  149 = "149. Baptist (NFS)"
  150 = "150. United Church of Christ (includes Congregational"
  155 = "155. Congregational Christian"
  160 = "160. Church of the Brethren"
  161 = "161. Brethren (NFS)"
  162 = "162. Mennonite Church"
  163 = "163. Moravian Church"
  164 = "164. Old Order Amish"
  165 = "165. Quakers (Friends)"
  166 = "166. Evangelical Covenant Church (not Anabaptist in"
  167 = "167. Evangelical Free Church (not Anabaptist in"
  168 = "168. Brethren in Christ"
  170 = "170. Mennonite Brethren"
  180 = "180. Christian and Missionary Alliance (CMA)"
  181 = "181. Church of God (Anderson, IN)"
  182 = "182. Church of the Nazarene"
  183 = "183. Free Methodist Church"
  184 = "184. Salvation Army"
  185 = "185. Wesleyan Church"
  186 = "186. Church of God of Findlay, OH"
  199 = "199. Holiness (NFS); Church of God (NFS); R not or NA"
  200 = "200. Plymouth Brethren"
  201 = "201. Independent Fundamentalist Churches of America"
  219 = "219. Independent-Fundamentalist (NFS)"
  220 = "220. Evangelical Lutheran Church in America (formerly"
  221 = "221. Lutheran Church--Missouri Synod; LC-MS"
  222 = "222. Wisconsin Evangelical Lutheran Synod; WELS"
  223 = "223. Other Conservative Lutheran"
  229 = "229. Lutheran (NFS)"
  230 = "230. United Methodist Church; Evangelical United"
  231 = "231. African Methodist Episcopal Church"
  232 = "232. African Methodist Episcopal Zion Church"
  233 = "233. Christian Methodist Episcopal Church"
  234 = "234. Primitive Methodist"
  240 = "240. Congregational Methodist (fundamentalist)"
  249 = "249. Methodist (NFS)"
  250 = "250. Assemblies of God"
  251 = "251. Church of God (Cleveland, TN)"
  252 = "252. Church of God (Huntsville, AL)"
  253 = "253. International Church of the Four Square Gospel"
  254 = "254. Pentecostal Church of God"
  255 = "255. Pentecostal Holiness Church"
  256 = "256. United Pentecostal Church International"
  257 = "257. Church of God in Christ (incl. NA whether 258)"
  258 = "258. Church of God in Christ (International)"
  260 = "260. Church of God of the Apostolic Faith"
  261 = "261. Church of God of Prophecy"
  262 = "262. Vineyard Fellowship"
  263 = "263. Open Bible Standard Churches"
  264 = "264. Full Gospel"
  267 = "267. Apostolic Pentecostal"
  268 = "268. Spanish Pentecostal"
  269 = "269. Pentecostal (NFS); Church of God (NFS); R not or"
  270 = "270. Presbyterian Church in the U.S.A."
  271 = "271. Cumberland Presbyterian Church"
  272 = "272. Presbyterian Church in American (PCA)"
  275 = "275. Evangelical Presbyterian"
  276 = "276. Reformed Presbyterian"
  279 = "279. Presbyterian (NFS)"
  280 = "280. Christian Reformed Church (inaccurately known as"
  281 = "281. Reformed Church in America"
  282 = "282. Free Hungarian Reformed Church"
  289 = "289. Reformed (NFS)"
  290 = "290. Christian Church (Disciples of Christ)"
  291 = "291. Christian Churches and Churches of Christ"
  292 = "292. Churches of Christ; Church of Christ (NFS)"
  293 = "293. Christian Congregation"
  300 = "300. Christian Scientists"
  301 = "301. Mormons; Latter Day Saints"
  302 = "302. Spiritualists"
  303 = "303. Unitarian; Universalist"
  304 = "304. Jehovah's Witnesses"
  305 = "305. Unity; Unity Church; Christ Church Unity"
  306 = "306. Fundamentalist Adventist (Worldwide Church of God)"
  309 = "309. Non-traditional Protestant (NFS)"
  400 = "400. Roman Catholic"
  500 = "500. Jewish, no preference"
  501 = "501. Orthodox"
  502 = "502. Conservative"
  503 = "503. Reformed"
  524 = "524. Jewish, other"
  600 = "600. Roman Catholic AND Protestant"
  700 = "700. Greek Rite Catholic"
  701 = "701. Greek Orthodox"
  702 = "702. Russian Orthodox"
  703 = "703. Rumanian Orthodox"
  704 = "704. Serbian Orthodox"
  705 = "705. Syrian Orthodox"
  706 = "706. Armenian Orthodox"
  707 = "707. Georgian Orthodox"
  708 = "708. Ukranian Orthodox"
  719 = "719. Eastern Orthodox (NFS)"
  720 = "720. Muslim; Mohammedan; Islam"
  721 = "721. Buddhist"
  722 = "722. Hindu"
  723 = "723. Bahai"
  724 = "724. American Indian Religions (Native American"
  725 = "725. New Age"
  726 = "726. Wica (Wiccan)"
  727 = "727. Pagan"
  729 = "729. Other non-Christian/non-Jewish"
  750 = "750. Scientology"
  790 = "790. Religious/ethical cults"
  795 = "795. More than 1 major religion (e.g., Christian,"
  870 = "870. Other"
  879 = "879. R indicates attendance/affiliation but specifies none"
  880 = "880. None"
  881 = "881. Agnostics"
  882 = "882. Atheists"
  888 = "888. DK"
  889 = "889. RF"
  000 = "000. NA"
;
VALUE V043249a  (MAX=60)
  8888 = "8888. DK"
  8889 = "8889. RF"
;
VALUE V043249b  (MAX=60)
  88 = "88. DK"
  89 = "89. RF"
;
VALUE V043250f  (MAX=60)
  98 = "88. DK"
  99 = "89. RF"
  00 = "00. NA"
;
VALUE V043251f  (MAX=60)
  1 = "1. Married"
  2 = "2. Widowed"
  3 = "3. Divorced"
  4 = "4. Separated"
  5 = "5. Never married"
  6 = "6. Partnered, not married {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043251x  (MAX=60)
  1 = "1. Indicated married/partnered in both Y2 and HH listing"
  2 = "2. Indicated married/partnered in HH listing only"
  3 = "3. Indicated married or partnered in Y2 only"
  4 = "4. Not indicated as married/partnered in Y2 or HH listing"
;
VALUE V043252f  (MAX=60)
  0 = "0. 0 grades"
  17= "17 or more grades"
  88= "88. Don't know"
  89= "89. Refused"
;
VALUE V043253a  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043253b  (MAX=60)
  1 = "1. Bachelor's degree"
  2 = "2. Master's degree"
  3 = "3. PhD, LIT, SCD, DFA, DLIT, DPH, DPHIL, JSC, SJD"
  4 = "4. LLB, JD"
  5 = "5. MD, DDS, DVM, MVSA, DSC, DO"
  6 = "6. JDC, STD, THD"
  7 = "7. Associate degree (AA)"
  0 = "0. No degree earned"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043254f  (MAX=60)
  0 = "0. NA/DK number of grades; no HS diploma"
  1 = "1. 8 grades or less and no diploma or equivalency"
  2 = "2. 9-11 grades, no further schooling"
  3 = "3. High school diploma or equivalency test"
  4 = "4. More than 12 years of schooling, no higher degree"
  5 = "5. Junior or community college level degrees"
  6 = "6. BA level degrees; 17+ years, no advanced degree"
  7 = "7. Advanced degree, including LLB"
  8 = "8. DK"
  9 = "9. RF"
;
VALUE V043255f  (MAX=60)
  0 = "0. 0 grades"
  17= "17 or more grades"
  88= "88. Don't know"
  89= "89. Refused"
;
VALUE V043256a  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043256b  (MAX=60)
  1 = "1. Bachelor's degree"
  2 = "2. Master's degree"
  3 = "3. PhD, LIT, SCD, DFA, DLIT, DPH, DPHIL, JSC, SJD"
  4 = "4. LLB, JD"
  5 = "5. MD, DDS, DVM, MVSA, DSC, DO"
  6 = "6. JDC, STD, THD"
  7 = "7. Associate degree (AA)"
  0 = "0. No degree earned"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043257f  (MAX=60)
  0 = "0. NA/DK number of grades; no HS diploma"
  1 = "1. 8 grades or less and no diploma or equivalency"
  2 = "2. 9-11 grades, no further schooling"
  3 = "3. High school diploma or equivalency test"
  4 = "4. More than 12 years of schooling, no higher degree"
  5 = "5. Junior or community college level degrees"
  6 = "6. BA level degrees; 17+ years, no advanced degree"
  7 = "7. Advanced degree, including LLB"
  8 = "8. DK"
  9 = "9. RF"
;
VALUE V043258f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043259f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043260a  (MAX=60)
  10= "10. WORKING NOW only"
  15= "15. WORKING NOW >=20 hrs/wk and retired"
  16= "16. WORKING NOW >=20 hrs/wk and permanently disabled"
  17= "17. WORKING NOW >=20 hrs/wk and homemaker"
  18= "18. WORKING NOW >=20 hrs/wk and student"
  20= "20. TEMPORARILY LAID OFF"
  40= "40. UNEMPLOYED"
  50= "50. RETIRED, no other occupation"
  51= "51. RETIRED and working now <20 hrs/wk"
  60= "60. PERMANENTLY DISABLED, not working"
  61= "61. PERMANENTLY DISABLED and working now <20 hrs/wk"
  70= "70. HOMEMAKER, no other occupation"
  71= "71. HOMEMAKER and working now <20 hrs/wk"
  75= "75. HOMEMAKER and student, no other occupation"
  80= "80. STUDENT, no other occupation"
  81= "81. STUDENT and working now <20 hrs/wk"
  89= "89. Refused"
;
VALUE V043260b  (MAX=60)
  1 = "1. R WORKING NOW"
  2 = "2. R TEMPORARILY LAID OFF (TLO)"
  4 = "4. R UNEMPLOYED"
  5 = "5. R RETIRED"
  6 = "6. R PERMANENTLY DISABLED"
  7 = "7. R HOMEMAKER"
  8 = "8. R STUDENT"
  9 = "9. Refused"
;
VALUE V043260c  (MAX=60)
  1 = "1. Working now"
  2 = "2. Temporarily laid off (TLO)"
  4 = "4. Unemployed"
  5 = "5. Retired"
  6 = "6. Permanently disabled"
  7 = "7. Homemaker"
  8 = "8. Student"
  9 = "9. Refused"
;
VALUE V043261f  (MAX=60)
  1 = "1. Current employment [Y6(1)=10,16,17,18,20,61,71,81]"
  2 = "2. Past employment (if any) [Y6(1) = 15,40,50,51,60]"
;
VALUE V043262a  (MAX=60)
 999 = "999. DK; NA; Don't know; Not ascertained"
;
VALUE V043262b  (MAX=60)
 99 = "99. DK; NA; Don't know; Not ascertained"
;
VALUE V043262c  (MAX=60)
  1 = "1. Lowest prestige"
  6 = "6. Highest prestige"
  8 = "8. Member of military"
  9 = "9. DK; NA; Don't know; Not ascertained"
;
VALUE V043262d  (MAX=60)
  999.99 = "999.99 DK; NA; Don't know; Not ascertained"
;
VALUE V043262e  (MAX=60)
  999 = "999. DK; NA; Don't know; Not ascertained"
;
VALUE V043262f  (MAX=60)
  1 = "1. Someone else"
  3 = "3. Both self and someone else"
  5 = "5. Self-employed"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043262g  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043262h  (MAX=60)
  888 = "888. Don't know"
  889 = "889. Refused"
  000 = "000. NA"
;
VALUE V043262j  (MAX=60)
  1 = "1. A lot"
  3 = "3. Somewhat"
  5 = "5. Not much at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043262k  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043262m  (MAX=60)
999 = "999. DK; NA; Don't know; Not ascertained"
;
VALUE V043262n  (MAX=60)
 99 = " 99. DK; NA; Don't know; Not ascertained"
;
VALUE V043262p  (MAX=60)
 01 = "01. Executive, Administrative and Managerial (001-039)"
 02 = "02. Professional Specialty Occupations (040-199)"
 03 = "03. Technicians and Related Support Occupations (200-235)"
 04 = "04. Sales Occupation ( 236-285)"
 05 = "05. Administrative Support, including clerical (286-389)"
 06 = "06. Private Household (403-407)"
 07 = "07. Protective Service (408-427)"
 08 = "08. Service except Protective and Household (428-469)"
 09 = "09. Farming, Forestry and Fishing Occupations (470-499)"
 10 = "10. Precision Production, Craft and Repair Occupations(500-"
 11 = "11. Machine Operators, Assemblers and Inspectors (700-799)"
 12 = "12. Transportation and Material Moving Occupations (800-859)"
 13 = "13. Handlers, Equipment Cleaners, Helpers and Laborers(860-)"
 14 = "14. Member of Armed Forces"
 99 = "99. DK; NA; Don't know; Not ascertained"
;
VALUE V043263f  (MAX=60)
  1 = "1. Y16a-Y17b Current employment only [10,20,17,18,71,81 in"
  2 = "2. Y7a-Y15 Past employment only [40,50,60,70,75,80 in Y6(1)]"
  3 = "3. Both current and past [15,16,51,61 in Y6(1)]"
;
VALUE V043264f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043265f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
;
VALUE V043266a  (MAX=60)
  8888 = "8888. Don't know"
  8889 = "8889. Refused"
;
VALUE V043266b  (MAX=60)
  01 = "01. January"
  02 = "02. February"
  03 = "03. March"
  04 = "04. April"
  05 = "05. May"
  06 = "06. June"
  07 = "07. July"
  08 = "08. August"
  09 = "09. September"
  10 = "10. October"
  11 = "11. November"
  12 = "12. December"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043267f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043268f  (MAX=60)
  999 = "999. DK; NA; Don't know; Not ascertained"
;
VALUE V043268a  (MAX=60)
  99 = "99. DK; NA; Don't know; Not ascertained"
;
VALUE V043268b  (MAX=60)
  1 = "1. Lowest prestige"
  6 = "6. Highest prestige"
  8 = "8. Member of military"
  9 = "9. DK; NA; Don't know; Not ascertained"
;
VALUE V043268c  (MAX=60)
  999.99 = "999.99 DK; NA; Don't know; Not ascertained"
;
VALUE V043268d  (MAX=60)
999 = "999. DK; NA; Don't know; Not ascertained"
;
VALUE V043268e  (MAX=60)
 99 = " 99. DK; NA; Don't know; Not ascertained"
;
VALUE V043268f  (MAX=60)
 01 = "01. Executive, Administrative and Managerial (001-039)"
 02 = "02. Professional Specialty Occupations (040-199)"
 03 = "03. Technicians and Related Support Occupations (200-235)"
 04 = "04. Sales Occupation ( 236-285)"
 05 = "05. Administrative Support, including clerical (286-389)"
 06 = "06. Private Household (403-407)"
 07 = "07. Protective Service (408-427)"
 08 = "08. Service except Protective and Household (428-469)"
 09 = "09. Farming, Forestry and Fishing Occupations (470-499)"
 10 = "10. Precision Production, Craft and Repair Occupations(500-)"
 11 = "11. Machine Operators, Assemblers and Inspectors (700-799)"
 12 = "12. Transportation and Material Moving Occupations (800-859)"
 13 = "13. Handlers, Equipment Cleaners, Helpers and Laborers(860-)"
 14 = "14. Member of Armed Forces"
 99 = " 99. DK; NA; Don't know; Not ascertained"
;
VALUE V043269f  (MAX=60)
  999 = "999. DK; NA; Don't know; Not ascertained"
;
VALUE V043270f  (MAX=60)
  1 = "1. Someone else"
  3 = "3. Both self and someone else"
  5 = "5. Self-employed"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043271f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043272f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043273f  (MAX=60)
  888 = "888. Don't know"
  889 = "889. Refused"
  000 = "000. NA"
;
VALUE V043274f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043275f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043276f  (MAX=60)
  1 = "1. A lot"
  3 = "3. Somewhat"
  5 = "5. Not much at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043277f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
;
VALUE V043278f  (MAX=60)
  999 = "999. DK; NA; Don't know; Not ascertained"
;
VALUE V043278a  (MAX=60)
  99 = "99. DK; NA; Don't know; Not ascertained"
;
VALUE V043278b  (MAX=60)
  1 = "1. Lowest prestige"
  6 = "6. Highest prestige"
  8 = "8. Member of military"
  9 = "9. DK; NA; Don't know; Not ascertained"
;
VALUE V043278c  (MAX=60)
  999.99 = "999.99 DK; NA; Don't know; Not ascertained"
;
VALUE V043278d  (MAX=60)
999 = "999. DK; NA; Don't know; Not ascertained"
;
VALUE V043278e  (MAX=60)
 99 = " 99. DK; NA; Don't know; Not ascertained"
;
VALUE V043278f  (MAX=60)
 01 = "01. Executive, Administrative and Managerial (001-039)"
 02 = "02. Professional Specialty Occupations (040-199)"
 03 = "03. Technicians and Related Support Occupations (200-235)"
 04 = "04. Sales Occupation ( 236-285)"
 05 = "05. Administrative Support, including clerical (286-389)"
 06 = "06. Private Household (403-407)"
 07 = "07. Protective Service (408-427)"
 08 = "08. Service except Protective and Household (428-469)"
 09 = "09. Farming, Forestry and Fishing Occupations (470-499)"
 10 = "10. Precision Production, Craft and Repair Occupations(500-)"
 11 = "11. Machine Operators, Assemblers and Inspectors (700-799)"
 12 = "12. Transportation and Material Moving Occupations (800-859)"
 13 = "13. Handlers, Equipment Cleaners, Helpers and Laborers(860-)"
 14 = "14. Member of Armed Forces"
 99 = " 99. DK; NA; Don't know; Not ascertained"
;
VALUE V043279f  (MAX=60)
  999 = "999. DK; NA; Don't know; Not ascertained"
;
VALUE V043280f  (MAX=60)
  1 = "1. Someone else"
  3 = "3. Both self and someone else"
  5 = "5. Self-employed"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043281f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043282f  (MAX=60)
  888 = "888. Don't know"
  889 = "889. Refused"
;
VALUE V043283f  (MAX=60)
  1 = "1. More"
  3 = "3. Fewer"
  5 = "5. About right"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043284f  (MAX=60)
  1 = "1. A lot"
  3 = "3. Somewhat"
  5 = "5. Not much at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043285f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043286f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043287f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043288f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043289f  (MAX=60)
  10 = "10. Working now only"
  15 = "15. Working now and retired"
  16 = "16. Working now and disabled"
  17 = "17. Working now and homemaker"
  18 = "18. Working now and student"
  20 = "20. Temporarily laid off only"
  25 = "25. Temporarily laid off and retired"
  26 = "26. Temporarily laid off and disabled"
  27 = "27. Temporarily laid off and homemaker"
  28 = "28. Temporarily laid off and student"
  40 = "40. Unemployed only"
  50 = "50. Retired only"
  54 = "54. Retired and unemployed"
  56 = "56. Retired and disabled"
  57 = "57. Retired and homemaker"
  58 = "58. Retired and student"
  60 = "60. Disabled only"
  64 = "64. Disabled and unemployed"
  67 = "67. Disabled and homemaker"
  68 = "68. Disabled and student"
  70 = "70. Homemaker only"
  74 = "74. Homemaker and unemployed"
  78 = "78. Homemaker and student"
  80 = "80. Student only"
  84 = "84. Student and unemployed"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043289a  (MAX=60)
  1 = "1. Working now (10,15-18 in Y18a1)"
  2 = "2. Temporarily laid off (20,25-28 in Y18a1)"
  4 = "4. Unemployed (40 in Y18a1)"
  5 = "5. Retired (50,54,56-58 in Y18a1)"
  6 = "6. Permanently disabled (60,64,67,68 in Y18a1)"
  7 = "7. Homemaker (70,74,78 in Y18a1)"
  8 = "8. Student (80,84 in Y18a1)"
  9 = "9. Don't know (88 in Y18a1)"
  0 = "0. Refused (89 in Y18a1)"
;
VALUE V043290f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043291f  (MAX=60)
  10 = "10. Respondent only"
  12 = "12. Respondent and wife/female partner"
  13 = "13. Respondent and husband/male partner"
  14 = "14. Respondent and someone else"
  20 = "20. Wife/female partner only"
  24 = "24. Wife/female partner and someone else"
  30 = "30. Husband/male partner only"
  34 = "34. Husband/male partner and someone else"
  40 = "40. Someone else only"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043292f  (MAX=60)
  1 = "1. Someone IN ADDITION TO RESPONDENT is age 14 or older"
  5 = "5. NO ONE OTHER THAN RESPONDENT is age 14 or older in"
  8 = "8. Coding error by Interviewer; R indicated as married/"
  9 = "9. Coding error by Interviewer; person in household"
;
VALUE V043293f  (MAX=60)
  01 = "01. A. None or less than $2,999"
  02 = "02. B. $3,000 -$4,999"
  03 = "03. C. $5,000 -$6,999"
  04 = "04. D. $7,000 -$8,999"
  05 = "05. E. $9,000 -$10,999"
  06 = "06. F. $11,000-$12,999"
  07 = "07. G. $13,000-$14,999"
  08 = "08. H. $15,000-$16,999"
  09 = "09. J. $17,000-$19,999"
  10 = "10. K. $20,000-$21,999"
  11 = "11. M. $22,000-$24,999"
  12 = "12. N. $25,000-$29,999"
  13 = "13. P. $30,000-$34,999"
  14 = "14. Q. $35,000-$39,999"
  15 = "15. R. $40,000-$44,999"
  16 = "16. S. $45,000-$49,999"
  17 = "17. T. $50,000-$59,999"
  18 = "18. U. $60,000-$69,999"
  19 = "19. V. $70,000-$79,999"
  20 = "20. W. $80,000-$89,999"
  21 = "21. X. $90,000-$104,999"
  22 = "22. Y. $105,000-$119,000"
  23 = "23. Z. $120,000 and over"
  88 = "88. Don't know"
  89 = "89. Refused"
  00 = "00. NA (8,9 in Y20)"
;
VALUE V043293x  (MAX=60)
  01 = "01. A. None or less than $2,999"
  02 = "02. B. $3,000 -$4,999"
  03 = "03. C. $5,000 -$6,999"
  04 = "04. D. $7,000 -$8,999"
  05 = "05. E. $9,000 -$10,999"
  06 = "06. F. $11,000-$12,999"
  07 = "07. G. $13,000-$14,999"
  08 = "08. H. $15,000-$16,999"
  09 = "09. J. $17,000-$19,999"
  10 = "10. K. $20,000-$21,999"
  11 = "11. M. $22,000-$24,999"
  12 = "12. N. $25,000-$29,999"
  13 = "13. P. $30,000-$34,999"
  14 = "14. Q. $35,000-$39,999"
  15 = "15. R. $40,000-$44,999"
  16 = "16. S. $45,000-$49,999"
  17 = "17. T. $50,000-$59,999"
  18 = "18. U. $60,000-$69,999"
  19 = "19. V. $70,000-$79,999"
  20 = "20. W. $80,000-$89,999"
  21 = "21. X. $90,000-$104,999"
  22 = "22. Y. $105,000-$119,000"
  23 = "23. Z. $120,000 and over"
  88 = "88. Don't know"
  89 = "89. Refused"
  00 = "00. NA (8,9 in Y20)"
;
VALUE V043294f  (MAX=60)
  01 = "01. A. None or less than $2,999"
  02 = "02. B. $3,000 -$4,999"
  03 = "03. C. $5,000 -$6,999"
  04 = "04. D. $7,000 -$8,999"
  05 = "05. E. $9,000 -$10,999"
  06 = "06. F. $11,000-$12,999"
  07 = "07. G. $13,000-$14,999"
  08 = "08. H. $15,000-$16,999"
  09 = "09. J. $17,000-$19,999"
  10 = "10. K. $20,000-$21,999"
  11 = "11. M. $22,000-$24,999"
  12 = "12. N. $25,000-$29,999"
  13 = "13. P. $30,000-$34,999"
  14 = "14. Q. $35,000-$39,999"
  15 = "15. R. $40,000-$44,999"
  16 = "16. S. $45,000-$49,999"
  17 = "17. T. $50,000-$59,999"
  18 = "18. U. $60,000-$69,999"
  19 = "19. V. $70,000-$79,999"
  20 = "20. W. $80,000-$89,999"
  21 = "21. X. $90,000-$104,999"
  22 = "22. Y. $105,000-$119,000"
  23 = "23. Z. $120,000 and over"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043295f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043296f  (MAX=60)
  1 = "1. Middle class"
  5 = "5. Working class"
  7 = "7. Other (SPECIFY)"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043297f  (MAX=60)
  0 = "0. Upper class {VOL}"
  1 = "1. Middle class"
  5 = "5. Working class"
  6 = "6. Lower class {VOL}"
  7 = "7. Other (SPECIFY)"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043298f (MAX=60)
  00 = "00. Lower class (VOLUNTEERED)"
  01 = "01. Average working class"
  02 = "02. Working class -- NA if average or upper"
  03 = "03. Upper working class"
  04 = "04. Average middle class"
  05 = "05. Middle class -- NA if average or upper"
  06 = "06. Upper middle class"
  07 = "07. Upper class (VOLUNTEERED)"
  77 = "77. Other"
  88 = "88. Don't know if working or middle class"
  89 = "89. Refused; 'neither' or doesn't accept"
;
VALUE V043299f (MAX=60)
  10 = "10. Black"
  12 = "12. Black and Asian"
  13 = "13. Black and Native American"
  14 = "14. Black and Hispanic"
  15 = "15. Black and White"
  20 = "20. Asian"
  23 = "23. Asian and Native American"
  24 = "24. Asican and Hispanic"
  25 = "25. Asian and White"
  30 = "30. Native American"
  34 = "34. Native American and Hispanic"
  35 = "35. Native American and White"
  40 = "40. Hispanic"
  45 = "45. Hispanic and White"
  50 = "50. White (no mention of other race)"
  70 = "70. Other"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043299a (MAX=60)
  10 = "10. Black"
  20 = "20. Asian"
  30 = "30. Native American"
  40 = "40. Hispanic"
  50 = "50. White (no mention of other race)"
  70 = "70. Other"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043300f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043301a  (MAX=60)
  877 = "877. None"
  888 = "888. Don't know"
  889 = "889. Refused"
  000 = "000. NA; no mention; none"
;
VALUE V043302f  (MAX=60)
  0 = "0. None"
  1 = "1. One"
  2 = "2. Two or more"
  9 = "9. Respondent refused to answer or doesn't know"
;
VALUE V043303f  (MAX=60)
  877 = "877. None; neither"
  888 = "888. Don't know"
  889 = "889. Refused"
  000 = "000. NA; no mention; none"
;
VALUE V043303x  (MAX=60)
  877 = "877. None"
  888 = "888. Don't know"
  889 = "889. Refused"
  000 = "000. NA; no mention; none"
;
VALUE V043304x  (MAX=60)
  0 = "0. No Hispanic mention"
  1 = "1. Spanish/Hispanic mention in Y24x"
  2 = "2. Spanish/Hispanic mention in Y26a/Y26b/Y26c/Y27a"
  3 = "3. Spanish/Hispanic mention in both"
;
VALUE V043305f  (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043306f  (MAX=60)
  1 = "1. Mexican"
  2 = "2. Puerto Rican"
  3 = "3. Cuban"
  4 = "4. Latin American"
  5 = "5. Central American"
  6 = "6. Spanish"
  7 = "7. Other (SPECIFY) {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V043307f  (MAX=60)
  888 = "888. Don't know"
  889 = "889. Refused"
  000 = "000. NA"
;
VALUE V043308f  (MAX=60)
  00 = "00. Less than 1 year"
  01 = "01. 12-18 months; 1 year"
  02 = "02. 19-24 months; 2 years"
  03 = "03. 3 years"
  76 = "76. 76 years or more"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043309a  (MAX=60)
  888 = "888. Don't know"
  889 = "889. Refused"
  000 = "000. NA"
;
VALUE V043310f  (MAX=60)
  00 = "00. Less than 1 mile"
  01 = "01. One mile"
  02 = "02. 2-4 miles"
  03 = "03. 5-9 miles"
  04 = "04. 10-19 miles"
  05 = "05. 20-49 miles"
  06 = "06. 50-99 miles"
  07 = "07. 100-199 miles"
  08 = "08. 200-499 miles"
  09 = "09. 500 miles or more"
  90 = "90. Other (SPECIFY)"
;
VALUE V043311f  (MAX=60)
  00 = "00. Less than 1 year"
  01 = "01. 12-18 months; 1 year"
  02 = "02. 19-24 months; 2 years"
  03 = "03. 3 years"
  76 = "76. 76 years or more"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V043312f  (MAX=60)
  1 = "1. Own house"
  5 = "5. Pay rent"
  7 = "7. Other (SPECIFY)"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V043401a  (MAX=60)
  1 = "1. Marked"
  5 = "5. Not marked"
  0 = "0. NA"
;
VALUE V043401b  (MAX=60)
  1 = "1. Marked"
  5 = "5. Not marked"
  0 = "0. NA"
;
VALUE V043401c  (MAX=60)
  1 = "1. Marked"
  5 = "5. Not marked"
  0 = "0. NA"
;
VALUE V043401d  (MAX=60)
  1 = "1. Marked"
  5 = "5. Not marked"
  0 = "0. NA"
;
VALUE V043401e  (MAX=60)
  1 = "1. Marked"
  5 = "5. Not marked"
  0 = "0. NA"
;
VALUE V043401f  (MAX=60)
  1 = "1. Marked"
  5 = "5. Not marked"
  0 = "0. NA"
;
VALUE V043402f  (MAX=60)
  1 = "1. Very good"
  2 = "2. Good"
  3 = "3. Fair"
  4 = "4. Poor"
  5 = "5. Very poor"
  0 = "0. NA"
;
VALUE V043403f  (MAX=60)
  1 = "1. Very high"
  2 = "2. Fairly high"
  3 = "3. Average"
  4 = "4. Fairly low"
  5 = "5. Very low"
  0 = "0. NA"
;
VALUE V043404f  (MAX=60)
  1 = "1. Very high"
  2 = "2. Fairly high"
  3 = "3. Average"
  4 = "4. Fairly low"
  5 = "5. Very low"
  0 = "0. NA"
;
VALUE V043405f  (MAX=60)
  1 = "1. Not at all suspicious"
  2 = "2. Somewhat suspicious"
  3 = "3. Very suspicious"
  0 = "0. NA"
;
VALUE V043406f  (MAX=60)
  1 = "1. Very high"
  2 = "2. Fairly high"
  3 = "3. Average"
  4 = "4. Fairly low"
  5 = "5. Very low"
  0 = "0. NA"
;
VALUE V043407f  (MAX=60)
  1 = "1. Completely sincere"
  2 = "2. Usually sincere"
  3 = "3. Often seemed to be insincere"
  0 = "0. NA"
;
VALUE V043408f  (MAX=60)
  1 = "1. Yes {SPECIFY}"
  5 = "5. No"
;
VALUE V043409f  (MAX=60)
  1 = "1. Yes, think R reported correctly"
  2 = "2. No, think R reported incorrectly"
  3 = "3. Refused income questions"
  4 = "4. No, think R reported dishonestly"
  0 = "0. NA"
;
VALUE V043409a  (MAX=60)
  01 = "01. A. None or less than $2,999"
  02 = "02. B. $3,000 -$4,999"
  03 = "03. C. $5,000 -$6,999"
  04 = "04. D. $7,000 -$8,999"
  05 = "05. E. $9,000 -$10,999"
  06 = "06. F. $11,000-$12,999"
  07 = "07. G. $13,000-$14,999"
  08 = "08. H. $15,000-$16,999"
  09 = "09. J. $17,000-$19,999"
  10 = "10. K. $20,000-$21,999"
  11 = "11. M. $22,000-$24,999"
  12 = "12. N. $25,000-$29,999"
  13 = "13. P. $30,000-$34,999"
  14 = "14. Q. $35,000-$39,999"
  15 = "15. R. $40,000-$44,999"
  16 = "16. S. $45,000-$49,999"
  17 = "17. T. $50,000-$59,999"
  18 = "18. U. $60,000-$69,999"
  19 = "19. V. $70,000-$79,999"
  20 = "20. W. $80,000-$89,999"
  21 = "21. X. $90,000-$104,999"
  22 = "22. Y. $105,000-$119,000"
  23 = "23. Z. $120,000 and over"
  98 = "98. IMPOSSIBLE TO ESTIMATE"
  00 = "00. NA"
;
VALUE V043410f  (MAX=60)
  97 = "97. 97 and older"
  98 = "98. Hard to guess {SPECIFY}"
  0 = "0. NA"
;
VALUE V043411f  (MAX=60)
  1 = "1. Male"
  2 = "2. Female"
  0 = "0. NA"
;
VALUE V043412f  (MAX=60)
  1 = "1. Low - probably less than high school diploma"
  2 = "2. Probably has a high school diploma but"
  3 = "3. Probably a little college"
  4 = "4. Probably a college degree"
  8 = "8. Hard to guess {SPECIFY}"
  0 = "0. NA"
;
VALUE V043413a  (MAX=60)
  10 = "10. Negative - general"
  11 = "11. Negative - too long"
  12 = "12. Negative - too complicated"
  13 = "13. Negative - boring/tedious/repetitious"
  15 = "15. R wanted to stop before interview completed. After"
  20 = "20. R complained and/or interviewer observed that R was"
  22 = "22. R complained and/or interviewer observed that R was"
  30 = "30. R expressed (especially repeatedly) doubts/apologies/"
  31 = "31. R expressed (especially repeatedly) doubts/apologies/"
  40 = "40. R was agitated or stressed by interview PROCESS"
  41 = "41. R became angry at interview CONTENT"
  45 = "45. R became concerned about sampling purpose or bias:"
  50 = "50. R could not read Respondent Booklet"
  70 = "70. R appeared to enjoy the interview (R was "cooperative""
  80 = "80. Neutral or no feedback (1st mention only"
  00 = "00. NA"
;
VALUE V043413b  (MAX=60)
  10 = "10. Negative - general"
  11 = "11. Negative - too long"
  12 = "12. Negative - too complicated"
  13 = "13. Negative - boring/tedious/repetitious"
  15 = "15. R wanted to stop before interview completed. After"
  20 = "20. R complained and/or interviewer observed that R was"
  22 = "22. R complained and/or interviewer observed that R was"
  30 = "30. R expressed (especially repeatedly) doubts/apologies/"
  31 = "31. R expressed (especially repeatedly) doubts/apologies/"
  40 = "40. R was agitated or stressed by interview PROCESS"
  41 = "41. R became angry at interview CONTENT"
  45 = "45. R became concerned about sampling purpose or bias:"
  50 = "50. R could not read Respondent Booklet"
  70 = "70. R appeared to enjoy the interview (R was "cooperative""
;
VALUE V043413c  (MAX=60)
  10 = "10. Negative - general"
  11 = "11. Negative - too long"
  12 = "12. Negative - too complicated"
  13 = "13. Negative - boring/tedious/repetitious"
  15 = "15. R wanted to stop before interview completed. After"
  20 = "20. R complained and/or interviewer observed that R was"
  22 = "22. R complained and/or interviewer observed that R was"
  30 = "30. R expressed (especially repeatedly) doubts/apologies/"
  31 = "31. R expressed (especially repeatedly) doubts/apologies/"
  40 = "40. R was agitated or stressed by interview PROCESS"
  41 = "41. R became angry at interview CONTENT"
  45 = "45. R became concerned about sampling purpose or bias:"
  50 = "50. R could not read Respondent Booklet"
  70 = "70. R appeared to enjoy the interview (R was "cooperative""
;
VALUE V043413d  (MAX=60)
  10 = "10. Negative - general"
  11 = "11. Negative - too long"
  12 = "12. Negative - too complicated"
  13 = "13. Negative - boring/tedious/repetitious"
  15 = "15. R wanted to stop before interview completed. After"
  20 = "20. R complained and/or interviewer observed that R was"
  22 = "22. R complained and/or interviewer observed that R was"
  30 = "30. R expressed (especially repeatedly) doubts/apologies/"
  31 = "31. R expressed (especially repeatedly) doubts/apologies/"
  40 = "40. R was agitated or stressed by interview PROCESS"
  41 = "41. R became angry at interview CONTENT"
  45 = "45. R became concerned about sampling purpose or bias:"
  50 = "50. R could not read Respondent Booklet"
  70 = "70. R appeared to enjoy the interview (R was "cooperative""
;
VALUE V043413e  (MAX=60)
  10 = "10. Negative - general"
  11 = "11. Negative - too long"
  12 = "12. Negative - too complicated"
  13 = "13. Negative - boring/tedious/repetitious"
  15 = "15. R wanted to stop before interview completed. After"
  20 = "20. R complained and/or interviewer observed that R was"
  22 = "22. R complained and/or interviewer observed that R was"
  30 = "30. R expressed (especially repeatedly) doubts/apologies/"
  31 = "31. R expressed (especially repeatedly) doubts/apologies/"
  40 = "40. R was agitated or stressed by interview PROCESS"
  41 = "41. R became angry at interview CONTENT"
  45 = "45. R became concerned about sampling purpose or bias:"
  50 = "50. R could not read Respondent Booklet"
  70 = "70. R appeared to enjoy the interview (R was "cooperative""
;
VALUE V043413f  (MAX=60)
  10 = "10. Negative - general"
  11 = "11. Negative - too long"
  12 = "12. Negative - too complicated"
  13 = "13. Negative - boring/tedious/repetitious"
  15 = "15. R wanted to stop before interview completed. After"
  20 = "20. R complained and/or interviewer observed that R was"
  22 = "22. R complained and/or interviewer observed that R was"
  30 = "30. R expressed (especially repeatedly) doubts/apologies/"
  31 = "31. R expressed (especially repeatedly) doubts/apologies/"
  40 = "40. R was agitated or stressed by interview PROCESS"
  41 = "41. R became angry at interview CONTENT"
  45 = "45. R became concerned about sampling purpose or bias:"
  50 = "50. R could not read Respondent Booklet"
  70 = "70. R appeared to enjoy the interview (R was "cooperative""
;
VALUE V043413g  (MAX=60)
  10 = "10. Negative - general"
  11 = "11. Negative - too long"
  12 = "12. Negative - too complicated"
  13 = "13. Negative - boring/tedious/repetitious"
  15 = "15. R wanted to stop before interview completed. After"
  20 = "20. R complained and/or interviewer observed that R was"
  22 = "22. R complained and/or interviewer observed that R was"
  30 = "30. R expressed (especially repeatedly) doubts/apologies/"
  31 = "31. R expressed (especially repeatedly) doubts/apologies/"
  40 = "40. R was agitated or stressed by interview PROCESS"
  41 = "41. R became angry at interview CONTENT"
  45 = "45. R became concerned about sampling purpose or bias:"
  50 = "50. R could not read Respondent Booklet"
  70 = "70. R appeared to enjoy the interview (R was "cooperative""
;
VALUE V044001f (MAX=60)
  1 = "1. Standard turnout format; Pre patriotism questions"
  2 = "2. Experimental turnout format; Pre patriotism questions"
  3 = "3. Standard turnout format; Post patriotism questions"
  4 = "4. Experimental turnout format; Post patriotism question"
;
VALUE V044002f (MAX=60)
  11 = "11. November"
  12 = "12. December"
  00 = "00. NA"
;
VALUE V044003f (MAX=60)
  00 = "00. NA"
;
VALUE V044005f (MAX=60)
  1 = "1. October 29, 2004 version"
;
VALUE V044006f (MAX=60)
  11 = "11. November"
  12 = "12. December"
  00 = "00. NA"
;
VALUE V044007f (MAX=60)
  00 = "00. NA"
;
VALUE V044009f (MAX=60)
  1 = "1. October 29, 2004 version"
;
VALUE V044010a (MAX=60)
  0 = "0. NA"
;
VALUE V044010b (MAX=60)
  0 = "0. NA"
;
VALUE V044011f (MAX=60)
  1 = "1. IW conducted in 1 session"
  2 = "2. IW conducted in 2 sessions"
  3 = "3. IW conducted in 3 sessions"
  4 = "4. IW conducted in 4 sessions"
  0 = "0. NA"
;
VALUE V044012f (MAX=60)
  0 = "0. Post IW conducted using a single version of the instrumen"
  1 = "1. Post IW conducted using more than a single version"
  9 = "9. NA"
;
VALUE V044013f (MAX=60)
  1 = "1. One interviewer conducted the entire interview"
  2 = "2. Two interviewers conducted the interview"
  0 = "0. NA"
;
VALUE V044015a (MAX=60)
  1 =  "1. October 29, 2004 version"
;
VALUE V044015b (MAX=60)
  1 =  "1. October 29, 2004 version"
;
VALUE V044015c (MAX=60)
  1 =  "1. October 29, 2004 version"
;
VALUE V044016a (MAX=60)
  00 = "00. Interview completed in 1 session"
  01 = "01. Media module (A1-A8)"
  02 = "02. 1st budget module (E5-E5c)"
  03 = "03. Liberal-conservative scales (G4-G4a1)"
  04 = "04. Interventionism (G6-G6g)"
  05 = "05. Abortion  (G7a-G7c)"
  06 = "06. Office recognition of political figures (J7-J7d1)"
  07 = "07. 1st  sexism module (K4a-K4c)"
  08 = "08. Children's traits (N1-N1d)"
  09 = "09. Stereotypes (P4-P6d)"
  10 = "10. CSES module (Q1-Q28)"
;
VALUE V044016b (MAX=60)
  00 = "00. Interview completed in 1 session"
  01 = "01. Media module (A1-A8)"
  02 = "02. 1st budget module (E5-E5c)"
  03 = "03. Liberal-conservative scales (G4-G4a1)"
  04 = "04. Interventionism (G6-G6g)"
  05 = "05. Abortion  (G7a-G7c)"
  06 = "06. Office recognition of political figures (J7-J7d1)"
  07 = "07. 1st  sexism module (K4a-K4c)"
  08 = "08. Children's traits (N1-N1d)"
  09 = "09. Stereotypes (P4-P6d)"
  10 = "10. CSES module (Q1-Q28)"
;
VALUE V044021f (MAX=60)
  0 = "0. Not a refusal conversion situation"
  1 = "1. Refusal conversion"
;
VALUE V044023f (MAX=60)
  1 = "1. All interviews conducted face-to-face"
;
VALUE V044024f (MAX=60)
  1001 = "1001. Completed interview"
  5001 = "5001. Final refusal by respondent"
  5002 = "5002. Final refusal, not by respondent"
  5005 = "5005. Refusal, conversion not attempted"
  6002 = "6002. Final no contact"
  6003 = "6003. Interview begun, not resumed"
  6004 = "6004. Non-interview, permanent condition"
  6007 = "6007. Non-interview, other reason"
;
VALUE V044025f (MAX=60)
  000 = "000.00 NA"
;
VALUE V044026f (MAX=60)
  1 = "1. All interviews were conducted in English"
;
VALUE V044027f (MAX=60)
  0 = "0. Not selected for verification"
  2 = "2. Verified, no inconsistencies"
  3 = "3. Verified with discrepancies"
  4 = "4. Failed verification"
  5 = "5. Unable to verify (unable to contact respondent)"
  6 = "6. Verification limit met (used when the case if flagged for"
;
VALUE V044028f (MAX=60)
  0 = "0. Not flagged for evaluation"
  1 = "1. Flagged for evaluation; not evaluated"
  2 = "2. Evaluated"
;
VALUE V044029f (MAX=60)
  1 = "1. Yes, tape-recorded"
  5 = "5. No"
;
VALUE V044030f (MAX=60)
  20 = "20. $20"
  50 = "50. $50"
;
VALUE V044031f (MAX=60)
  00 = "00. Respondent refused payment"
  20 = "20. $20"
  50 = "50. $50"
  99 = "99. NA"
;
VALUE V044033f (MAX=60)
  1 = "1. All respondents paid by check"
;
VALUE V044034f (MAX=60)
  0 = "0. No Post-election incentive"
;
VALUE V044035f (MAX=60)
  0 = "0. Persuasion letters not tracked"
;
VALUE V044036a  (MAX=60)
  0 = "0. Positive comment not coded at any call"
  1 = "1. Positive comment coded for at least one call"
;
VALUE V044036b  (MAX=60)
  0 = "0. Time-delay comment not coded at any call"
  1 = "1. Time-delay comment coded for at least one call"
;
VALUE V044036c  (MAX=60)
  0 = "0. Negative comment not coded at any call"
  1 = "1. Negative comment coded for at least one call"
;
VALUE V044036d  (MAX=60)
  0 = "0. Eligibility comment not coded at any call"
  1 = "1. Eligibility comment coded for at least one call"
;
VALUE V044036e  (MAX=60)
  0 = "0. Privacy comment not coded at any call"
  1 = "1. Privacy comment coded for at least one call"
;
VALUE V044036f  (MAX=60)
  0 = "0. Political disinterest comment not coded at any call"
  1 = "1. Political disinterest comment coded for at least one call"
;
VALUE V044037a  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037b  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037c  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037d  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037e  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037f  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037g  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037h  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037j  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037k  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037m  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037n  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037p  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037q  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037r  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037s  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037t  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037u  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037v  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037w  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044037y  (MAX=60)
  1 = "1. Coded at 1 or more calls"
  5 = "5. Not coded"
;
VALUE V044038f (MAX=60)
  0 = "0. Respondent did not initially refuse"
  1 = "1. Respondent initial refusal"
;
VALUE V044039f (MAX=60)
  0 = "0. Informant did not initially refuse"
  1 = "1. Informant initial refusal"
;
VALUE V044201f (MAX=60)
  0 = "0. No errors in the Post-election instrument"
;
VALUE V044401f (MAX=60)
  1 = "1. John Kerry thermometer administered first (D1b)"
  2 = "2. Ralph Nader thermometer administered first (D1c)"
;
VALUE V044402a (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
;
VALUE V044402b (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
;
VALUE V044402c (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
;
VALUE V044402d (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
;
VALUE V044403a (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
;
VALUE V044403b (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
;
VALUE V044403c (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
;
VALUE V044403d (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
;
VALUE V044403e (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
;
VALUE V044403f (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
;
VALUE V044406a (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
  8 = "8. Administered 8th"
  9 = "9. Administered 9th"
;
VALUE V044406b (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
  8 = "8. Administered 8th"
  9 = "9. Administered 9th"
;
VALUE V044406c (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
  8 = "8. Administered 8th"
  9 = "9. Administered 9th"
;
VALUE V044406d (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
  8 = "8. Administered 8th"
  9 = "9. Administered 9th"
;
VALUE V044406e (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
  8 = "8. Administered 8th"
  9 = "9. Administered 9th"
;
VALUE V044406f (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
  8 = "8. Administered 8th"
  9 = "9. Administered 9th"
;
VALUE V044406g (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
  8 = "8. Administered 8th"
  9 = "9. Administered 9th"
;
VALUE V044406h (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
  8 = "8. Administered 8th"
  9 = "9. Administered 9th"
;
VALUE V044406j (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
  4 = "4. Administered 4th"
  5 = "5. Administered 5th"
  6 = "6. Administered 6th"
  7 = "7. Administered 7th"
  8 = "8. Administered 8th"
  9 = "9. Administered 9th"
;
VALUE V044407f (MAX=60)
  1 = "1. Democratic House candidate placement administered first ("
  2 = "2. Republican House candidate placement administered first ("
;
VALUE V044408f (MAX=60)
  1 = "1. Democratic House candidate placement administered first"
  2 = "2. Republican House candidate placement administered first"
;
VALUE V044409f (MAX=60)
  1 = "1. George Bush placement administered first (G6b)"
  2 = "2. John Kerry placement administered first (G6c)"
;
VALUE V044410f (MAX=60)
  1 = "1. Democratic House candidate placement administered first"
  2 = "2. Republican House candidate placement administered first"
;
VALUE V044411f (MAX=60)
  1 = "1. Democratic party placement administered first (G6f)"
  2 = "2. Republican party placement administered first (G6g)"
;
VALUE V044412f (MAX=60)
  1 = "1. George Bush placement administered first (G7b)"
  2 = "2. John Kerry placement administered first (G7c)"
;
VALUE V044413f (MAX=60)
  1 = "1. Democratic House candidate placement administered first"
  2 = "2. Republican House candidate placement administered first"
;
VALUE V044414f (MAX=60)
  1 = "1. Democratic party  placement administered first (G7f)"
  2 = "2. Republican party  placement administered first (G7g)"
;
VALUE V044415a (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
;
VALUE V044415b (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
;
VALUE V044415c (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
;
VALUE V044416a (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
;
VALUE V044416b (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
;
VALUE V044416c (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
;
VALUE V044417a (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
;
VALUE V044417b (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
;
VALUE V044417c (MAX=60)
  1 = "1. Administered 1st"
  2 = "2. Administered 2nd"
  3 = "3. Administered 3rd"
;
VALUE V044502f (MAX=60)
  12 = "12. Democratic incumbent running - Republican challenger"
  13 = "13. Democratic incumbent running - other challenger"
  14 = "14. Democratic incumbent running - unopposed"
  19 = "19. Democratic incumbent running - Repub and other challenge"
  21 = "21. Republican incumbent running - Democratic challenger"
  23 = "23. Republican incumbent running - other challenger"
  24 = "24. Republican incumbent running - unopposed"
  29 = "29. Republican incumbent running - Dem and other challengers"
  31 = "31. Other incumbent running - Democratic challenger"
  32 = "32. Other incumbent running - Republican challenger"
  34 = "34. Other incumbent running - unopposed"
  35 = "35. Other incumbent running - Democratic, Republican challen"
  36 = "36. Other incumbent running -- Republican and other challeng"
  37 = "37. Other incumbent running -- Democratic and other challeng"
  39 = "39. Other incumbent running -- Democr, Republ, other challen"
  40 = "40. Democratic and Republican incumbents running - no other "
  41 = "41. 2 Democratic incumbents running - no other candidate"
  42 = "42. 2 Republican incumbents running - no other candidate"
  43 = "43. Dem and Repub incumbents running - other candidate(s)"
  44 = "44. Democratic non-incumbent only - no retiree/unclear who i"
  45 = "45. Republican non-incumbent only - no retiree/unclear who i"
  46 = "46. Democratic and Republican cands - no retiree/unclear who"
  47 = "47. Democratic and other cands - no retiree/unclear who is"
  48 = "48. Republican and other cands - no retiree/unclear who is "
  49 = "49. Democratic, Republican, other cands - no retiree/unclear"
  51 = "51. Dem incumbent not running -- Democratic candidate unoppo"
  52 = "52. Dem incumbent not running -- Republican candidate unoppo"
  53 = "53. Dem incumbent not running -- other candidate unopposed"
  55 = "55. Dem incumbent not running -- Democratic and Republican c"
  56 = "56. Dem incumbent not running -- Republican and other cands"
  57 = "57. Dem incumbent not running -- Democratic and other cands"
  59 = "59. Dem incumbent not running -- Democr, Republ, other cands"
  61 = "61. Rep incumbent not running -- Democratic candidate unoppo"
  62 = "62. Rep incumbent not running -- Republican candidate unoppo"
  63 = "63. Rep incumbent not running -- other candidate unopposed"
  65 = "65. Rep incumbent not running -- Democratic and Republican c"
  66 = "66. Rep incumbent not running -- Republican and other cands"
  67 = "67. Rep incumbent not running -- Democratic and other cands"
  69 = "69. Rep incumbent not running -- Democr, Republ, other cands"
  71 = "71. Other incumbent not running -- Democratic cand unopposed"
  72 = "72. Other incumbent not running -- Republican cand unopposed"
  73 = "73. Other incumbent not running -- other candidate unopposed"
  75 = "75. Other incumbent not running -- Democratic, Republican ca"
  76 = "76. Other incumbent not running -- Republican and other cand"
  77 = "77. Other incumbent not running -- Democratic and other cand"
  79 = "79. Other incumbent not running -- Democr, Republ, other can"
  91 = "91. Rep incumbent not running -Democratic and 2 Republican c"
  92 = "92. Rep incumbent not running -Republican and 2 Democratic c"
  93 = "93. Dem incumbent not running -Democratic and 2 Republican c"
  94 = "94. Dem incumbent not running -Republican and 2 Democratic c"
;
VALUE V044503b (MAX=60)
  31 = "31.  Democratic candidate in open House race"
  33 = "33.  Democratic House running incumbent"
  35 = "35.  Democratic House challenger"
;
VALUE V044503c (MAX=60)
  1 = "1. Male"
  2 = "2. Female"
;
VALUE V044504b (MAX=60)
  32 = "32.  Republican candidate in open House race"
  34 = "34.  Republican House running incumbent"
  36 = "36.  Republican House challenger"
;
VALUE V044504c (MAX=60)
  1 = "1. Male"
  2 = "2. Female"
;
VALUE V044505b (MAX=60)
  37 = "37.  Independent/3rd-party House candidate -  nonincumbent"
  38 = "38.  Independent/3rd-party House candidate  - 2nd nonincumen"
  39 = "39.  Independent/3rd-party House incumbent"
;
VALUE V044505c (MAX=60)
  1 = "1. Male"
  2 = "2. Female"
;
VALUE V044506b (MAX=60)
  41 = "41. Retiring Democratic House Representative"
  42 = "42. Retiring Republican House Representative"
  43 = "43. Retiring Independent/3rd-Party House Representative"
;
VALUE V044506c (MAX=60)
  1 = "1. Male"
  2 = "2. Female"
;
VALUE V044507f (MAX=60)
  12 = "12. Democratic incumbent running - Republican challenger"
  13 = "13. Democratic incumbent running - other challenger"
  14 = "14. Democratic incumbent running - unopposed"
  19 = "19. Democratic incumbent running - Repub and other challenge"
  21 = "21. Republican incumbent running - Democratic challenger"
  23 = "23. Republican incumbent running - other challenger"
  24 = "24. Republican incumbent running - unopposed"
  29 = "29. Republican incumbent running - Dem and other challengers"
  31 = "31. Other incumbent running - Democratic challenger"
  32 = "32. Other incumbent running - Republican challenger"
  34 = "34. Other incumbent running - unopposed"
  35 = "35. Other incumbent running - Democratic, Republican challen"
  36 = "36. Other incumbent running -- Republican and other challeng"
  37 = "37. Other incumbent running -- Democratic and other challeng"
  39 = "39. Other incumbent running -- Democr, Republ, other challen"
  51 = "51. Dem incumbent not running -- Democratic candidate unoppo"
  52 = "52. Dem incumbent not running -- Republican candidate unoppo"
  53 = "53. Dem incumbent not running -- other candidate unopposed"
  55 = "55. Dem incumbent not running -- Democratic and Republican c"
  56 = "56. Dem incumbent not running -- Republican and other cands"
  57 = "57. Dem incumbent not running -- Democratic and other cands"
  59 = "59. Dem incumbent not running -- Democr, Republ, other cands"
  61 = "61. Rep incumbent not running -- Democratic candidate unoppo"
  62 = "62. Rep incumbent not running -- Republican candidate unoppo"
  63 = "63. Rep incumbent not running -- other candidate unopposed"
  65 = "65. Rep incumbent not running -- Democratic and Republican c"
  66 = "66. Rep incumbent not running -- Republican and other cands"
  67 = "67. Rep incumbent not running -- Democratic and other cands"
  69 = "69. Rep incumbent not running -- Democr, Republ, other cands"
  71 = "71. Other incumbent not running --Democratic candidate unopp"
  72 = "72. Other incumbent not running --Republican candidate unopp"
  73 = "73. Other incumbent not running -- other candidate unopposed"
  75 = "75. Other incumbent not running -- Democratic, Republican ca"
  76 = "76. Other incumbent not running -- Republican and other cand"
  77 = "77. Other incumbent not running -- Democratic and other cand"
  79 = "79. Other incumbent not running -- Democr, Republ, other can"
  81 = "81. No race in state - Democratic incumbents"
  82 = "82. No race in state - Republican incumbents"
  85 = "85. No race in state - Democratic and Republican incumbents"
  87 = "87. No race in state - Democratic and other incumbent"
  88 = "88. No race in state - Republican and other incumbent"
;
VALUE V044508b (MAX=60)
  01 = "01. Democratic candidate in open Senate race"
  03 = "03. Democratic Senate running incumbent"
  05 = "05. Democratic Senate challenger"
;
VALUE V044508c (MAX=60)
  1 = "1. Male"
  2 = "2. Female"
;
VALUE V044509b (MAX=60)
  02 = "02. Republican candidate in open Senate race"
  04 = "04. Republican Senate running incumbent"
  06 = "06. Republican Senate challenger"
;
VALUE V044509c (MAX=60)
  1 = "1. Male"
  2 = "2. Female"
;
VALUE V044510b (MAX=60)
  07 = "07. Independent/3rd-party Senate candidate -  nonincumbent"
  08 = "08. Independent/3rd-party Senate candidate  - 2nd nonincumen"
  09 = "09. Independent/3rd-party Senate incumbent"
;
VALUE V044510c (MAX=60)
  1 = "1. Male"
  2 = "2. Female"
;
VALUE V044511b (MAX=60)
  11 = "11. Democratic Junior Senator"
  12 = "12. Republican Junior Senator"
  13 = "13. Independent/3rd-Party Junior Senator"
  17 = "17. Democratic Senior Senator"
  18 = "18. Republican Senior Senator"
  19 = "19. Independent/3rd Party Senior Senator"
;
VALUE V044511c (MAX=60)
  1 = "1. Male"
  2 = "2. Female"  
;
VALUE V044512b (MAX=60)
  17 = "17. Democratic Senior Senator"
  18 = "18. Republican Senior Senator"
  19 = "19. Independent/3rd Party Senior Senator"
;
VALUE V044512c (MAX=60)
  1 = "1. Male"
  2 = "2. Female"
;
VALUE V044513b (MAX=60)
  11 = "11. Democratic Junior Senator"
  12 = "12. Republican Junior Senator"
  13 = "13. Independent/3rd-Party Junior Senator"
;
VALUE V044513c (MAX=60)
  1 = "1. Male"    
  2 = "2. Female"
;
VALUE V044514a (MAX=60)
  1 = "1. Democratic candidate"
  5 = "5. Republican candidate"
  7 = "7. Independent/3rd-party candidate"
;
VALUE V044514b (MAX=60)
  31 = "31. Democratic House candidate in open race"
  32 = "32. Republican House candidate in open race"
  33 = "33. Democratic House incumbent"
  34 = "34. Republican House incumbent"
  35 = "35. Democratic House challenger"
  36 = "36. Republican House challenger"
  37 = "37. Non-incumbent independent/3rd-party House candidate"
  39 = "39. Incumbent independent/3rd-party House candidate"
;
VALUE V044516a (MAX=60)
  1 = "1. Democratic candidate"
  5 = "5. Republican candidate"
  7 = "7. Independent/3rd-party candidate"
;
VALUE V044516b (MAX=60)
  1 = "1. Democratic Senate candidate in open race"
  2 = "2. Republican Senate candidate in open race"
  3 = "3. Democratic Senate incumbent"
  4 = "4. Republican Senate incumbent"
  5 = "5. Democratic Senate challenger"
  6 = "6. Republican Senate challenger"
  7 = "7. Non-incumbent independent/3rd-party Senate candidate"
  9 = "9. Incumbent independent/3rd-party Senate candidate"
;
VALUE V045001f  (MAX=60)
 1 = "1. Very much interested"
 3 = "3. Somewhat interested"
 5 = "5. Not much interested"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045002f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045002a  (MAX=60)
 1 = "1. A good many"
 3 = "3. Several"
 5 = "5. Just one or two"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045003f  (MAX=60)
 0 = "0. None"
 1 = "1. One day"
 2 = "2. Two days"
 3 = "3. Three days"
 4 = "4. Four days"
 5 = "5. Five days"
 6 = "6. Six days"
 7 = "7. Every day"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045003a  (MAX=60)
 1 = "1. A great deal"
 2 = "2. Quite a bit"
 3 = "3. Some"
 4 = "4. Very little"
 5 = "5. None"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045004f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045004a  (MAX=60)
 1 = "1. A great deal"
 2 = "2. Quite a bit"
 3 = "3. Some"
 4 = "4. Very little"
 5 = "5. None"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045005f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045005a  (MAX=60)
 1 = "1. A good many"
 3 = "3. Several"
 5 = "5. Just one or two"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045006f  (MAX=60)
 1 = "1. A great deal"
 2 = "2. Quite a bit"
 3 = "3. Some"
 4 = "4. Very little"
 5 = "5. None"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045007f  (MAX=60)
 1 = "1. Just about always"
 2 = "2. Most of the time"
 3 = "3. Only some of the time"
 4 = "4. Almost never"
 5 = "5. None of the time [VOL]"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045008f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045008a  (MAX=60)
 1 = "1. Democrats"
 5 = "5. Republicans"
 6 = "6. Both"
 7 = "7. Other {SPECIFY}"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045009f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045010f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045011f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045012f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045013f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045014f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045014a  (MAX=60)
 1 = "1. Democrats"
 3 = "3. Republicans"
 5 = "5. Other {SPECIFY}"
 6 = "6. Both Democratic candidate and Republican candidate {VOL}"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045015f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045015a  (MAX=60)
 1 = "1. Democrats"
 3 = "3. Republicans"
 5 = "5. Other {SPECIFY}"
 6 = "6. Both Democratics and Republicans"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045016f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045017a  (MAX=60)
 1 = "1. Yes, voted"
 5 = "5. No, didn't vote"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045017b  (MAX=60)
 1 = "1. I did not vote (in the election this November)."
 2 = "2. I thought about voting this time, but didn't."
 3 = "3. I usually vote, but didn't this time."
 4 = "4. I am sure I voted"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045018f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 6 = "6. VOL:  NOT REQUIRED TO REGISTER IN R'S STATE"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045018x  (MAX=60)
 1 = "1. R voter"
 2 = "2. R nonvoter - registered"
 3 = "3. R nonvoter - not registered"
 4 = "4. R nonvoter - DK/RF if registered"
 5 = "5. R nonvoter - not required to register"
 6 = "6. DK/RF if voter"
;
VALUE V045019f  (MAX=60)
 1 = "1. Yes, registered in preload county"
 5 = "5. No, registered in other county"
 7 = "7. R VOLUNTEERS: preload county is incorrect"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045019a  (MAX=60)
 88 = "88. Don't know"
 89 = "89. Refused"
;
VALUE V045019b  (MAX=60)
 88888 = "88888. Don't know"
 88889 = "88889. Refused"
;
VALUE V045020x  (MAX=60)
 1 = "1. Voter registered in preload county"
 2 = "2. Voter registered outside preload county"
 3 = "3. Voter- says preload county is incorrect"
 4 = "4. Voter - registration location is DK/RF"
 5 = "5. Nonvoter"
;
VALUE V045021x  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
;
VALUE V045022x  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 7 = "7. Not enough information to determine"
;
VALUE V045023f  (MAX=60)
 1 = "1. Election day"
 5 = "5. Some time before this"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045023a  (MAX=60)
 01 = "01. Less than one week, 1-6 days"
 02 = "02. One week; 7 days"
 03 = "03. 1-2 weeks; 8-14 days"
 04 = "04. 2-3 weeks; 15-21 days"
 05 = "05. 3-4 weeks; 22-28 days"
 06 = "06. One month; 29-31 days"
 07 = "07. More than one month; 32-60 days"
 11 = "11. A few days; a couple of days; several days -- NFS"
 12 = "12. A few weeks; a couple of weeks; several weeks -- NFS;"
 87 = "87. Other"
 88 = "88. Don't know"
 89 = "89. Refused"
;
VALUE V045024f  (MAX=60)
 1 = "1. In person"
 5 = "5. Absentee ballot"
 7 = "7. R VOLUNTEERS: BY MAIL {OREGON ONLY}"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045025f  (MAX=60)
 1 = "1. Yes, voted for President"
 5 = "5. No, didn't vote for President"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045026f  (MAX=60)
 1 = "1. John Kerry"
 3 = "3. George W. Bush"
 5 = "5. Ralph Nader"
 7 = "7. Other {SPECIFY}"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045026a  (MAX=60)
 1 = "1. Strong"
 5 = "5. Not strong"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045027f  (MAX=60)
 01 = "01. Knew all along/from the first; always vote for the"
 02 = "02. Before the convention because of Kerry's/ Bush's/"
 03 = "03. At the time of the Republican convention/ when Bush"
 04 = "04. During the Democratic convention when Kerry was"
 05 = "05. After the convention(s); during the campaign (NFS);"
 06 = "06. Five to seven weeks before the election"
 07 = "07. One month; three weeks; October; after the"
 08 = "08. About two weeks before the election; 'ten days'"
 09 = "09. In the last few days of the campaign; the last part"
 10 = "10. On election day"
 11 = "11. During/after the primaries (not codeable in 02);"
 87 = "87. Other"
 88 = "88. Don't know"
 89 = "89. Refused"
;
VALUE V045028f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045029f  (MAX=60)
 1 = "1. John Kerry"
 3 = "3. George W. Bush"
 5 = "5. Ralph Nader"
 7 = "7. Other {SPECIFY}"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045029a  (MAX=60)
 1 = "1. Strong"
 5 = "5. Not strong"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045030x  (MAX=60)
 1 = "1. Voter - in-county"
 2 = "2. Voter - not in-county"
 5 = "5. Nonvoter"
 7 = "7. Washington D.C. in-county"
;
VALUE V045031x  (MAX=60)
 1 = "1. Yes, voted for House of Representatives"
 5 = "5. No, didn't vote for House of Representatives"
 7 = "7. OUTSIDE DISTRICT - R VOLUNTEERS: voted in Washington DC"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045032x  (MAX=60)
 1 = "1. Democratic candidate"
 3 = "3. Republican candidate"
 5 = "5. Independent/third party candidate"
 7 = "7. Other candidate {SPECIFY}"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045033x  (MAX=60)
 31 = "31. Democratic candidate in open House race"
 32 = "32. Republican candidate in open House race"
 33 = "33. Democratic House running incumbent"
 34 = "34. Republican House running incumbent"
 35 = "35. Democratic House challenger"
 36 = "36. Republican House challenger"
 37 = "37. Independent/3rd party House candidate - nonincumbent"
 39 = "39. Independent/3rd party House candidate - incumbent"
 70 = "70. Third party or independent House candidate"
 71 = "71. Democratic candidate in open House race"
 72 = "72. Republican candidate in open House race"
 73 = "73. Democratic House incumbent"
 74 = "74. Republican House incumbent"
 75 = "75. Democratic House challenger"
 76 = "76. Republican House challenger"
 81 = "81. Democrat - no name given"
 82 = "82. Republican - no name given"
 87 = "87. IN COUNTY OF IW: Name not on candidate list;"
 88 = "88. Don't know"
 89 = "89. Refused"
;
VALUE V045034f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 7 = "7. R VOLUNTEERS: names are not correct for R's district"
 8 = "8. Don't know"
 9 = "9. Refused"
 0 = "0. NA"
;
VALUE V045035f  (MAX=60)
 1 = "1. Democratic candidate"
 3 = "3. Republican candidate"
 5 = "5. Independent/third party candidate"
 7 = "7. Other candidate {SPECIFY}"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045035x  (MAX=60)
 31 = "31. Democratic candidate in open House race"
 32 = "32. Republican candidate in open House race"
 33 = "33. Democratic House running incumbent"
 34 = "34. Republican House running incumbent"
 35 = "35. Democratic House challenger"
 36 = "36. Republican House challenger"
 37 = "37. Independent/3rd party House candidate - nonincumbent"
 39 = "39. Independent/3rd party House candidate - incumbent"
 87 = "87. Name not on candidate list"
 88 = "88. Don't know"
 89 = "89. Refused"
;
VALUE V045036x  (MAX=60)
 1 = "1. In-county voter, Senate race in state"
 2 = "2. In-county voter, no Senate race in state"
 3 = "3. Out-of-county voter, voted in state with race"
 4 = "4. Out-of-county voter, voted in state without race"
 5 = "5. Nonvoter - race in state"
 6 = "6. Nonvoter - no race in state"
;
VALUE V045037x  (MAX=60)
 1 = "1. Yes, voted for Senate"
 5 = "5. No, didn't vote for Senate"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045038x  (MAX=60)
 1 = "1. Democratic candidate"
 2 = "2. LOUISIANA ONLY: other democratic candidate"
 3 = "3. Republican candidate"
 5 = "5. Independent/third party candidate"
 7 = "7. Other candidate {SPECIFY}"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045039x  (MAX=60)
 01 = "01. Democratic candidate in open Senate race"
 02 = "02. Republican candidate in open Senate race"
 03 = "03. Democratic Senate running incumbent"
 04 = "04. Republican Senate running incumbent"
 05 = "05. Democratic Senate challenger"
 06 = "06. Republican Senate challenger"
 07 = "07. Independent/3rd-party Senate cand -  nonincumbent"
 08 = "08. Independent/3rd-party Senate cand  - 2nd nonincument"
 09 = "09. Independent/3rd-party Senate incumbent"
 70 = "70. Third party or independent House candidate"
 71 = "71. Democratic candidate in open House race"
 72 = "72. Republican candidate in open House race"
 73 = "73. Democratic House incumbent"
 74 = "74. Republican House incumbent"
 75 = "75. Democratic House challenger"
 76 = "76. Republican House challenger"
 81 = "81. Democrat - no name given"
 82 = "82. Republican - no name given"
 87 = "87. IN COUNTY OF IW: Name not on candidate list;"
 88 = "88. Don't know"
 89 = "89. Refused"
;
VALUE V045040f  (MAX=60)
 1 = "1. Yes"
 5 = "5. No"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045041f  (MAX=60)
 1 = "1. Democratic candidate"
 3 = "3. Republican candidate"
 5 = "5. Independent/third party candidate"
 7 = "7. Other candidate {SPECIFY}"
 8 = "8. Don't know"
 9 = "9. Refused"
;
VALUE V045041x  (MAX=60)
 01 = "01. Democratic candidate in open Senate race"
 02 = "02. Republican candidate in open Senate race"
 03 = "03. Democratic Senate running incumbent"
 04 = "04. Republican Senate running incumbent"
 05 = "05. Democratic Senate challenger"
 06 = "06. Republican Senate challenger"
 07 = "07. Independent/3rd-party Senate cand -  nonincumbent"
 08 = "08. Independent/3rd-party Senate cand  - 2nd nonincument"
 09 = "09. Independent/3rd-party Senate incumbent"
 87 = "87. Name not on candidate list"
 88 = "88. Don't know"
 89 = "89. Refused"
;
VALUE V045043f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045044f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045045f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045046f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045047f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045048f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045049f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045050f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045051f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045052f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045053f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045054f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045055f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045056f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045057f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045058f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045059f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045060f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045061f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045062f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045063f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045064f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045065f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045066f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045067f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045068f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045069f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045070f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045071f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045072f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045073f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045074f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045075f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045076f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045077f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045078f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045079f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045080f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045081f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045082f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045083f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045084f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045085f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045086f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045087f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045088f  (MAX=60)
 777 = "777. Don't recognize"
 888 = "888. Don't know where to rate"
 889 = "889. Refused"
;
VALUE V045089f (MAX=60)
  1 = "1. The Democrats"
  5 = "5. The Republicans"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045090f (MAX=60)
  1 = "1. The Democrats"
  5 = "5. The Republicans"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045091f (MAX=60)
  1 = "1. Democratic running incumbent"
  2 = "2. Republican running incumbent"
  3 = "3. Other running incumbent"
  4 = "4. Democratic retiring incumbent"
  5 = "5. Republican retiring incumbent"
  6 = "6. Other retiring incumbent"
  7 = "7. No identifiable incumbent or Washington DC"
;
VALUE V045092f (MAX=60)
  1 = "1. Approve"
  5 = "5. Disapprove"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045092a (MAX=60)
  1 = "1. Approve strongly"
  2 = "2. Approve not strongly"
  4 = "4. Disapprove not strongly"
  5 = "5. Disapprove strongly" 
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045093f (MAX=60)
  1 = "1. More than half"
  2 = "2. Half"
  3 = "3. Less than half"
  7 = "7. Don't know; not sure"
  9 = "9. Refused"
  0 = "0. No running House incumbent"
;
VALUE V045094f (MAX=60)
  1 = "1. Very good"
  2 = "2. Fairly good"
  3 = "3. Fairly poor"
  4 = "4. Very poor"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045095f (MAX=60)
  1 = "1. Most of the time"
  2 = "2. Some of the time"
  3 = "3. Only now and then"
  4 = "4. Hardly at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045096f (MAX=60)
  1 = "1. Yes, favor"
  5 = "5. No, don't favor"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045097f (MAX=60)
  1 = "1. Yes, favor"
  5 = "5. No, don't favor"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045098f (MAX=60)
  1 = "1. Yes, favor"
  5 = "5. No, don't favor"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045099f (MAX=60)
  1 = "1. Very important"
  3 = "3. Somewhat important"
  5 = "5. Not important at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045100f (MAX=60)
  1 = "1. Very important"
  3 = "3. Somewhat important"
  5 = "5. Not important at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045101f (MAX=60)
  1 = "1. Very important"
  3 = "3. Somewhat important"
  5 = "5. Not important at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045102f (MAX=60)
  1 = "1. Very important"
  3 = "3. Somewhat important"
  5 = "5. Not important at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045103f (MAX=60)
  1 = "1. Very important"
  3 = "3. Somewhat important"
  5 = "5. Not important at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045104f (MAX=60)
  1 = "1. Very important"
  3 = "3. Somewhat important"
  5 = "5. Not important at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045105f (MAX=60)
  1 = "1. Very important"
  3 = "3. Somewhat important"
  5 = "5. Not important at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045106f (MAX=60)
  1 = "1. Very important"
  3 = "3. Somewhat important"
  5 = "5. Not important at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045107f (MAX=60)
  1 = "1. Very important"
  3 = "3. Somewhat important"
  5 = "5. Not important at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045108f (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045109f (MAX=60)
  1 = "1. Yes, have interest in question"
  5 = "5. No, haven't had interest"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045109a (MAX=60)
  1 = "1. Government in Washington should see to it that"
  5 = "5. This is not the Federal government's business"
  7 = "7. Other {SPECIFY}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045109b (MAX=60)
  1 = "1. Feel govt should see to jobs - strongly"
  2 = "2. Feel govt should see to jobs - not strongly"
  4 = "4. Feel not govt business - not strongly"
  5 = "5. Feel not govt business - strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045110f (MAX=60)
  1 = "1. Yes, favor"
  5 = "5. No, don't favor"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045111f (MAX=60)
  1 = "1. Yes, favor"
  5 = "5. No, don't favor"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045112f (MAX=60)
  1 = "1. Yes, favor"
  5 = "5. No, don't favor"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045113f (MAX=60)
  1 = "1. Larger"
  3 = "3. Smaller"
  5 = "5. About the same"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045113a (MAX=60)
  1 = "1. Much larger"
  2 = "2. Somewhat larger"
  3 = "3. About the same"
  4 = "4. Somewhat smaller"
  5 = "5. Much smaller"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045113b (MAX=60)
  1 = "1. Good thing"
  3 = "3. Bad thing"
  7 = "7. Haven't thought"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045114f (MAX=60)
  1 = "1. Favor"
  5 = "5. Oppose"
  7 = "7. Haven't thought much about this"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045115f (MAX=60)
  1 = "1. Increased a lot"
  2 = "2. Increased a little"
  3 = "3. Left the same as it is now"
  4 = "4. Decreased a little"
  5 = "5. Decreased a lot"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045116f (MAX=60)
  1 = "1. Extremely likely"
  2 = "2. Very likely"
  3 = "3. Somewhat likely"
  4 = "4. Not at all likely"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045117f (MAX=60)
  01 = "01. Extremely liberal"
  02 = "02. Liberal"
  03 = "03. Slightly liberal"
  04 = "04. Moderate; middle of the road"
  05 = "05. Slightly conservative"
  06 = "06. Conservative"
  07 = "07. Extremely conservative"
  80 = "80. Haven't thought much {DO NOT PROBE}"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045117a (MAX=60)
  1 = "1. Liberal"
  3 = "3. Conservative"
  5 = "5. Moderate"
  7 = "7. R Refused to choose"
  8 = "8. Don't know"
;
VALUE V045118f (MAX=60)
  1 = "1. Liberal"
  3 = "3. Conservative"
  5 = "5. Moderate"
  7 = "7. R Refused to choose"
  8 = "8. Don't know"
;
VALUE V045119f (MAX=60)
  1 = "1. Extremely liberal"
  2 = "2. Liberal"
  3 = "3. Slightly liberal"
  4 = "4. Moderate; middle of the road"
  5 = "5. Slightly conservative"
  6 = "6. Conservative"
  7 = "7. Extremely conservative"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V045120f (MAX=60)
  1 = "1. Extremely liberal"
  2 = "2. Liberal"
  3 = "3. Slightly liberal"
  4 = "4. Moderate; middle of the road"
  5 = "5. Slightly conservative"
  6 = "6. Conservative"
  7 = "7. Extremely conservative"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045121f (MAX=60)
  01 = "01. Govt should provide many fewer services"
  07 = "07. Govt should provide many more services"
  80 = "80. Haven't thought much about this"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045122f (MAX=60)
  1 = "1. Govt should provide many fewer services"
  7 = "7. Govt should provide many more services"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V045123f (MAX=60)
  1 = "1. Govt should provide many fewer services"
  7 = "7. Govt should provide many more services"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045124f (MAX=60)
  01 = "01. Should solve with diplomacy"
  07 = "07. Must be ready to use military force"
  80 = "80. Haven't thought much about this"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045125f (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not too important"
  5 = "5. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045126f (MAX=60)
  1 = "1. Should solve with diplomacy"
  7 = "7. Must be ready to use military force"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045127f (MAX=60)
  1 = "1. Should solve with diplomacy"
  7 = "7. Must be ready to use military force"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045128f (MAX=60)
  1 = "1. Should solve with diplomacy"
  7 = "7. Must be ready to use military force"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V045129f (MAX=60)
  1 = "1. Should solve with diplomacy"
  7 = "7. Must be ready to use military force"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045130f (MAX=60)
  1 = "1. Should solve with diplomacy"
  7 = "7. Must be ready to use military force"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045131f (MAX=60)
  1 = "1. Should solve with diplomacy"
  7 = "7. Must be ready to use military force"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045132f (MAX=60)
  1 = "1. By law, abortion should never be permitted"
  2 = "2. The law should permit abortion only in case of rape, ince"
  3 = "3. The law should permit abortion for reasons other than rap"
  4 = "4. By law, a woman should always be able to obtain an aborti"
  7 = "7. Other {SPECIFY} {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045133f (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not too important"
  5 = "5. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045134f (MAX=60)
  1 = "1. By law, abortion should never be permitted"
  2 = "2. The law should permit abortion only in case of rape, ince"
  3 = "3. The law should permit abortion for reasons other than rap"
  4 = "4. By law, a woman should always be able to obtain an aborti"
  7 = "7. Other {SPECIFY} {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045135f (MAX=60)
  1 = "1. By law, abortion should never be permitted"
  2 = "2. The law should permit abortion only in case of rape, ince"
  3 = "3. The law should permit abortion for reasons other than rap"
  4 = "4. By law, a woman should always be able to obtain an aborti"
  7 = "7. Other {SPECIFY} {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045136f (MAX=60)
  1 = "1. By law, abortion should never be permitted"
  2 = "2. The law should permit abortion only in case of rape, ince"
  3 = "3. The law should permit abortion for reasons other than rap"
  4 = "4. By law, a woman should always be able to obtain an aborti"
  7 = "7. Other {SPECIFY} {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V045137f (MAX=60)
  1 = "1. By law, abortion should never be permitted"
  2 = "2. The law should permit abortion only in case of rape, ince"
  3 = "3. The law should permit abortion for reasons other than rap"
  4 = "4. By law, a woman should always be able to obtain an aborti"
  7 = "7. Other {SPECIFY} {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045138f (MAX=60)
  1 = "1. By law, abortion should never be permitted"
  2 = "2. The law should permit abortion only in case of rape, ince"
  3 = "3. The law should permit abortion for reasons other than rap"
  4 = "4. By law, a woman should always be able to obtain an aborti"
  7 = "7. Other {SPECIFY} {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045139f (MAX=60)
  1 = "1. By law, abortion should never be permitted"
  2 = "2. The law should permit abortion only in case of rape, ince"
  3 = "3. The law should permit abortion for reasons other than rap"
  4 = "4. By law, a woman should always be able to obtain an aborti"
  7 = "7. Other {SPECIFY} {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045140f (MAX=60)
  01 = "01. Govt should help Hispanics"
  07 = "07. Should help themselves"
  80 = "80. Haven't thought much about it"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045141f (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not too important"
  5 = "5. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045142f (MAX=60)
  1 = "1. Discourage companies"
  3 = "3. Encourage companies"
  5 = "5. Should stay out of this matter"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045142a (MAX=60)
  1 = "1. A great deal"
  5 = "5. Only a little"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045143f (MAX=60)
  1 = "1. Favor"
  5 = "5. Oppose"
  7 = "7. Neither favor nor oppose"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045143a (MAX=60)
  1 = "1. Favor strongly"
  2 = "2. Favor not strongly"
  4 = "4. Oppose not strongly"
  5 = "5. Oppose strongly "
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045143b (MAX=60)
  1 = "1. Favor strongly"
  2 = "2. Favor not strongly"
  3 = "3. Lead toward favoring"
  4 = "4. Don't lean either way"
  5 = "5. Lean toward opposing"
  6 = "6. Oppose not strongly"
  7 = "7. Oppose strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045144f (MAX=60)
  1 = "1. Favor"
  5 = "5. Oppose"
  7 = "7. Neither/depends/other {VOL} {SPECIFY}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045144a (MAX=60)
  1 = "1. Favor strongly"
  2 = "2. Favor not strongly"
  4 = "4. Oppose not strongly"
  5 = "5. Oppose strongly "
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045145f (MAX=60)
  1 = "1. Extremely good"
  2 = "2. Very good"
  3 = "3. Somewhat good"
  4 = "4. Not very good"
  7 = "7. Don't feel anything {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045145x (MAX=60)
  1 = "1. Extremely good"
  2 = "2. Very good"
  3 = "3. Somewhat good"
  4 = "4. Not very good"
  7 = "7. Don't feel anything {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045146f (MAX=60)
  1 = "1. Agree"
  3 = "3. Neither agree nor disagree"
  5 = "5. Disagree"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045146x (MAX=60)
  1 = "1. Agree"
  3 = "3. Neither agree nor disagree"
  5 = "5. Disagree"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045147f (MAX=60)
  1 = "1. Agree"
  3 = "3. Neither agree nor disagree"
  5 = "5. Disagree"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045147x (MAX=60)
  1 = "1. Agree"
  3 = "3. Neither agree nor disagree"
  5 = "5. Disagree"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045148f (MAX=60)
  1 = "1. Extremely strong"
  2 = "2. Very strong"
  4 = "4. Somewhat strong"
  5 = "5. Not Very strong"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045148x (MAX=60)
  1 = "1. Extremely strong"
  2 = "2. Very strong"
  4 = "4. Somewhat strong"
  5 = "5. Not Very strong"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045149f (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not too important"
  5 = "5. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045149x (MAX=60)
  1 = "1. Extremely important"
  2 = "2. Very important"
  3 = "3. Somewhat important"
  4 = "4. Not too important"
  5 = "5. Not at all important"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045150f (MAX=60)
  1 = "1. Gov't bigger because it's involved in things people sho"
  2 = "2. Gov't bigger because problems bigger"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045151f (MAX=60)
  1 = "1. Need a strong gov't to handle complex economic problems"
  2 = "2. Free market can handle without gov't involvement"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045152f (MAX=60)
  1 = "1. The less government the better"
  2 = "2. More things government should be doing"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045153f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045153a (MAX=60)
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045154f (MAX=60)
  1 = "1. Yes, listen"
  5 = "5. No, don't listen"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045155f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045155a (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045156f (MAX=60)
  1 = "1. Favor"
  5 = "5. Oppose"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045156a (MAX=60)
  1 = "1. Favor strongly"
  2 = "2. Favor not strongly"
  4 = "4. Oppose not strongly"
  5 = "5. Oppose strongly "
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045157f (MAX=60)
  1 = "1. Homosexuals should be allowed to serve"
  5 = "5. Homosexuals should not be allowed to serve"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045157a (MAX=60)
  1 = "1. Feel homosexuals should be allowed - strongly"
  2 = "2. Feel homosexuals should be allowed - not strongly"
  4 = "4. Feel homosexuals should not be allowed - not strongly"
  5 = "5. Feel homosexuals should not be allowed - strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045158f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045159f (MAX=60)
  1 = "1. Yes, differences"
  5 = "5. No, no differences"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045160f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045160a (MAX=60)
  1 = "1. Democrats"
  5 = "5. Republicans"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045161f (MAX=60)
  1 = "1. Yes, have interest"
  5 = "5. No, don't have interest"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045161a (MAX=60)
  1 = "1. Govt should see to it"
  5 = "5. Not the Federal govt's business"
  7 = "7. Other {SPECIFY}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045161b (MAX=60)
  1 = "1. Feel govt should see to jobs - strongly"
  2 = "2. Feel govt should see to jobs - not strongly"
  4 = "4. Feel not govt business - not strongly"
  5 = "5. Feel not govt business - strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045162f (MAX=60)
  1 = "1. Correctly identifies as Speaker of the House"
  5 = "5. Identification is incomplete or wrong"
  8 = "8. R makes no attempt to guess"
  9 = "9. Refused"
;
VALUE V045162a (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
;
VALUE V045163f (MAX=60)
  1 = "1. Correctly identifies as Vice_President of the U.S."
  5 = "5. Identification is incomplete or wrong"
  8 = "8. R makes no attempt to guess"
  9 = "9. Refused"
;
VALUE V045163a (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
;
VALUE V045164f (MAX=60)
  1 = "1. Correctly identifies as Prime Minister of England/"
  5 = "5. Identification is incomplete or wrong"
  8 = "8. R makes no attempt to guess"
  9 = "9. Refused"
;
VALUE V045164a (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
;
VALUE V045165f (MAX=60)
  1 = "1. Correctly identifies as Chief Justice of the Supreme"
  5 = "5. Identification is incomplete or wrong"
  8 = "8. R makes no attempt to guess"
  9 = "9. Refused"
;
VALUE V045165a (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
;
VALUE V045166f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045167f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045168f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045169f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045170f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045170a (MAX=60)
  0 = "0.    No organizations"
  1 = "1. One organization"
  97 = "97.   97 or more organizations"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045171f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045172f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045173f (MAX=60)
  001 = "001. Female only"
  002 = "002. Black only"
  003 = "003. Hispanic only"
  012 = "012. Female and black"
  013 = "013. Female and Hispanic"
  023 = "023. Black and Hispanic"
  123 = "123. Female, black and Hispanic"
  000 = "000. Not female, black or Hispanic"
;
VALUE V045174f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  7 = "7. Depends {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V045174a (MAX=60)
  1 = "1. A lot"
  3 = "3. Some"
  5 = "5. Not very much at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045175f (MAX=60)
  1 = "1. A lot"
  2 = "2. Fairly often"
  3 = "3. Once in a while"
  4 = "4. Hardly ever"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V045176f (MAX=60)
  1 = "1. A lot"
  2 = "2. Fairly often"
  3 = "3. Once in a while"
  4 = "4. Hardly ever"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V045177f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  7 = "7. Depends {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V045177a (MAX=60)
  1 = "1. A lot"
  3 = "3. Some"
  5 = "5. Not very much at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045178f (MAX=60)
  1 = "1. A lot"
  2 = "2. Fairly often"
  3 = "3. Once in a while"
  4 = "4. Hardly ever"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V045179f (MAX=60)
  1 = "1. A lot"
  2 = "2. Fairly often"
  3 = "3. Once in a while"
  4 = "4. Hardly ever"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"  
;
VALUE V045180f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  7 = "7. Depends {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V045180a (MAX=60)
  1 = "1. A lot"
  3 = "3. Some"
  5 = "5. Not very much at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045181f (MAX=60)
  1 = "1. A lot"
  2 = "2. Fairly often"
  3 = "3. Once in a while"
  4 = "4. Hardly ever"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V045182f (MAX=60)
  1 = "1. A lot"
  2 = "2. Fairly often"
  3 = "3. Once in a while"
  4 = "4. Hardly ever"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V045183f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree Somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree Somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045184f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree Somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree Somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045185f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree Somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree Somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045186f (MAX=60)
  1 = "1. Most people can be trusted"
  5 = "5. Can't be too careful"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045187f (MAX=60)
  1 = "1. Take advantage"
  5 = "5. Try to be fair"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045188f (MAX=60)
  1 = "1. Try to be helpful"
  5 = "5. Just looking out for themselves"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045189f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045190f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045191f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045192f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045193f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045194f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045195f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045196f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045197f (MAX=60)
  1 = "1. Just about always"
  2 = "2. Most of the time"
  3 = "3. Only some of the time"
  4 = "4. Never {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045198f (MAX=60)
  1 = "1. Gov't run by a few big interests"
  5 = "5. Gov't run for the benefit of all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045199f (MAX=60)
  1 = "1. Waste a lot"
  3 = "3. Waste some"
  5 = "5. Don't waste very much"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045200f (MAX=60)
  1 = "1. Quite a few are crooked"
  3 = "3. Not very many are crooked"
  5 = "5. Hardly any are crooked"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045201f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045202f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045203f (MAX=60)
  1 = "1. A good deal"
  3 = "3. Some"
  5 = "5. Not much"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045204f (MAX=60)
  1 = "1. A good deal"
  3 = "3. Some"
  5 = "5. Not much"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045205f (MAX=60)
  1 = "1. Agree"
  3 = "3. Neither agree nor disagree"
  5 = "5. Disagree"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045206f (MAX=60)
  1 = "1. Agree"
  3 = "3. Neither agree nor disagree"
  5 = "5. Disagree"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045207f (MAX=60)
  1 = "1. For preferential hiring and promotion of blacks"
  5 = "5. Against preferential hiring and promotion of blacks"
  7 = "7. Other {SPECIFY}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045207a (MAX=60)
  1 = "1. Favor strongly"
  2 = "2. Favor not strongly"
  4 = "4. Oppose not strongly"
  5 = "5. Oppose strongly "
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045208f (MAX=60)
  1 = "1. Independence"
  3 = "3. Both {VOL}"
  5 = "5. Respect for elders"
  7 = "7. Neither {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045209f (MAX=60)
  1 = "1. Curiosity"
  3 = "3. Both {VOL}"
  5 = "5. Good manners"
  7 = "7. Neither {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045210f (MAX=60)
  1 = "1. Obedience"
  3 = "3. Both {VOL}"
  5 = "5. Self-reliance"
  7 = "7. Neither {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045211f (MAX=60)
  1 = "1. Being considerate"
  3 = "3. Both {VOL}"
  5 = "5. Well behaved"
  7 = "7. Neither {VOL}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045212f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045213f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045214f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045215f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045216f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045217f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree somewhat"
  3 = "3. Neither agree nor disagree"
  4 = "4. Disagree somewhat"
  5 = "5. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045218f (MAX=60)
  1 = "1. Almost everything"
  2 = "2. Many things"
  3 = "3. Some things"
  4 = "4. Very few things"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045219f (MAX=60)
  1 = "1. Fewer opinions"
  3 = "3. About the same number of opinions"
  5 = "5. More opinions"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045219a (MAX=60)
  1 = "1. A lot fewer opinions"
  2 = "2. Somewhat fewer opinions"
  3 = "3. About the same number of opinions"
  4 = "4. Somewhat more opinions"
  5 = "5. A lot more opinions"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045220f (MAX=60)
  1 = "1. Like"
  3 = "3. Dislike"
  5 = "5. Neither like nor dislike"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045220a (MAX=60)
  1 = "1. Like it  lot"
  2 = "2. Like it somewhat"
  3 = "3. Neither like nor dislike it"
  4 = "4. Dislike it somewhat"
  5 = "5. Dislike it a lot"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045221f (MAX=60)
  1 = "1. Simple"
  5 = "5. Complex"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045222f (MAX=60)
  1 = "1. Hard-working"
  7 = "7. Lazy"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045223f (MAX=60)
  1 = "1. Hard-working"
  7 = "7. Lazy"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045224f (MAX=60)
  1 = "1. Hard-working"
  7 = "7. Lazy"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045225f (MAX=60)
  1 = "1. Hard-working"
  7 = "7. Lazy"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045226f (MAX=60)
  1 = "1. Intelligent"
  7 = "7. Unintelligent"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045227f (MAX=60)
  1 = "1. Intelligent"
  7 = "7. Unintelligent"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045228f (MAX=60)
  1 = "1. Intelligent"
  7 = "7. Unintelligent"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045229f (MAX=60)
  1 = "1. Intelligent"
  7 = "7. Unintelligent"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045230f (MAX=60)
  1 = "1. Trustworthy"
  7 = "7. Untrustworthy"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045231f (MAX=60)
  1 = "1. Trustworthy"
  7 = "7. Untrustworthy"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045232f (MAX=60)
  1 = "1. Trustworthy"
  7 = "7. Untrustworthy"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045233f (MAX=60)
  1 = "1. Trustworthy"
  7 = "7. Untrustworthy"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045235f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045235a (MAX=60)
  1 = "1. Frequently"
  2 = "2. Occasionally"
  3 = "3. Rarely"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045236f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045236a (MAX=60)
  1 = "1. Frequently"
  2 = "2. Occasionally"
  3 = "3. Rarely"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045237f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045238f (MAX=60)
  995 = "995. 'There were no issues'; 'there were no issues, just"
  996 = "996. 'There was no campaign in my district'"
  998 = "998. DK"
  999 = "999. NA"
  000 = "000. No problems mentioned"
;
VALUE V045239f (MAX=60)
  1 = "1. Very good job"
  2 = "2. Good job"
  3 = "3. Bad job"
  4 = "4. Very bad job"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045240f (MAX=60)
  1 = "1. Very good job"
  2 = "2. Good job"
  3 = "3. Bad job"
  4 = "4. Very bad job"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045241f (MAX=60)
  1 = "1. Very satisfied"
  2 = "2. Fairly satisfied"
  3 = "3. Not very satisfied"
  4 = "4. Not at all satisfied"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045242f (MAX=60)
  1 = "1. It makes a difference who is in power"
  5 = "5. It doesn't make a difference who is in power"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045243f (MAX=60)
  1 = "1. Who people vote for won't make a difference"
  5 = "5. Who people vote for can make a difference"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045244f (MAX=60)
  1 = "1. Agree strongly"
  2 = "2. Agree"
  3 = "3. Disagree"
  4 = "4. Disagree strongly"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045245f (MAX=60)
  1 = "1. R voted for Democratic presidential candidate"
  3 = "3. R voted for Republican presidential candidate"
  5 = "5. R voted for Reform party presidential candidate"
  6 = "6. R voted for other candidate - party identified"
  7 = "7. R voted for other candidate - party not identified"
  8 = "8. Don't know who voted for (8 in C6a)"
  9 = "9. Refused (9 in C6a)"
;
VALUE V045246f (MAX=60)
  1 = "1. Very good job"
  2 = "2. Good job"
  3 = "3. Bad job"
  4 = "4. Very bad job"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045247f (MAX=60)
  1 = "1. Very well"
  2 = "2. Quite well"
  3 = "3. Not very well"
  4 = "4. Not well at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045248f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045248a (MAX=60)
  1 = "1. Democratic"
  5 = "5. Republican"
  7 = "7. Other {SPECIFY}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045249f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045249a (MAX=60)
  1 = "1. George W. Bush"
  3 = "3. John Kerry"
  5 = "5. Ralph Nader"
  7 = "7. Other {SPECIFY}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045250f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045250a (MAX=60)
  1 = "1. Democratic"
  3 = "3. Republican"
  5 = "5. Reform party"
  7 = "7. Other {SPECIFY}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045250b (MAX=60)
  1 = "1. Democratic"
  3 = "3. Republican"
  5 = "5. Reform party"
  7 = "7. Other {SPECIFY}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045251f (MAX=60)
  0 = "0. No party mentioned as close, or not determined"
  1 = "1. One party mentioned"
  2 = "2. Two or more parties mentioned"
  8 = "8. Interviewer error: no mentions coded as 1 or 2 mentions"
;
VALUE V045252f (MAX=60)
  1 = "1. Democratic"
  5 = "5. Republican"
  7 = "7. Other {SPECIFY}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045253f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
  0 = "0. NA"
;
VALUE V045253a (MAX=60)
  1 = "1. Democratic"
  5 = "5. Republican"
  7 = "7. Other {SPECIFY}"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045255f (MAX=60)
  1 = "1. Very close"
  2 = "2. Somewhat close"
  3 = "3. Not very close"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045257f (MAX=60)
  00 = "00. Strongly dislike"
  10 = "10. Strongly like"
  87 = "87. Haven't heard of"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045258f (MAX=60)
  00 = "00. Strongly dislike"
  10 = "10. Strongly like"
  87 = "87. Haven't heard of"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045259f (MAX=60)
  00 = "00. Strongly dislike"
  10 = "10. Strongly like"
  87 = "87. Haven't heard of"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045260f (MAX=60)
  00 = "00. Left"
  10 = "10. Right"
  87 = "87. Haven't heard of"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045261f (MAX=60)
  00 = "00. Left"
  10 = "10. Right"
  87 = "87. Haven't heard of"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045262f (MAX=60)
  00 = "00. Left"
  10 = "10. Right"
  87 = "87. Haven't heard of"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045263f (MAX=60)
  00 = "00. Left"
  10 = "10. Right"
  87 = "87. Haven't heard of"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045264f (MAX=60)
  00 = "00. Left"
  10 = "10. Right"
  87 = "87. Haven't heard of"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045265f (MAX=60)
  00 = "00. Left"
  10 = "10. Right"
  87 = "87. Haven't heard of"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045266f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045267f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045268f (MAX=60)
  1 = "1. Yes"
  5 = "5. No"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045269f (MAX=60)
  1 = "1. A lot of respect for individual freedom"
  2 = "2. Some respect"
  3 = "3. Not much respect"
  4 = "4. No respect at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045270f (MAX=60)
  1 = "1. Very widespread"
  2 = "2. Quite widespread"
  3 = "3. Not very widespread"
  4 = "4. It hardly happens at all"
  8 = "8. Don't know"
  9 = "9. Refused"
;
VALUE V045271f (MAX=60)
  00 = "00. Left"
  10 = "10. Right"
  88 = "88. Don't know"
  89 = "89. Refused"
;
VALUE V045300a  (MAX=60)
  0 = "0. No indication"
  1 = "1. Indicated"
;
VALUE V045300b  (MAX=60)
  0 = "0. No indication"
  1 = "1. Indicated"
;
VALUE V045301a  (MAX=60)
  1 = "1. Marked"
  5 = "5. Not marked"
  0 = "0. NA"
;
VALUE V045301b  (MAX=60)
  1 = "1. Marked"
  5 = "5. Not marked"
  0 = "0. NA"
;
VALUE V045301c  (MAX=60)
  1 = "1. Marked"
  5 = "5. Not marked"
  0 = "0. NA"
;
VALUE V045301d  (MAX=60)
  1 = "1. Marked"
  5 = "5. Not marked"
  0 = "0. NA"
;
VALUE V045301e  (MAX=60)
  1 = "1. Marked"
  5 = "5. Not marked"
  0 = "0. NA"
;
VALUE V045301f  (MAX=60)
  1 = "1. Marked"
  5 = "5. Not marked"
  0 = "0. NA"
;
VALUE V045302f  (MAX=60)
  1 = "1. Very good"
  2 = "2. Good"
  3 = "3. Fair"
  4 = "4. Poor"
  5 = "5. Very poor"
  0 = "0. NA"
;
VALUE V045303f  (MAX=60)
  1 = "1. Very high"
  2 = "2. Fairly high"
  3 = "3. Acerage"
  4 = "4. Fairly low"
  5 = "5. Very low"
  0 = "0. NA"
;
VALUE V045304f  (MAX=60)
  1 = "1. Very high"
  2 = "2. Fairly high"
  3 = "3. Acerage"
  4 = "4. Fairly low"
  5 = "5. Very low"
  0 = "0. NA"
;
VALUE V045305f  (MAX=60)
  1 = "1. Not at all suspicious"
  2 = "2. Somewhat suspicious"
  3 = "3. Very suspicious"
  0 = "0. NA"
;
VALUE V045306f  (MAX=60)
  1 = "1. Very high"
  2 = "2. Fairly high"
  3 = "3. Average"
  4 = "4. Fairly low"
  5 = "5. Very low"
  0 = "0. NA"
;
VALUE V045307f  (MAX=60)
  1 = "1. Completely sincere"
  2 = "2. Usually sincere"
  3 = "3. Often seemed to be insincere"
  0 = "0. NA"
;
VALUE V045307a  (MAX=60)
  1 = "1. Yes {SPECIFY}"
  5 = "5. No"
;
VALUE V045308a  (MAX=60)
  10 = "10. Negative - general"
  11 = "11. Negative - too long"
  12 = "12. Negative - too complicated"
  13 = "13. Negative - boring/tedious/repetitious"
  15 = "15. R wanted to stop before interview completed. After"
  20 = "20. R complained and/or interviewer observed that R was"
  22 = "22. R complained and/or interviewer observed that R was"
  30 = "30. R expressed (especially repeatedly) doubts/apologies/"
  31 = "31. R expressed (especially repeatedly) doubts/apologies/"
  40 = "40. R was agitated or stressed by interview PROCESS"
  41 = "41. R became angry at interview CONTENT"
  45 = "45. R became concerned about sampling purpose or bias:"
  50 = "50. R could not read Respondent Booklet"
  70 = "70. R appeared to enjoy the interview (R was 'cooperative"
  80 = "80. Neutral or no feedback (1st mention only"
  00 = "00. NA"
;
VALUE V045308b  (MAX=60)
  10 = "10. Negative - general"
  11 = "11. Negative - too long"
  12 = "12. Negative - too complicated"
  13 = "13. Negative - boring/tedious/repetitious"
  15 = "15. R wanted to stop before interview completed. After"
  20 = "20. R complained and/or interviewer observed that R was"
  22 = "22. R complained and/or interviewer observed that R was"
  30 = "30. R expressed (especially repeatedly) doubts/apologies/"
  31 = "31. R expressed (especially repeatedly) doubts/apologies/"
  40 = "40. R was agitated or stressed by interview PROCESS"
  41 = "41. R became angry at interview CONTENT"
  45 = "45. R became concerned about sampling purpose or bias:"
  50 = "50. R could not read Respondent Booklet"
  70 = "70. R appeared to enjoy the interview (R was 'cooperative"
;
VALUE V045308c  (MAX=60)
  10 = "10. Negative - general"
  11 = "11. Negative - too long"
  12 = "12. Negative - too complicated"
  13 = "13. Negative - boring/tedious/repetitious"
  15 = "15. R wanted to stop before interview completed. After"
  20 = "20. R complained and/or interviewer observed that R was"
  22 = "22. R complained and/or interviewer observed that R was"
  30 = "30. R expressed (especially repeatedly) doubts/apologies/"
  31 = "31. R expressed (especially repeatedly) doubts/apologies/"
  40 = "40. R was agitated or stressed by interview PROCESS"
  41 = "41. R became angry at interview CONTENT"
  45 = "45. R became concerned about sampling purpose or bias:"
  50 = "50. R could not read Respondent Booklet"
  70 = "70. R appeared to enjoy the interview (R was 'cooperative"
;
VALUE V045308d  (MAX=60)
  10 = "10. Negative - general"
  11 = "11. Negative - too long"
  12 = "12. Negative - too complicated"
  13 = "13. Negative - boring/tedious/repetitious"
  15 = "15. R wanted to stop before interview completed. After"
  20 = "20. R complained and/or interviewer observed that R was"
  22 = "22. R complained and/or interviewer observed that R was"
  30 = "30. R expressed (especially repeatedly) doubts/apologies/"
  31 = "31. R expressed (especially repeatedly) doubts/apologies/"
  40 = "40. R was agitated or stressed by interview PROCESS"
  41 = "41. R became angry at interview CONTENT"
  45 = "45. R became concerned about sampling purpose or bias:"
  50 = "50. R could not read Respondent Booklet"
  70 = "70. R appeared to enjoy the interview (R was 'cooperative"
;
VALUE V045308e  (MAX=60)
  10 = "10. Negative - general"
  11 = "11. Negative - too long"
  12 = "12. Negative - too complicated"
  13 = "13. Negative - boring/tedious/repetitious"
  15 = "15. R wanted to stop before interview completed. After"
  20 = "20. R complained and/or interviewer observed that R was"
  22 = "22. R complained and/or interviewer observed that R was"
  30 = "30. R expressed (especially repeatedly) doubts/apologies/"
  31 = "31. R expressed (especially repeatedly) doubts/apologies/"
  40 = "40. R was agitated or stressed by interview PROCESS"
  41 = "41. R became angry at interview CONTENT"
  45 = "45. R became concerned about sampling purpose or bias:"
  50 = "50. R could not read Respondent Booklet"
  70 = "70. R appeared to enjoy the interview (R was 'cooperative"
;
VALUE V045308f  (MAX=60)
  10 = "10. Negative - general"
  11 = "11. Negative - too long"
  12 = "12. Negative - too complicated"
  13 = "13. Negative - boring/tedious/repetitious"
  15 = "15. R wanted to stop before interview completed. After"
  20 = "20. R complained and/or interviewer observed that R was"
  22 = "22. R complained and/or interviewer observed that R was"
  30 = "30. R expressed (especially repeatedly) doubts/apologies/"
  31 = "31. R expressed (especially repeatedly) doubts/apologies/"
  40 = "40. R was agitated or stressed by interview PROCESS"
  41 = "41. R became angry at interview CONTENT"
  45 = "45. R became concerned about sampling purpose or bias:"
  50 = "50. R could not read Respondent Booklet"
  70 = "70. R appeared to enjoy the interview (R was 'cooperative"
;
VALUE V045308g  (MAX=60)
  10 = "10. Negative - general"
  11 = "11. Negative - too long"
  12 = "12. Negative - too complicated"
  13 = "13. Negative - boring/tedious/repetitious"
  15 = "15. R wanted to stop before interview completed. After"
  20 = "20. R complained and/or interviewer observed that R was"
  22 = "22. R complained and/or interviewer observed that R was"
  30 = "30. R expressed (especially repeatedly) doubts/apologies/"
  31 = "31. R expressed (especially repeatedly) doubts/apologies/"
  40 = "40. R was agitated or stressed by interview PROCESS"
  41 = "41. R became angry at interview CONTENT"
  45 = "45. R became concerned about sampling purpose or bias:"
  50 = "50. R could not read Respondent Booklet"
  70 = "70. R appeared to enjoy the interview (R was 'cooperative"
;
 run;
