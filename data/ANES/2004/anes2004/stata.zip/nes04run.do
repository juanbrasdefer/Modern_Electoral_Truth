/*  FILE nes04run.do                                                     */
/*  -----------------                                                    */ 
/*  2004 American National Election Study (2004.T)                       */
/*  STATA run file                                                       */
/*  VERSION 20050816 (Aug 16, 2005)                                      */

/*  This 'run' file can be used to read into STATA the raw ASCII data    */
/*  file for the 2004 NES Release file.                                  */

/*  If you have downloaded and decompressed the 2004 NES                 */
/*  'zip' file into a directory such as C:\ANES\nes2004\20050816, you    */
/*  should be able to run this file without modification to produce a    */
/*  STATA system file.                                                   */

/*  Running this file should successfully create a STATA system file     */
/*  named "nes04.dta" in directory "C:\ANES\nes2004\20050816\".          */


/* NOTE: missing data assignments are commented out but can be restored  */
/* by removing the asterisk (*) on the relevant lines in the run setup   */
/* below.                                                                */


set memory 65m
set more off
     

infix using c:\anes\nes2004\20050816\nes04col.dct
do c:\anes\nes2004\20050816\nes04lab.do 
do c:\anes\nes2004\20050816\nes04fmt.do
do c:\anes\nes2004\20050816\nes04cod.do
*do c:\anes\nes2004\20050816\nes04md.do

save c:\anes\nes2004\20050816\nes04.dta

