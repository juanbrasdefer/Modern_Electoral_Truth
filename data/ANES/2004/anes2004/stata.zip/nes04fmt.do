
label define V041001f    0   "0. Pre-election interview only" , add
label define V041001f    1   "1. Both Pre-election and Post-election interviews" , add
label define V041101f    1   "1. One person in HH" , add
label define V041101f    2   "2. Two persons in HH" , add
label define V041101f    3   "3. Three persons in HH" , add
label define V041101f    4   "4. Four persons in HH" , add
label define V041101f    5   "5. Five persons in HH" , add
label define V041101f    6   "6. Six persons in HH" , add
label define V041101f    7   "7. Seven persons in HH" , add
label define V041101f    8   "8. Eight persons in HH" , add
label define V041101f    9   "9. Nine persons in HH" , add
label define V041102f    1   "1. One adult in HH" , add
label define V041102f    2   "2. Two adults in HH" , add
label define V041102f    3   "3. Three adults in HH" , add
label define V041102f    4   "4. Four adults in HH" , add
label define V041102f    5   "5. Five adults in HH" , add
label define V041102f    6   "6. Six adults in HH" , add
label define V041102a    1   "1. One eligible adult in HH" , add
label define V041102a    2   "2. Two eligible adults in HH" , add
label define V041102a    3   "3. Three eligible adults in HH" , add
label define V041102a    4   "4. Four eligible adults in HH" , add
label define V041102a    5   "5. Five eligible adults in HH" , add
label define V041102a    6   "6. Six eligible adults in HH" , add
label define V041102b    0   "0. No ineligible adult in HH" , add
label define V041102b    1   "1. One ineligible adult in HH" , add
label define V041102b    2   "2. Two ineligible adults in HH" , add
label define V041102b    3   "3. Three ineligible adults in HH" , add
label define V041102b    4   "4. Four ineligible adults in HH" , add
label define V041102c    0   "0. No female adult in HH" , add
label define V041102c    1   "1. One female adult in HH" , add
label define V041102c    2   "2. Two female adults in HH" , add
label define V041102c    3   "3. Three female adults in HH" , add
label define V041102c    4   "4. Four female adults in HH" , add
label define V041103f    0   "0. No children in HH" , add
label define V041103f    1   "1. One child in HH" , add
label define V041103f    2   "2. Two children in HH" , add
label define V041103f    3   "3. Three children in HH" , add
label define V041103f    4   "4. Four children in HH" , add
label define V041103f    5   "5. Five children in HH" , add
label define V041103f    6   "6. Six children in HH" , add
label define V041103f    7   "7. Seven children in HH" , add
label define V041104f    0   "0. No female children in HH" , add
label define V041104f    1   "1. One female child in HH" , add
label define V041104f    2   "2. Two female children in HH" , add
label define V041104f    3   "3. Three female children in HH" , add
label define V041104f    4   "4. Four female children in HH" , add
label define V041104f    5   "5. Five female children in HH" , add
label define V041104f    6   "6. Six female children in HH" , add
label define V041104f    7   "7. Seven female children in HH" , add
label define V041105f    0   "0. No child in HH under 5 years old" , add
label define V041105f    1   "1. One child in HH under 5 years old" , add
label define V041105f    2   "2. Two children in HH under 5 years old" , add
label define V041105f    3   "3. Three children in HH under 5 years old" , add
label define V041106f    0   "0. No child in HH age 5-9" , add
label define V041106f    1   "1. One child in HH age 5-9" , add
label define V041106f    2   "2. Two children in HH age 5-9" , add
label define V041106f    3   "3. Three children in HH age 5-9" , add
label define V041107f    0   "0. No child in HH age 10-13" , add
label define V041107f    1   "1. One child in HH age 10-13" , add
label define V041107f    2   "2. Two children in HH age 10-13" , add
label define V041107f    3   "3. Three children in HH age 10-13" , add
label define V041107f    4   "4. Four children in HH age 10-13" , add
label define V041108f    0   "0. No child in HH age 14-17" , add
label define V041108f    1   "1. One child in HH age 14-17" , add
label define V041108f    2   "2. Two children in HH age 14-17" , add
label define V041108f    3   "3. Three children in HH age 14-17" , add
label define V041109f    1   "1. R is person number 1 (1st person in HH listing)" , add
label define V041109f    2   "2. R is person number 2 (2nd person in HH listing)" , add
label define V041109f    3   "3. R is person number 3 (3rd person in HH listing)" , add
label define V041109f    4   "4. R is person number 4 (4th person in HH listing)" , add
label define V041109f    5   "5. R is person number 5 (5th person in HH listing)" , add
label define V041109f    6   "6. R is person number 6 (6th person in HH listing)" , add
label define V041109f    7   "7. R is person number 7 (7th person in HH listing)" , add
label define V041109f    8   "8. R is person number 8 (8th person in HH listing)" , add
label define V041109a    1   "1. Male" , add
label define V041109a    2   "2. Female" , add
label define V041109b    1    "01. Self" , add
label define V041109b    2    "02. Wife/female partner" , add
label define V041109b    3    "03. Husband/male partner" , add
label define V041109b    4    "04. Mother" , add
label define V041109b    5    "05. Father" , add
label define V041109b    6    "06. Sister" , add
label define V041109b    7    "07. Brother" , add
label define V041109b    8    "08. Daughter" , add
label define V041109b    9    "09. Son" , add
label define V041109b    10   "10. Grandmother" , add
label define V041109b    11   "11. Grandfather" , add
label define V041109b    12   "12. Roommate" , add
label define V041109b    13   "13. Niece" , add
label define V041109b    14   "14. Nephew" , add
label define V041109b    15   "15. Aunt" , add
label define V041109b    16   "16. Uncle" , add
label define V041109b    17   "17. Granddaughter" , add
label define V041109b    18   "18. Grandson" , add
label define V041109b    19   "19. Mother-in-law/mother of partner" , add
label define V041109b    20   "20. Father-in-law/father of partner" , add
label define V041109b    21   "21. Daughter-in-law" , add
label define V041109b    22   "22. Son-in-law" , add
label define V041109b    23   "23. Sister-in-law" , add
label define V041109b    24   "24. Brother-in-law" , add
label define V041109b    25   "25. Live-in careperson" , add
label define V041109b    26   "26. Other {SPECIFY}" , add
label define V041109c    0   "0. No child in HH is (step)son/daughter of R" , add
label define V041109c    1   "1. 1 child in HH is (step)son/daughter of R" , add
label define V041109c    2   "2. 2 children in HH are (step)sons/daughters of R" , add
label define V041109c    3   "3. 3 children in HH are (step)sons/daughters of R" , add
label define V041109c    4   "4. 4 children in HH are (step)sons/daughters of R" , add
label define V041109c    5   "5. 5 children in HH are (step)sons/daughters of R" , add
label define V041109c    6   "6. 6 children in HH are (step)sons/daughters of R" , add
label define V041109d    0   "0. No child in HH is (step)daughter of R" , add
label define V041109d    1   "1. 1 child in HH is (step)daughter of R" , add
label define V041109d    2   "2. 2 children in HH are (step)daughters of R" , add
label define V041109d    3   "3. 3 children in HH are (step)daughters of R" , add
label define V041109d    4   "4. 4 children in HH are (step)daughters of R" , add
label define V041109d    5   "5. 5 children in HH are (step)daughters of R" , add
label define V041109d    6   "6. 6 children in HH are (step)daughters of R" , add
label define V041110f    10   "10. 1 adult male HHR" , add
label define V041110f    11   "11. 1 adult male HHR plus 1 adult non-relative" , add
label define V041110f    12   "12. 1 adult male HHR plus 2 or more adult non-relatives" , add
label define V041110f    20   "20. 1 adult female HHR" , add
label define V041110f    21   "21. 1 adult female HHR plus 1 adult non-relative" , add
label define V041110f    22   "22. 1 adult female HHR plus 2 or more adult non-relatives" , add
label define V041110f    30   "30. 1 married couple: no children or all children living at" , add
label define V041110f    40   "40. 1 married couple plus 1 other adult relative" , add
label define V041110f    50   "50. 1 married couple plus 2 or more other adult relatives" , add
label define V041110f    51   "51. 1 married couple plus 1 adult non-relative" , add
label define V041110f    52   "52. 1 married couple plus 2 or more adult non-relatives" , add
label define V041110f    55   "55. 1 married couple plus relative(s) and non-relative(s)" , add
label define V041110f    60   "60. 1 adult male HHR plus 1 adult relative" , add
label define V041110f    70   "70. 1 adult male HHR plus 2 or more adult relatives" , add
label define V041110f    75   "75. 1 adult male HHR plus relative(s) and non-relative(s)" , add
label define V041110f    80   "80. 1 adult female HHR plus 1 adult relative" , add
label define V041110f    90   "90. 1 adult female HHR plus 2 or more relatives" , add
label define V041110f    95   "95. 1 adult female HHR plus relative(s) and non-relative(s)" , add
label define V041111b    1   "1. Male" , add
label define V041111b    5   "5. Female" , add
label define V041111b    0   "0. NA" , add
label define V041111a    00   "00. NA" , add
label define V041112b    1   "1. Male" , add
label define V041112b    5   "5. Female" , add
label define V041112b    0   "0. NA" , add
label define V041112a    00   "00. NA" , add
label define V041113b    1   "1. Male" , add
label define V041113b    5   "5. Female" , add
label define V041113b    0   "0. NA" , add
label define V041113a    00   "00. NA" , add
label define V041114b    1   "1. Male" , add
label define V041114b    5   "5. Female" , add
label define V041114b    0   "0. NA" , add
label define V041114a    00   "00. NA" , add
label define V041115b    1   "1. Male" , add
label define V041115b    5   "5. Female" , add
label define V041115b    0   "0. NA" , add
label define V041115a    00   "00. NA" , add
label define V041116b    1   "1. Male" , add
label define V041116b    5   "5. Female" , add
label define V041116b    0   "0. NA" , add
label define V041116a    00   "00. NA" , add
label define V041202f    01   "01. Alabama" , add
label define V041202f    02   "02. Alaska" , add
label define V041202f    04   "04. Arizona" , add
label define V041202f    05   "05. Arkansas" , add
label define V041202f    06   "06. California" , add
label define V041202f    08   "08. Colorado" , add
label define V041202f    09   "09. Connecticut" , add
label define V041202f    10   "10. Delaware" , add
label define V041202f    11   "11. Washington DC" , add
label define V041202f    12   "12. Florida" , add
label define V041202f    13   "13. Georgia" , add
label define V041202f    15   "15. Hawaii" , add
label define V041202f    16   "16. Idaho" , add
label define V041202f    17   "17. Illinois" , add
label define V041202f    18   "18. Indiana" , add
label define V041202f    19   "19. Iowa" , add
label define V041202f    20   "20. Kansas" , add
label define V041202f    21   "21. Kentucky" , add
label define V041202f    22   "22. Louisiana" , add
label define V041202f    23   "23. Maine" , add
label define V041202f    24   "24. Maryland" , add
label define V041202f    25   "25. Massachusetts" , add
label define V041202f    26   "26. Michigan" , add
label define V041202f    27   "27. Minnesota" , add
label define V041202f    28   "28. Mississippi" , add
label define V041202f    29   "29. Missouri" , add
label define V041202f    30   "30. Montana" , add
label define V041202f    31   "31. Nebraska" , add
label define V041202f    32   "32. Nevada" , add
label define V041202f    33   "33. New Hampshire" , add
label define V041202f    34   "34. New Jersey" , add
label define V041202f    35   "35. New Mexico" , add
label define V041202f    36   "36. New York" , add
label define V041202f    37   "37. North Carolina" , add
label define V041202f    38   "38. North Dakota" , add
label define V041202f    39   "39. Ohio" , add
label define V041202f    40   "40. Oklahoma" , add
label define V041202f    41   "41. Oregon" , add
label define V041202f    42   "42. Pennsylvania" , add
label define V041202f    44   "44. Rhode Island" , add
label define V041202f    45   "45. South Carolina" , add
label define V041202f    46   "46. South Dakota" , add
label define V041202f    47   "47. Tennessee" , add
label define V041202f    48   "48. Texas" , add
label define V041202f    49   "49. Utah" , add
label define V041202f    50   "50. Vermont" , add
label define V041202f    51   "51. Virginia" , add
label define V041202f    53   "53. Washington" , add
label define V041202f    54   "54. West Virginia" , add
label define V041202f    55   "55. Wisconsin" , add
label define V041202f    56   "56. Wyoming" , add
label define V041203f    01   "01. Connecticut" , add
label define V041203f    02   "02. Maine" , add
label define V041203f    03   "03. Massachusetts" , add
label define V041203f    04   "04. New Hampshire" , add
label define V041203f    05   "05. Rhode Island" , add
label define V041203f    06   "06. Vermont" , add
label define V041203f    11   "11. Delaware" , add
label define V041203f    12   "12. New Jersey" , add
label define V041203f    13   "13. New York" , add
label define V041203f    14   "14. Pennsylvania" , add
label define V041203f    21   "21. Illinois" , add
label define V041203f    22   "22. Indiana" , add
label define V041203f    23   "23. Michigan" , add
label define V041203f    24   "24. Ohio" , add
label define V041203f    25   "25. Wisconsin" , add
label define V041203f    31   "31. Iowa" , add
label define V041203f    32   "32. Kansas" , add
label define V041203f    33   "33. Minnesota" , add
label define V041203f    34   "34. Missouri" , add
label define V041203f    35   "35. Nebraska" , add
label define V041203f    36   "36. North Dakota" , add
label define V041203f    37   "37. South Dakota" , add
label define V041203f    40   "40. Virginia" , add
label define V041203f    41   "41. Alabama" , add
label define V041203f    42   "42. Arkansas" , add
label define V041203f    43   "43. Florida" , add
label define V041203f    44   "44. Georgia" , add
label define V041203f    45   "45. Louisiana" , add
label define V041203f    46   "46. Mississippi" , add
label define V041203f    47   "47. North Carolina" , add
label define V041203f    48   "48. South Carolina" , add
label define V041203f    49   "49. Texas" , add
label define V041203f    51   "51. Kentucky" , add
label define V041203f    52   "52. Maryland" , add
label define V041203f    53   "53. Oklahoma" , add
label define V041203f    54   "54. Tennessee" , add
label define V041203f    55   "55. Washington DC" , add
label define V041203f    56   "56. West Virginia" , add
label define V041203f    61   "61. Arizona" , add
label define V041203f    62   "62. Colorado" , add
label define V041203f    63   "63. Idaho" , add
label define V041203f    64   "64. Montana" , add
label define V041203f    65   "65. Nevada" , add
label define V041203f    66   "66. New Mexico" , add
label define V041203f    67   "67. Utah" , add
label define V041203f    68   "68. Wyoming" , add
label define V041203f    71   "71. California" , add
label define V041203f    72   "72. Oregon" , add
label define V041203f    73   "73. Washington" , add
label define V041203f    81   "81. Alaska" , add
label define V041203f    82   "82. Hawaii" , add
label define V041205f   1   "1. Northeast (CT,ME,MA,NH,NJ,NY,PA,RI,VT)" , add
label define V041205f   2   "2. North Central (IL,IN,IA,KS,MI,MN,MO,NE,ND,OH,SD,WI)" , add
label define V041205f   3   "3. South (AL,AR,DE,DC,FL,GA,KY,LA,MD,MS,NC,OK,SC,TN,TX,VA,WV)" , add
label define V041205f   4   "4. West (AK,AZ,CA,CO,HI,ID,MT,NM,NV,OR,UT,WA,WY)" , add
label define V041213f   1   "1. Rural" , add
label define V041213f   5   "5. Urban" , add
label define V042001f   1   "1. A10 Pre and Pre patriotism module" , add
label define V042001f   2   "2. A11 Pre and Pre patriotism module" , add
label define V042001f   3   "3. A10 Pre and Post patriotism module" , add
label define V042001f   4   "4. A11 Pre and Post patriotism module" , add
label define V042002f   09   "09. September" , add
label define V042002f   10   "10. October" , add
label define V042002f   11   "11. November" , add
label define V042002f   00   "00. NA" , add
label define V042003f   00   "00. NA" , add
label define V042005f   1   "1. September 2, 2004 version" , add
label define V042005f   2   "2. September 8, 2004 version" , add
label define V042005f   3   "3. September 16, 2004 version" , add
label define V042005f   4   "4. September 29, 2004 version" , add
label define V042005f   0   "0. NA" , add
label define V042006f   09   "09. September" , add
label define V042006f   10   "10. October" , add
label define V042006f   11   "11. November" , add
label define V042006f   00   "00. NA" , add
label define V042007f   00   "00. NA" , add
label define V042009f   1   "1. September 2, 2004 version" , add
label define V042009f   2   "2. September 8, 2004 version" , add
label define V042009f   3   "3. September 16, 2004 version" , add
label define V042009f   4   "4. September 29, 2004 version" , add
label define V042009f   0   "0. NA" , add
label define V042010a   0   "0. NA" , add
label define V042010b   0   "0. NA" , add
label define V042011f   1   "1. IW conducted in 1 session" , add
label define V042011f   2   "2. IW conducted in 2 sessions" , add
label define V042011f   3   "3. IW conducted in 3 sessions" , add
label define V042011f   4   "4. IW conducted in 4 sessions" , add
label define V042011f   0   "0. NA" , add
label define V042012f   0   "0. Pre IW conducted using a single version of the instrument" , add
label define V042012f   1   "1. Pre IW conducted using more than a single version" , add
label define V042012f   9   "9. NA" , add
label define V042013f   1   "1. One interviewer conducted the entire interview" , add
label define V042013f   2   "2. Two interviewers conducted the interview" , add
label define V042013f   0   "0. NA" , add
label define V042015a   1   "1. September 2, 2004 version" , add
label define V042015a   2   "2. September 8, 2004 version" , add
label define V042015a   3   "3. September 16, 2004 version" , add
label define V042015a   4   "4. September 29, 2004 version" , add
label define V042015a   0   "0. NA" , add
label define V042015b   1   "1. September 2, 2004 version" , add
label define V042015b   2   "2. September 8, 2004 version" , add
label define V042015b   3   "3. September 16, 2004 version" , add
label define V042015b   4   "4. September 29, 2004 version" , add
label define V042015c   1   "1. September 2, 2004 version" , add
label define V042015c   2   "2. September 8, 2004 version" , add
label define V042015c   3   "3. September 16, 2004 version" , add
label define V042015c   4   "4. September 29, 2004 version" , add
label define V042015d   1   "1. September 2, 2004 version" , add
label define V042015d   2   "2. September 8, 2004 version" , add
label define V042015d   3   "3. September 16, 2004 version" , add
label define V042015d   4   "4. September 29, 2004 version" , add
label define V042016a   00   "00. Interview completed in 1 session" , add
label define V042016a   01   "01. Media module (A1-A9)" , add
label define V042016a   02   "02. Country on right track A10" , add
label define V042016a   03   "03. Congressional approval (A13-A13a)" , add
label define V042016a   04   "04. Thermometer series (B1-B1q)" , add
label define V042016a   05   "05. Party likes-dislikes (C1-C2d5)" , add
label define V042016a   06   "06. R finance questions (C4-C9)" , add
label define V042016a   07   "07. Presidential candidate affects (D1-D2d1)" , add
label define V042016a   08   "08. Liberal-conservative placements (E1-E6)" , add
label define V042016a   09   "09. Who will win presidency (E7-E9a)" , add
label define V042016a   10   "10. Economy question (F1-F6)" , add
label define V042016a   11   "11. Interventionism questions (F7-F7a1)" , add
label define V042016a   12   "12. Party handling of issues (G1-G3)" , add
label define V042016a   13   "13. U.S. position and involvement in world (H1-H2)" , add
label define V042016a   14   "14. Party ID (J1-J1b)" , add
label define V042016a   15   "15. Presidential candidate traits (K1-K2h)" , add
label define V042016a   16   "16. Iraq/Afghanistan questions (M1-M4)" , add
label define V042016a   17   "17. Spending-services scales (N1-N1e)" , add
label define V042016a   18   "18. Govt health insurance scale (N4-N4a1)" , add
label define V042016a   19   "19. Guaranteed jobs-standard of living scales (N5-N5e)" , add
label define V042016a   20   "20. Federal spending series (P1-P1m)" , add
label define V042016a   21   "21. Tax level questions (P2a-P2a2)" , add
label define V042016a   22   "22. Late abortion questions (P2c-P2c1)" , add
label define V042016a   23   "23. Environment-jobs scale (P3-P3a1)" , add
label define V042016a   24   "24. Demographics (W1-end of IW)" , add
label define V042016b   01   "01. Media module (A1-A9)" , add
label define V042016b   02   "02. Country on right track A10" , add
label define V042016b   03   "03. Congressional approval (A13-A13a)" , add
label define V042016b   04   "04. Thermometer series (B1-B1q)" , add
label define V042016b   05   "05. Party likes-dislikes (C1-C2d5)" , add
label define V042016b   06   "06. R finance questions (C4-C9)" , add
label define V042016b   07   "07. Presidential candidate affects (D1-D2d1)" , add
label define V042016b   08   "08. Liberal-conservative placements (E1-E6)" , add
label define V042016b   09   "09. Who will win presidency (E7-E9a)" , add
label define V042016b   10   "10. Economy question (F1-F6)" , add
label define V042016b   11   "11. Interventionism questions (F7-F7a1)" , add
label define V042016b   12   "12. Party handling of issues (G1-G3)" , add
label define V042016b   13   "13. U.S. position and involvement in world (H1-H2)" , add
label define V042016b   14   "14. Party ID (J1-J1b)" , add
label define V042016b   15   "15. Presidential candidate traits (K1-K2h)" , add
label define V042016b   16   "16. Iraq/Afghanistan questions (M1-M4)" , add
label define V042016b   17   "17. Spending-services scales (N1-N1e)" , add
label define V042016b   18   "18. Govt health insurance scale (N4-N4a1)" , add
label define V042016b   19   "19. Guaranteed jobs-standard of living scales (N5-N5e)" , add
label define V042016b   20   "20. Federal spending series (P1-P1m)" , add
label define V042016b   21   "21. Tax level questions (P2a-P2a2)" , add
label define V042016b   22   "22. Late abortion questions (P2c-P2c1)" , add
label define V042016b   23   "23. Environment-jobs scale (P3-P3a1)" , add
label define V042016b   24   "24. Demographics (W1-end of IW)" , add
label define V042016c   01   "01. Media module (A1-A9)" , add
label define V042016c   02   "02. Country on right track A10" , add
label define V042016c   03   "03. Congressional approval (A13-A13a)" , add
label define V042016c   04   "04. Thermometer series (B1-B1q)" , add
label define V042016c   05   "05. Party likes-dislikes (C1-C2d5)" , add
label define V042016c   06   "06. R finance questions (C4-C9)" , add
label define V042016c   07   "07. Presidential candidate affects (D1-D2d1)" , add
label define V042016c   08   "08. Liberal-conservative placements (E1-E6)" , add
label define V042016c   09   "09. Who will win presidency (E7-E9a)" , add
label define V042016c   10   "10. Economy question (F1-F6)" , add
label define V042016c   11   "11. Interventionism questions (F7-F7a1)" , add
label define V042016c   12   "12. Party handling of issues (G1-G3)" , add
label define V042016c   13   "13. U.S. position and involvement in world (H1-H2)" , add
label define V042016c   14   "14. Party ID (J1-J1b)" , add
label define V042016c   15   "15. Presidential candidate traits (K1-K2h)" , add
label define V042016c   16   "16. Iraq/Afghanistan questions (M1-M4)" , add
label define V042016c   17   "17. Spending-services scales (N1-N1e)" , add
label define V042016c   18   "18. Govt health insurance scale (N4-N4a1)" , add
label define V042016c   19   "19. Guaranteed jobs-standard of living scales (N5-N5e)" , add
label define V042016c   20   "20. Federal spending series (P1-P1m)" , add
label define V042016c   21   "21. Tax level questions (P2a-P2a2)" , add
label define V042016c   22   "22. Late abortion questions (P2c-P2c1)" , add
label define V042016c   23   "23. Environment-jobs scale (P3-P3a1)" , add
label define V042016c   24   "24. Demographics (W1-end of IW)" , add
label define V042020f   0   "00. NA" , add
label define V042021f   0   "0. Not a refusal conversion situation" , add
label define V042021f   1   "1. Refusal conversion" , add
label define V042022f   1   "1. All cases released at start of interviewing period" , add
label define V042023f   1   "1. All interviews conducted face-to-face" , add
label define V042024f   1   "1. Completed interview" , add
label define V042025f   000   "000.00 NA" , add
label define V042026f   1   "1. All interviews were conducted in English" , add
label define V042027f   0   "0. Not selected for verification" , add
label define V042027f   2   "2. Verified, no inconsistencies" , add
label define V042027f   3   "3. Verified with discrepancies" , add
label define V042027f   4   "4. Failed verification" , add
label define V042027f   5   "5. Unable to verify (unable to contact respondent)" , add
label define V042027f   6   "6. Verification limit met (used when the case if flagged for" , add
label define V042028f   0   "0. Not flagged for evaluation" , add
label define V042028f   1   "1. Flagged for evaluation; not evaluated" , add
label define V042028f   2   "2. Evaluated" , add
label define V042029f   1   "1. Yes, tape-recorded" , add
label define V042029f   5   "5. No" , add
label define V042030f   20   "20. $20" , add
label define V042030f   50   "50. $50" , add
label define V042031f   00   "00. Respondent refused payment" , add
label define V042031f   20   "20. $20" , add
label define V042031f   50   "50. $50" , add
label define V042031f   99   "99. NA" , add
label define V042033f   1   "1. All respondents paid by check" , add
label define V042034f   1   "1. All respondents received $5 cash and a magnet" , add
label define V042035f   0   "0. Persuasion letters not documented" , add
label define V042036a    0   "0. Positive comment not coded at any call" , add
label define V042036a    1   "1. Positive comment coded for at least one call" , add
label define V042036a    9   "9. NA" , add
label define V042036b    0   "0. Time-delay comment not coded at any call" , add
label define V042036b    1   "1. Time-delay comment coded for at least one call" , add
label define V042036b    9   "9. NA" , add
label define V042036c    0   "0. Negative comment not coded at any call" , add
label define V042036c    1   "1. Negative comment coded for at least one call" , add
label define V042036c    9   "9. NA" , add
label define V042036d    0   "0. Eligibility comment not coded at any call" , add
label define V042036d    1   "1. Eligibility comment coded for at least one call" , add
label define V042036d    9   "9. NA" , add
label define V042036e    0   "0. Privacy comment not coded at any call" , add
label define V042036e    1   "1. Privacy comment coded for at least one call" , add
label define V042036e    9   "9. NA" , add
label define V042036f    0   "0. Political disinterest comment not coded at any call" , add
label define V042036f    1   "1. Political disinterest comment coded for at least one call" , add
label define V042036f    9   "9. NA" , add
label define V042037a    1   "1. Coded at 1 or more calls" , add
label define V042037a    5   "5. Not coded" , add
label define V042037a    0   "0. NA" , add
label define V042037b    1   "1. Coded at 1 or more calls" , add
label define V042037b    5   "5. Not coded" , add
label define V042037b    0   "0. NA" , add
label define V042037c    1   "1. Coded at 1 or more calls" , add
label define V042037c    5   "5. Not coded" , add
label define V042037c    0   "0. NA" , add
label define V042037d    1   "1. Coded at 1 or more calls" , add
label define V042037d    5   "5. Not coded" , add
label define V042037d    0   "0. NA" , add
label define V042037e    1   "1. Coded at 1 or more calls" , add
label define V042037e    5   "5. Not coded" , add
label define V042037e    0   "0. NA" , add
label define V042037f    1   "1. Coded at 1 or more calls" , add
label define V042037f    5   "5. Not coded" , add
label define V042037f    0   "0. NA" , add
label define V042037g    1   "1. Coded at 1 or more calls" , add
label define V042037g    5   "5. Not coded" , add
label define V042037g    0   "0. NA" , add
label define V042037h    1   "1. Coded at 1 or more calls" , add
label define V042037h    5   "5. Not coded" , add
label define V042037h    0   "0. NA" , add
label define V042037j    1   "1. Coded at 1 or more calls" , add
label define V042037j    5   "5. Not coded" , add
label define V042037j    0   "0. NA" , add
label define V042037k    1   "1. Coded at 1 or more calls" , add
label define V042037k    5   "5. Not coded" , add
label define V042037k    0   "0. NA" , add
label define V042037m    1   "1. Coded at 1 or more calls" , add
label define V042037m    5   "5. Not coded" , add
label define V042037m    0   "0. NA" , add
label define V042037n    1   "1. Coded at 1 or more calls" , add
label define V042037n    5   "5. Not coded" , add
label define V042037n    0   "0. NA" , add
label define V042037p    1   "1. Coded at 1 or more calls" , add
label define V042037p    5   "5. Not coded" , add
label define V042037p    0   "0. NA" , add
label define V042037q    1   "1. Coded at 1 or more calls" , add
label define V042037q    5   "5. Not coded" , add
label define V042037q    0   "0. NA" , add
label define V042037r    1   "1. Coded at 1 or more calls" , add
label define V042037r    5   "5. Not coded" , add
label define V042037r    0   "0. NA" , add
label define V042037s    1   "1. Coded at 1 or more calls" , add
label define V042037s    5   "5. Not coded" , add
label define V042037s    0   "0. NA" , add
label define V042037t    1   "1. Coded at 1 or more calls" , add
label define V042037t    5   "5. Not coded" , add
label define V042037t    0   "0. NA" , add
label define V042037u    1   "1. Coded at 1 or more calls" , add
label define V042037u    5   "5. Not coded" , add
label define V042037u    0   "0. NA" , add
label define V042037v    1   "1. Coded at 1 or more calls" , add
label define V042037v    5   "5. Not coded" , add
label define V042037v    0   "0. NA" , add
label define V042037w    1   "1. Coded at 1 or more calls" , add
label define V042037w    5   "5. Not coded" , add
label define V042037w    0   "0. NA" , add
label define V042037y    1   "1. Coded at 1 or more calls" , add
label define V042037y    5   "5. Not coded" , add
label define V042037y    0   "0. NA" , add
label define V042038f   0   "0. Respondent did not initially refuse" , add
label define V042038f   1   "1. Respondent initial refusal" , add
label define V042039f   0   "0. Informant did not initially refuse" , add
label define V042039f   1   "1. Informant initial refusal" , add
label define V042040f    1   "1. Mobile home" , add
label define V042040f    2   "2. Detached single family" , add
label define V042040f    3   "3. Multi-family" , add
label define V042040f    4   "4. Apartment house" , add
label define V042040f    5   "5. Condo complex" , add
label define V042040f    7   "7. Other {SPECIFY}" , add
label define V042040f    0   "0. NA" , add
label define V042041f    1   "1. Single family home" , add
label define V042041f    2   "2. Structure with 2 to 9 units" , add
label define V042041f    3   "3. Structure with 10 to 49 units" , add
label define V042041f    4   "4. Structure with 50 or more units" , add
label define V042041f    7   "7. Other {SPECIFY}" , add
label define V042041f    0   "0. NA" , add
label define V042042f    1   "1. Entirely residential" , add
label define V042042f    2   "2. Primarily residential with some commercial or other" , add
label define V042042f    3   "3. Primarily commercial or other non-residential" , add
label define V042042f    0   "0. NA" , add
label define V042043f    1   "1. Rural area" , add
label define V042043f    2   "2. Small town" , add
label define V042043f    3   "3. Suburb" , add
label define V042043f    4   "4. Large city" , add
label define V042043f    5   "5. Inner city" , add
label define V042043f    0   "0. NA" , add
label define V042044f    1   "1. Yes {SPECIFY}" , add
label define V042044f    5   "5. No" , add
label define V042044f    0   "0. NA" , add
label define V042044a    1   "1. Democratic Presidential candidate" , add
label define V042044a    2   "2. Republican Presidential candidate" , add
label define V042044a    3   "3. Congressional candidate" , add
label define V042044a    4   "4. Candidate for governor" , add
label define V042044a    5   "5. 1 or more local candidates" , add
label define V042044a    7   "7. Other non-presidential candidate, NA what level" , add
label define V042044a    0   "0. NA" , add
label define V042044b    1   "1. Democratic Presidential candidate" , add
label define V042044b    2   "2. Republican Presidential candidate" , add
label define V042044b    3   "3. Congressional candidate" , add
label define V042044b    4   "4. Candidate for governor" , add
label define V042044b    5   "5. 1 or more local candidates" , add
label define V042044b    7   "7. Other non-presidential candidate, NA what level" , add
label define V042045x    0   "0. None of the specified impediments coded at any call and" , add
label define V042045x    1   "1. 1 or more specified impediments coded" , add
label define V042045x    9   "9. NA" , add
label define V042045a    1   "1. Coded at 1 or more calls" , add
label define V042045a    5   "5. Not coded" , add
label define V042045a    0   "0. NA" , add
label define V042045b    1   "1. Coded at 1 or more calls" , add
label define V042045b    5   "5. Not coded" , add
label define V042045b    0   "0. NA" , add
label define V042045c    1   "1. Coded at 1 or more calls" , add
label define V042045c    5   "5. Not coded" , add
label define V042045c    0   "0. NA" , add
label define V042045d    1   "1. Coded at 1 or more calls" , add
label define V042045d    5   "5. Not coded" , add
label define V042045d    0   "0. NA" , add
label define V042046x    0   "0. None of the specified security measures coded at any call and" , add
label define V042046x    1   "1. 1 or more specified impediments coded" , add
label define V042046x    9   "9. NA" , add
label define V042046a    1   "1. Coded at 1 or more calls" , add
label define V042046a    5   "5. Not coded" , add
label define V042046a    0   "0. NA" , add
label define V042046b    1   "1. Coded at 1 or more calls" , add
label define V042046b    5   "5. Not coded" , add
label define V042046b    0   "0. NA" , add
label define V042046c    1   "1. Coded at 1 or more calls" , add
label define V042046c    5   "5. Not coded" , add
label define V042046c    0   "0. NA" , add
label define V042046d    1   "1. Coded at 1 or more calls" , add
label define V042046d    5   "5. Not coded" , add
label define V042046d    0   "0. NA" , add
label define V042046e    1   "1. Coded at 1 or more calls" , add
label define V042046e    5   "5. Not coded" , add
label define V042046e    0   "0. NA" , add
label define V042047f    1   "1. Yes" , add
label define V042047f    2   "2. No, but building is locked/subdivision is gated and locked" , add
label define V042047f    5   "5. No" , add
label define V042047f    0   "0. NA" , add
label define V042047a    1   "1. Building manager or other gatekeeper must let you in the" , add
label define V042047a    2   "2. Building manager or other gatekeeper must get permission from" , add
label define V042047a    7   "7. Other {SPECIFY}" , add
label define V042047a    0   "0. NA" , add
label define V042048a    0   "0. Gatekeeper noted at neither PreAdmin.45c nor PreAdmin.47" , add
label define V042048a    1   "1. Gatekeeper noted at PreAdmin.45c but not at PreAdmin.47" , add
label define V042048a    2   "2. Gatekeeper noted at PreAdmin.47 but not at PreAdmin.45c" , add
label define V042048a    3   "3. Gatekeeper noted at both PreAdmin.45c and PreAdmin.47" , add
label define V042048a    9   "9. NA in both PreAdmin.45c and PreAdmin.47" , add
label define V042048b    0   "0. Locked status noted at neither PreAdmin.45b nor PreAdmin.47" , add
label define V042048b    1   "1. Locked status noted at PreAdmin.45b but not at PreAdmin.47" , add
label define V042048b    2   "2. Locked status noted at PreAdmin.47 but not at PreAdmin.45c" , add
label define V042048b    3   "3. Locked status noted at both PreAdmin.45b and PreAdmin.47" , add
label define V042048b    9   "9. NA in both PreAdmin.45b and PreAdmin.47" , add
label define V042201f   0   "0. No error in Pre application" , add
label define V042201f   1   "1. Error in E8 (skipped E8a)" , add
label define V042201f   2   "2. Error in E9 (skipped E9a)" , add
label define V042201f   3   "3. Error in E8 and E9 (skipped E8a and E9a)" , add
label define V042202f   0   "0. No error; F3-F6 not skipped" , add
label define V042202f   1   "1. Error; F3-F6 skipped" , add
label define V042401f   1   "1. President Bush likes-dislikes administered first (A3-A4)" , add
label define V042401f   2   "2. John Kerry likes-dislikes administered first (A5-A6)" , add
label define V042402f   1   "1. John Kerry thermometer administered first (B1b)" , add
label define V042402f   2   "2. Ralph Nader thermometer administered first (B1c)" , add
label define V042403a   1   "1. Administered as 1st name" , add
label define V042403a   2   "2. Administered as 2nd name" , add
label define V042403a   3   "3. Administered as 3rd name" , add
label define V042403a   4   "4. Administered as 4th name" , add
label define V042403a   5   "5. Administered as 5th name" , add
label define V042403a   6   "6. Administered as 6th name" , add
label define V042403a   7   "7. Administered as 7th name" , add
label define V042403a   8   "8. Administered as 8th name" , add
label define V042403b   1   "1. Administered as 1st name" , add
label define V042403b   2   "2. Administered as 2nd name" , add
label define V042403b   3   "3. Administered as 3rd name" , add
label define V042403b   4   "4. Administered as 4th name" , add
label define V042403b   5   "5. Administered as 5th name" , add
label define V042403b   6   "6. Administered as 6th name" , add
label define V042403b   7   "7. Administered as 7th name" , add
label define V042403b   8   "8. Administered as 8th name" , add
label define V042403c   1   "1. Administered as 1st name" , add
label define V042403c   2   "2. Administered as 2nd name" , add
label define V042403c   3   "3. Administered as 3rd name" , add
label define V042403c   4   "4. Administered as 4th name" , add
label define V042403c   5   "5. Administered as 5th name" , add
label define V042403c   6   "6. Administered as 6th name" , add
label define V042403c   7   "7. Administered as 7th name" , add
label define V042403c   8   "8. Administered as 8th name" , add
label define V042403d   1   "1. Administered as 1st name" , add
label define V042403d   2   "2. Administered as 2nd name" , add
label define V042403d   3   "3. Administered as 3rd name" , add
label define V042403d   4   "4. Administered as 4th name" , add
label define V042403d   5   "5. Administered as 5th name" , add
label define V042403d   6   "6. Administered as 6th name" , add
label define V042403d   7   "7. Administered as 7th name" , add
label define V042403d   8   "8. Administered as 8th name" , add
label define V042403e   1   "1. Administered as 1st name" , add
label define V042403e   2   "2. Administered as 2nd name" , add
label define V042403e   3   "3. Administered as 3rd name" , add
label define V042403e   4   "4. Administered as 4th name" , add
label define V042403e   5   "5. Administered as 5th name" , add
label define V042403e   6   "6. Administered as 6th name" , add
label define V042403e   7   "7. Administered as 7th name" , add
label define V042403e   8   "8. Administered as 8th name" , add
label define V042403f   1   "1. Administered as 1st name" , add
label define V042403f   2   "2. Administered as 2nd name" , add
label define V042403f   3   "3. Administered as 3rd name" , add
label define V042403f   4   "4. Administered as 4th name" , add
label define V042403f   5   "5. Administered as 5th name" , add
label define V042403f   6   "6. Administered as 6th name" , add
label define V042403f   7   "7. Administered as 7th name" , add
label define V042403f   8   "8. Administered as 8th name" , add
label define V042403g   1   "1. Administered as 1st name" , add
label define V042403g   2   "2. Administered as 2nd name" , add
label define V042403g   3   "3. Administered as 3rd name" , add
label define V042403g   4   "4. Administered as 4th name" , add
label define V042403g   5   "5. Administered as 5th name" , add
label define V042403g   6   "6. Administered as 6th name" , add
label define V042403g   7   "7. Administered as 7th name" , add
label define V042403g   8   "8. Administered as 8th name" , add
label define V042403h   1   "1. Administered as 1st name" , add
label define V042403h   2   "2. Administered as 2nd name" , add
label define V042403h   3   "3. Administered as 3rd name" , add
label define V042403h   4   "4. Administered as 4th name" , add
label define V042403h   5   "5. Administered as 5th name" , add
label define V042403h   6   "6. Administered as 6th name" , add
label define V042403h   7   "7. Administered as 7th name" , add
label define V042403h   8   "8. Administered as 8th name" , add
label define V042404f   1   "1. Democratic party thermometer administered first (B1n)" , add
label define V042404f   2   "2. Republican party thermometer administered first (B1p)" , add
label define V042405f   1   "1. Democratic party likes-dislikes administered first (C1)" , add
label define V042405f   2   "2. Republican party likes-dislikes administered first (C2)" , add
label define V042406f   1   "1. President Bush affects administered first (D1 series)" , add
label define V042406f   2   "2. John Kerry affects administered first (D2 series)" , add
label define V042407a   1   "1. Administered 1st" , add
label define V042407a   2   "2. Administered 2nd" , add
label define V042407a   3   "3. Administered 3rd" , add
label define V042407a   4   "4. Administered 4th" , add
label define V042407b   1   "1. Administered 1st" , add
label define V042407b   2   "2. Administered 2nd" , add
label define V042407b   3   "3. Administered 3rd" , add
label define V042407b   4   "4. Administered 4th" , add
label define V042407c   1   "1. Administered 1st" , add
label define V042407c   2   "2. Administered 2nd" , add
label define V042407c   3   "3. Administered 3rd" , add
label define V042407c   4   "4. Administered 4th" , add
label define V042407d   1   "1. Administered 1st" , add
label define V042407d   2   "2. Administered 2nd" , add
label define V042407d   3   "3. Administered 3rd" , add
label define V042407d   4   "4. Administered 4th" , add
label define V042408a   1   "1. Administered 1st" , add
label define V042408a   2   "2. Administered 2nd" , add
label define V042408a   3   "3. Administered 3rd" , add
label define V042408a   4   "4. Administered 4th" , add
label define V042408b   1   "1. Administered 1st" , add
label define V042408b   2   "2. Administered 2nd" , add
label define V042408b   3   "3. Administered 3rd" , add
label define V042408b   4   "4. Administered 4th" , add
label define V042408c   1   "1. Administered 1st" , add
label define V042408c   2   "2. Administered 2nd" , add
label define V042408c   3   "3. Administered 3rd" , add
label define V042408c   4   "4. Administered 4th" , add
label define V042408d   1   "1. Administered 1st" , add
label define V042408d   2   "2. Administered 2nd" , add
label define V042408d   3   "3. Administered 3rd" , add
label define V042408d   4   "4. Administered 4th" , add
label define V042409f   1   "1. John Kerry placement administered first (K3)" , add
label define V042409f   2   "2. Ralph Nader placement administered first (K4)" , add
label define V042410f   1   "1. Democratic party placement administered first (E5)" , add
label define V042410f   2   "2. Republican party placement administered first (E6)" , add
label define V042411f   1   "1. Unemployment questions F3-F4 administered first" , add
label define V042411f   2   "2. Inflation questions F5-F6 administered first" , add
label define V042412f   1   "1. Democratic party first in question text" , add
label define V042412f   2   "2. Republican party first in question text" , add
label define V042413f   1   "1. President Bush traits administered first (K1 series)" , add
label define V042413f   2   "2. John Kerry traits administered first (K2 series)" , add
label define V042414a   1   "1. Administered 1st" , add
label define V042414a   2   "2. Administered 2nd" , add
label define V042414a   3   "3. Administered 3rd" , add
label define V042414a   4   "4. Administered 4th" , add
label define V042414a   5   "5. Administered 5th" , add
label define V042414a   6   "6. Administered 6th" , add
label define V042414a   7   "7. Administered 7th" , add
label define V042414b   1   "1. Administered 1st" , add
label define V042414b   2   "2. Administered 2nd" , add
label define V042414b   3   "3. Administered 3rd" , add
label define V042414b   4   "4. Administered 4th" , add
label define V042414b   5   "5. Administered 5th" , add
label define V042414b   6   "6. Administered 6th" , add
label define V042414b   7   "7. Administered 7th" , add
label define V042414c   1   "1. Administered 1st" , add
label define V042414c   2   "2. Administered 2nd" , add
label define V042414c   3   "3. Administered 3rd" , add
label define V042414c   4   "4. Administered 4th" , add
label define V042414c   5   "5. Administered 5th" , add
label define V042414c   6   "6. Administered 6th" , add
label define V042414c   7   "7. Administered 7th" , add
label define V042414d   1   "1. Administered 1st" , add
label define V042414d   2   "2. Administered 2nd" , add
label define V042414d   3   "3. Administered 3rd" , add
label define V042414d   4   "4. Administered 4th" , add
label define V042414d   5   "5. Administered 5th" , add
label define V042414d   6   "6. Administered 6th" , add
label define V042414d   7   "7. Administered 7th" , add
label define V042414e   1   "1. Administered 1st" , add
label define V042414e   2   "2. Administered 2nd" , add
label define V042414e   3   "3. Administered 3rd" , add
label define V042414e   4   "4. Administered 4th" , add
label define V042414e   5   "5. Administered 5th" , add
label define V042414e   6   "6. Administered 6th" , add
label define V042414e   7   "7. Administered 7th" , add
label define V042414f   1   "1. Administered 1st" , add
label define V042414f   2   "2. Administered 2nd" , add
label define V042414f   3   "3. Administered 3rd" , add
label define V042414f   4   "4. Administered 4th" , add
label define V042414f   5   "5. Administered 5th" , add
label define V042414f   6   "6. Administered 6th" , add
label define V042414f   7   "7. Administered 7th" , add
label define V042414g   1   "1. Administered 1st" , add
label define V042414g   2   "2. Administered 2nd" , add
label define V042414g   3   "3. Administered 3rd" , add
label define V042414g   4   "4. Administered 4th" , add
label define V042414g   5   "5. Administered 5th" , add
label define V042414g   6   "6. Administered 6th" , add
label define V042414g   7   "7. Administered 7th" , add
label define V042415a   1   "1. Administered 1st" , add
label define V042415a   2   "2. Administered 2nd" , add
label define V042415a   3   "3. Administered 3rd" , add
label define V042415a   4   "4. Administered 4th" , add
label define V042415a   5   "5. Administered 5th" , add
label define V042415a   6   "6. Administered 6th" , add
label define V042415a   7   "7. Administered 7th" , add
label define V042415b   1   "1. Administered 1st" , add
label define V042415b   2   "2. Administered 2nd" , add
label define V042415b   3   "3. Administered 3rd" , add
label define V042415b   4   "4. Administered 4th" , add
label define V042415b   5   "5. Administered 5th" , add
label define V042415b   6   "6. Administered 6th" , add
label define V042415b   7   "7. Administered 7th" , add
label define V042415c   1   "1. Administered 1st" , add
label define V042415c   2   "2. Administered 2nd" , add
label define V042415c   3   "3. Administered 3rd" , add
label define V042415c   4   "4. Administered 4th" , add
label define V042415c   5   "5. Administered 5th" , add
label define V042415c   6   "6. Administered 6th" , add
label define V042415c   7   "7. Administered 7th" , add
label define V042415d   1   "1. Administered 1st" , add
label define V042415d   2   "2. Administered 2nd" , add
label define V042415d   3   "3. Administered 3rd" , add
label define V042415d   4   "4. Administered 4th" , add
label define V042415d   5   "5. Administered 5th" , add
label define V042415d   6   "6. Administered 6th" , add
label define V042415d   7   "7. Administered 7th" , add
label define V042415e   1   "1. Administered 1st" , add
label define V042415e   2   "2. Administered 2nd" , add
label define V042415e   3   "3. Administered 3rd" , add
label define V042415e   4   "4. Administered 4th" , add
label define V042415e   5   "5. Administered 5th" , add
label define V042415e   6   "6. Administered 6th" , add
label define V042415e   7   "7. Administered 7th" , add
label define V042415f   1   "1. Administered 1st" , add
label define V042415f   2   "2. Administered 2nd" , add
label define V042415f   3   "3. Administered 3rd" , add
label define V042415f   4   "4. Administered 4th" , add
label define V042415f   5   "5. Administered 5th" , add
label define V042415f   6   "6. Administered 6th" , add
label define V042415f   7   "7. Administered 7th" , add
label define V042415g   1   "1. Administered 1st" , add
label define V042415g   2   "2. Administered 2nd" , add
label define V042415g   3   "3. Administered 3rd" , add
label define V042415g   4   "4. Administered 4th" , add
label define V042415g   5   "5. Administered 5th" , add
label define V042415g   6   "6. Administered 6th" , add
label define V042415g   7   "7. Administered 7th" , add
label define V042416f   1   "1. George Bush placement administered first (N1b)" , add
label define V042416f   2   "2. John Kerry placement administered first (N1c)" , add
label define V042417f   1   "1. Democratic party placement administered first (N1d)" , add
label define V042417f   2   "2. Republican party placement administered first (N1e)" , add
label define V042418f   1   "1. George Bush placement administered first N2b)" , add
label define V042418f   2   "2. John Kerry placement administered first (N2c)" , add
label define V042419f   1   "1. Democratic party placement administered first (N2d)" , add
label define V042419f   2   "2. Republican party placement administered first (N2e)" , add
label define V042420f   1   "1. George Bush placement administered first (N5b)" , add
label define V042420f   2   "2. John Kerry placement administered first (N5c)" , add
label define V042421f   1   "1. Democratic party placement administered first (N5d)" , add
label define V042421f   2   "2. Republican party placement administered first (N5e)" , add
label define V042422f   1   "1. George Bush placement administered first (N6b)" , add
label define V042422f   2   "2. John Kerry placement administered first (N6c)" , add
label define V042423f   1   "1. Democratic party placement administered first (N6d)" , add
label define V042423f   2   "2. Republican party placement administered first (N6e)" , add
label define V042424a   01   "01. Administered 1st" , add
label define V042424a   02   "02. Administered 2nd" , add
label define V042424a   03   "03. Administered 3rd" , add
label define V042424a   04   "04. Administered 4th" , add
label define V042424a   05   "05. Administered 5th" , add
label define V042424a   06   "06. Administered 6th" , add
label define V042424a   07   "07. Administered 7th" , add
label define V042424a   08   "08. Administered 8th" , add
label define V042424a   09   "09. Administered 9th" , add
label define V042424a   10   "10. Administered 10th" , add
label define V042424b   01   "01. Administered 1st" , add
label define V042424b   02   "02. Administered 2nd" , add
label define V042424b   03   "03. Administered 3rd" , add
label define V042424b   04   "04. Administered 4th" , add
label define V042424b   05   "05. Administered 5th" , add
label define V042424b   06   "06. Administered 6th" , add
label define V042424b   07   "07. Administered 7th" , add
label define V042424b   08   "08. Administered 8th" , add
label define V042424b   09   "09. Administered 9th" , add
label define V042424b   10   "10. Administered 10th" , add
label define V042424c   01   "01. Administered 1st" , add
label define V042424c   02   "02. Administered 2nd" , add
label define V042424c   03   "03. Administered 3rd" , add
label define V042424c   04   "04. Administered 4th" , add
label define V042424c   05   "05. Administered 5th" , add
label define V042424c   06   "06. Administered 6th" , add
label define V042424c   07   "07. Administered 7th" , add
label define V042424c   08   "08. Administered 8th" , add
label define V042424c   09   "09. Administered 9th" , add
label define V042424c   10   "10. Administered 10th" , add
label define V042424d   01   "01. Administered 1st" , add
label define V042424d   02   "02. Administered 2nd" , add
label define V042424d   03   "03. Administered 3rd" , add
label define V042424d   04   "04. Administered 4th" , add
label define V042424d   05   "05. Administered 5th" , add
label define V042424d   06   "06. Administered 6th" , add
label define V042424d   07   "07. Administered 7th" , add
label define V042424d   08   "08. Administered 8th" , add
label define V042424d   09   "09. Administered 9th" , add
label define V042424d   10   "10. Administered 10th" , add
label define V042424e   01   "01. Administered 1st" , add
label define V042424e   02   "02. Administered 2nd" , add
label define V042424e   03   "03. Administered 3rd" , add
label define V042424e   04   "04. Administered 4th" , add
label define V042424e   05   "05. Administered 5th" , add
label define V042424e   06   "06. Administered 6th" , add
label define V042424e   07   "07. Administered 7th" , add
label define V042424e   08   "08. Administered 8th" , add
label define V042424e   09   "09. Administered 9th" , add
label define V042424e   10   "10. Administered 10th" , add
label define V042424f   01   "01. Administered 1st" , add
label define V042424f   02   "02. Administered 2nd" , add
label define V042424f   03   "03. Administered 3rd" , add
label define V042424f   04   "04. Administered 4th" , add
label define V042424f   05   "05. Administered 5th" , add
label define V042424f   06   "06. Administered 6th" , add
label define V042424f   07   "07. Administered 7th" , add
label define V042424f   08   "08. Administered 8th" , add
label define V042424f   09   "09. Administered 9th" , add
label define V042424f   10   "10. Administered 10th" , add
label define V042424g   01   "01. Administered 1st" , add
label define V042424g   02   "02. Administered 2nd" , add
label define V042424g   03   "03. Administered 3rd" , add
label define V042424g   04   "04. Administered 4th" , add
label define V042424g   05   "05. Administered 5th" , add
label define V042424g   06   "06. Administered 6th" , add
label define V042424g   07   "07. Administered 7th" , add
label define V042424g   08   "08. Administered 8th" , add
label define V042424g   09   "09. Administered 9th" , add
label define V042424g   10   "10. Administered 10th" , add
label define V042424h   01   "01. Administered 1st" , add
label define V042424h   02   "02. Administered 2nd" , add
label define V042424h   03   "03. Administered 3rd" , add
label define V042424h   04   "04. Administered 4th" , add
label define V042424h   05   "05. Administered 5th" , add
label define V042424h   06   "06. Administered 6th" , add
label define V042424h   07   "07. Administered 7th" , add
label define V042424h   08   "08. Administered 8th" , add
label define V042424h   09   "09. Administered 9th" , add
label define V042424h   10   "10. Administered 10th" , add
label define V042424j   01   "01. Administered 1st" , add
label define V042424j   02   "02. Administered 2nd" , add
label define V042424j   03   "03. Administered 3rd" , add
label define V042424j   04   "04. Administered 4th" , add
label define V042424j   05   "05. Administered 5th" , add
label define V042424j   06   "06. Administered 6th" , add
label define V042424j   07   "07. Administered 7th" , add
label define V042424j   08   "08. Administered 8th" , add
label define V042424j   09   "09. Administered 9th" , add
label define V042424j   10   "10. Administered 10th" , add
label define V042424k   01   "01. Administered 1st" , add
label define V042424k   02   "02. Administered 2nd" , add
label define V042424k   03   "03. Administered 3rd" , add
label define V042424k   04   "04. Administered 4th" , add
label define V042424k   05   "05. Administered 5th" , add
label define V042424k   06   "06. Administered 6th" , add
label define V042424k   07   "07. Administered 7th" , add
label define V042424k   08   "08. Administered 8th" , add
label define V042424k   09   "09. Administered 9th" , add
label define V042424k   10   "10. Administered 10th" , add
label define V042425f   1   "1. George Bush placement administered first (P3b)" , add
label define V042425f   2   "2. John Kerry placement administered first (P3c)" , add
label define V042426f   1   "1. George Bush placement administered first (P5b)" , add
label define V042426f   2   "2. John Kerry placement administered first (P5c)" , add
label define V042427f   1   "1. George Bush placement administered first (P6b)" , add
label define V042427f   2   "2. John Kerry placement administered first (P6c)" , add
label define V042428f   1   "1. Democratic party placement administered first (P6d)" , add
label define V042428f   2   "2. Republican party placement administered first (P6e)" , add
label define V043001f    1   "1. Very much interested" , add
label define V043001f    3   "3. Somewhat interested" , add
label define V043001f    5   "5. Not much interested" , add
label define V043001f    8   "8. Don't know" , add
label define V043001f    9   "9. Refused" , add
label define V043002f    1   "1. Yes, voted" , add
label define V043002f    5   "5. No, didn't vote" , add
label define V043002f    8   "8. Don't know" , add
label define V043002f    9   "9. Refused" , add
label define V043003f    1   "1. Al Gore" , add
label define V043003f    3   "3. George W. Bush" , add
label define V043003f    5   "5. Pat Buchanan" , add
label define V043003f    6   "6. Ralph Nader" , add
label define V043003f    7   "7. Other (SPECIFY)" , add
label define V043003f    8   "8. Don't know" , add
label define V043003f    9   "9. Refused" , add
label define V043004f    1   "1. Fair" , add
label define V043004f    5   "5. Unfair" , add
label define V043004f    8   "8. Don't know" , add
label define V043004f    9   "9. Refused" , add
label define V043005f    1   "1. Fair - strongly" , add
label define V043005f    2   "2. Fair - not strongly" , add
label define V043005f    4   "4. Unfair - not strongly" , add
label define V043005f    5   "5. Unfair - strongly" , add
label define V043005f    8   "8. Don't know" , add
label define V043005f    9   "9. Refused" , add
label define V043006f    1   "1. Yes" , add
label define V043006f    5   "5. No" , add
label define V043006f    8   "8. Don't know" , add
label define V043006f    9   "9. Refused" , add
label define V043007f    0   "0. No mentions (5,8 in A3a; 8880,8888,8889 in A3b1)" , add
label define V043007f    1   "1. One mention" , add
label define V043007f    2   "2. Two mentions" , add
label define V043007f    3   "3. Three mentions" , add
label define V043007f    4   "4. Four mentions" , add
label define V043007f    5   "5. Five mentions" , add
label define V043007f    9   "9. RF (9 in A3a)" , add
label define V043007a    8877   "8877. Other miscellaneous" , add
label define V043007a    8880   "8880. No text; 'none'; 'no'; other uncodeable" , add
label define V043007a    8888   "8888. DK" , add
label define V043007a    8889   "8889. RF" , add
label define V043008f    1   "1. Yes" , add
label define V043008f    5   "5. No" , add
label define V043008f    8   "8. Don't Know" , add
label define V043008f    9   "9. Refused" , add
label define V043009f    0   "0. No mentions (5,8 in A4a; 8880,8888,8889 in A4b1)" , add
label define V043009f    1   "1. One mention" , add
label define V043009f    2   "2. Two mentions" , add
label define V043009f    3   "3. Three mentions" , add
label define V043009f    4   "4. Four mentions" , add
label define V043009f    5   "5. Five mentions" , add
label define V043009f    9   "9. RF (9 in A4a)" , add
label define V043009a    8877   "8877. Other miscellaneous" , add
label define V043009a    8880   "8880. No text; 'none'; 'no'; other uncodeable" , add
label define V043009a    8888   "8888. DK" , add
label define V043009a    8889   "8889. RF" , add
label define V043010f    1   "1. Yes" , add
label define V043010f    5   "5. No" , add
label define V043010f    8   "8. Don't know" , add
label define V043010f    9   "9. Refused" , add
label define V043011f    0   "0. No mentions (5,8 in A5a; 8880,8888,8889 in A5b1)" , add
label define V043011f    1   "1. One mention" , add
label define V043011f    2   "2. Two mentions" , add
label define V043011f    3   "3. Three mentions" , add
label define V043011f    4   "4. Four mentions" , add
label define V043011f    5   "5. Five mentions" , add
label define V043011f    9   "9. RF (9 in A5a)" , add
label define V043011a    8877   "8877. Other miscellaneous" , add
label define V043011a    8880   "8880. No text; 'none'; 'no'; other uncodeable" , add
label define V043011a    8888   "8888. DK" , add
label define V043011a    8889   "8889. RF" , add
label define V043012f    1   "1. Yes" , add
label define V043012f    5   "5. No" , add
label define V043012f    8   "8. Don't know" , add
label define V043012f    9   "9. Refused" , add
label define V043013f    0   "0. No mentions (5,8 in A6a; 8880,8888,8889 in A6b1)" , add
label define V043013f    1   "1. One mention" , add
label define V043013f    2   "2. Two mentions" , add
label define V043013f    3   "3. Three mentions" , add
label define V043013f    4   "4. Four mentions" , add
label define V043013f    5   "5. Five mentions" , add
label define V043013f    9   "9. RF (9 in A6a)" , add
label define V043013a    8877   "8877. Other miscellaneous" , add
label define V043013a    8880   "8880. No text; 'none'; 'no'; other uncodeable" , add
label define V043013a    8888   "8888. DK" , add
label define V043013a    8889   "8889. RF" , add
label define V043014f    0   "0. None" , add
label define V043014f    1   "1. One day" , add
label define V043014f    2   "2. Two days" , add
label define V043014f    3   "3. Three days" , add
label define V043014f    4   "4. Four days" , add
label define V043014f    5   "5. Five days" , add
label define V043014f    6   "6. Six days" , add
label define V043014f    7   "7. Every day" , add
label define V043014f    8   "8. Don't know" , add
label define V043014f    9   "9. Refused" , add
label define V043015f    1   "1. A great deal" , add
label define V043015f    2   "2. Quite a bit" , add
label define V043015f    3   "3. Some" , add
label define V043015f    4   "4. Very little" , add
label define V043015f    5   "5. None" , add
label define V043015f    8   "8. Don't know" , add
label define V043015f    9   "9. Refused" , add
label define V043016f    0   "0. None" , add
label define V043016f    1   "1. One day" , add
label define V043016f    2   "2. Two days" , add
label define V043016f    3   "3. Three days" , add
label define V043016f    4   "4. Four days" , add
label define V043016f    5   "5. Five days" , add
label define V043016f    6   "6. Six days" , add
label define V043016f    7   "7. Every day" , add
label define V043016f    8   "8. Don't know" , add
label define V043016f    9   "9. Refused" , add
label define V043017f    0   "0. None" , add
label define V043017f    1   "1. One day" , add
label define V043017f    2   "2. Two days" , add
label define V043017f    3   "3. Three days" , add
label define V043017f    4   "4. Four days" , add
label define V043017f    5   "5. Five days" , add
label define V043017f    6   "6. Six days" , add
label define V043017f    7   "7. Every day" , add
label define V043017f    8   "8. Don't know" , add
label define V043017f    9   "9. Refused" , add
label define V043018f    1   "1. A great deal" , add
label define V043018f    2   "2. Quite a bit" , add
label define V043018f    3   "3. Some" , add
label define V043018f    4   "4. Very little" , add
label define V043018f    5   "5. None" , add
label define V043018f    8   "8. Don't know" , add
label define V043018f    9   "9. Refused" , add
label define V043019f    0   "0. None" , add
label define V043019f    1   "1. One day" , add
label define V043019f    2   "2. Two days" , add
label define V043019f    3   "3. Three days" , add
label define V043019f    4   "4. Four days" , add
label define V043019f    5   "5. Five days" , add
label define V043019f    6   "6. Six days" , add
label define V043019f    7   "7. Every day" , add
label define V043019f    8   "8. Don't know" , add
label define V043019f    9   "9. Refused" , add
label define V043020f    0   "0. None" , add
label define V043020f    1   "1. One day" , add
label define V043020f    2   "2. Two days" , add
label define V043020f    3   "3. Three days" , add
label define V043020f    4   "4. Four days" , add
label define V043020f    5   "5. Five days" , add
label define V043020f    6   "6. Six days" , add
label define V043020f    7   "7. Every day" , add
label define V043020f    8   "8. Don't know" , add
label define V043020f    9   "9. Refused" , add
label define V043021f    1   "1. Yes" , add
label define V043021f    5   "5. No" , add
label define V043021f    8   "8. Don't know" , add
label define V043021f    9   "9. Refused" , add
label define V043022f    1   "1. A great deal" , add
label define V043022f    2   "2. Quite a bit" , add
label define V043022f    3   "3. Some" , add
label define V043022f    4   "4. Very little" , add
label define V043022f    5   "5. None" , add
label define V043022f    8   "8. Don't know" , add
label define V043022f    9   "9. Refused" , add
label define V043023f    1   "1. Right direction" , add
label define V043023f    5   "5. Wrong track" , add
label define V043023f    8   "8. Don't know" , add
label define V043023f    9   "9. Refused" , add
label define V043024f    1   "1. Approve" , add
label define V043024f    5   "5. Disapprove" , add
label define V043024f    8   "8. Don't know" , add
label define V043024f    9   "9. Refused" , add
label define V043025f    1   "1. Approve strongly" , add
label define V043025f    2   "2. Approve not strongly" , add
label define V043025f    4   "4. Disapprove not strongly" , add
label define V043025f    5   "5. Disapprove strongly" , add
label define V043025f    8   "8. Don't know" , add
label define V043025f    9   "9. Refused" , add
label define V043026f    1   "1. Approve" , add
label define V043026f    5   "5. Disapprove" , add
label define V043026f    8   "8. Don't know" , add
label define V043026f    9   "9. Refused" , add
label define V043027f    1   "1. Approve strongly" , add
label define V043027f    2   "2. Approve not strongly" , add
label define V043027f    4   "4. Disapprove not strongly" , add
label define V043027f    5   "5. Disapprove strongly" , add
label define V043027f    8   "8. Don't know" , add
label define V043027f    9   "9. Refused" , add
label define V043028f    1   "1. Approve" , add
label define V043028f    5   "5. Disapprove" , add
label define V043028f    8   "8. Don't know" , add
label define V043028f    9   "9. Refused" , add
label define V043029f    1   "1. Approve strongly" , add
label define V043029f    2   "2. Approve not strongly" , add
label define V043029f    4   "4. Disapprove not strongly" , add
label define V043029f    5   "5. Disapprove strongly" , add
label define V043029f    8   "8. Don't know" , add
label define V043029f    9   "9. Refused" , add
label define V043030f    1   "1. Approve" , add
label define V043030f    5   "5. Disapprove" , add
label define V043030f    8   "8. DK" , add
label define V043030f    9   "9. RF" , add
label define V043031f    1   "1. Approve strongly" , add
label define V043031f    2   "2. Approve not strongly" , add
label define V043031f    4   "4. Disapprove not strongly" , add
label define V043031f    5   "5. Disapprove strongly" , add
label define V043031f    8   "8. DK" , add
label define V043031f    9   "9. RF" , add
label define V043032f    1   "1. Approve" , add
label define V043032f    5   "5. Disapprove" , add
label define V043032f    8   "8. DK" , add
label define V043032f    9   "9. RF" , add
label define V043033f    1   "1. Approve strongly" , add
label define V043033f    2   "2. Approve not strongly" , add
label define V043033f    4   "4. Disapprove not strongly" , add
label define V043033f    5   "5. Disapprove strongly" , add
label define V043033f    8   "8. DK" , add
label define V043033f    9   "9. RF" , add
label define V043034f    1   "1. Right direction" , add
label define V043034f    5   "5. Wrong track" , add
label define V043034f    8   "8. Don't know" , add
label define V043034f    9   "9. Refused" , add
label define V043034x    1   "1. Right direction" , add
label define V043034x    5   "5. Wrong track" , add
label define V043034x    8   "8. Don't know" , add
label define V043034x    9   "9. Refused" , add
label define V043035f    1   "1. Very much" , add
label define V043035f    2   "2. Pretty much" , add
label define V043035f    3   "3. Not very much" , add
label define V043035f    4   "4. Not at all" , add
label define V043035f    8   "8. Don't know" , add
label define V043035f    9   "9. Refused" , add
label define V043036f    1   "1. Approve" , add
label define V043036f    5   "5. Disapprove" , add
label define V043036f    8   "8. Don't know" , add
label define V043036f    9   "9. Refused" , add
label define V043037f    1   "1. Approve strongly" , add
label define V043037f    2   "2. Approve not strongly" , add
label define V043037f    4   "4. Disapprove not strongly" , add
label define V043037f    5   "5. Disapprove strongly" , add
label define V043037f    8   "8. Don't know" , add
label define V043037f    9   "9. Refused" , add
label define V043038f    777   "777. Don't recognize" , add
label define V043038f    888   "888. Don't know where to rate" , add
label define V043038f    889   "889. Refused" , add
label define V043039f    777   "777. Don't recognize" , add
label define V043039f    888   "888. Don't know where to rate" , add
label define V043039f    889   "889. Refused" , add
label define V043040f    777   "777. Don't recognize" , add
label define V043040f    888   "888. Don't know where to rate" , add
label define V043040f    889   "889. Refused" , add
label define V043041f    777   "777. Don't recognize" , add
label define V043041f    888   "888. Don't know where to rate" , add
label define V043041f    889   "889. Refused" , add
label define V043042f    777   "777. Don't recognize" , add
label define V043042f    888   "888. Don't know where to rate" , add
label define V043042f    889   "889. Refused" , add
label define V043043f    777   "777. Don't recognize" , add
label define V043043f    888   "888. Don't know where to rate" , add
label define V043043f    889   "889. Refused" , add
label define V043044f    777   "777. Don't recognize" , add
label define V043044f    888   "888. Don't know where to rate" , add
label define V043044f    889   "889. Refused" , add
label define V043045f    777   "777. Don't recognize" , add
label define V043045f    888   "888. Don't know where to rate" , add
label define V043045f    889   "889. Refused" , add
label define V043046f    777   "777. Don't recognize" , add
label define V043046f    888   "888. Don't know where to rate" , add
label define V043046f    889   "889. Refused" , add
label define V043047f    777   "777. Don't recognize" , add
label define V043047f    888   "888. Don't know where to rate" , add
label define V043047f    889   "889. Refused" , add
label define V043048f    777   "777. Don't recognize" , add
label define V043048f    888   "888. Don't know where to rate" , add
label define V043048f    889   "889. Refused" , add
label define V043049f    777   "777. Don't recognize" , add
label define V043049f    888   "888. Don't know where to rate" , add
label define V043049f    889   "889. Refused" , add
label define V043050f    777   "777. Don't recognize" , add
label define V043050f    888   "888. Don't know where to rate" , add
label define V043050f    889   "889. Refused" , add
label define V043051f    777   "777. Don't recognize" , add
label define V043051f    888   "888. Don't know where to rate" , add
label define V043051f    889   "889. Refused" , add
label define V043052f    1   "1. Yes" , add
label define V043052f    5   "5. No" , add
label define V043052f    8   "8. Don't know" , add
label define V043052f    9   "9. Refused" , add
label define V043053f    0   "0. No mentions (5,8 in C1a; 8880,8888,8889 in C1b1)" , add
label define V043053f    1   "1. One mention" , add
label define V043053f    2   "2. Two mentions" , add
label define V043053f    3   "3. Three mentions" , add
label define V043053f    4   "4. Four mentions" , add
label define V043053f    5   "5. Five mentions" , add
label define V043053f    9   "9. RF (9 in C1a)" , add
label define V043053a    8877   "8877. Other miscellaneous" , add
label define V043053a    8880   "8880. No text; 'none'; 'no'; other uncodeable" , add
label define V043053a    8888   "8888. DK" , add
label define V043053a    8889   "8889. RF" , add
label define V043054f    1   "1. Yes" , add
label define V043054f    5   "5. No" , add
label define V043054f    8   "8. Don't know" , add
label define V043054f    9   "9. Refused" , add
label define V043055f    0   "0. No mentions (5,8 in C1c; 8880,8888,8889 in C1d1)" , add
label define V043055f    1   "1. One mention" , add
label define V043055f    2   "2. Two mentions" , add
label define V043055f    3   "3. Three mentions" , add
label define V043055f    4   "4. Four mentions" , add
label define V043055f    5   "5. Five mentions" , add
label define V043055f    9   "9. RF (9 in C1c)" , add
label define V043055a    8877   "8877. Other miscellaneous" , add
label define V043055a    8880   "8880. No text; 'none'; 'no'; other uncodeable" , add
label define V043055a    8888   "8888. DK" , add
label define V043055a    8889   "8889. RF" , add
label define V043056f    1   "1. Yes" , add
label define V043056f    5   "5. No" , add
label define V043056f    8   "8. Don't know" , add
label define V043056f    9   "9. Refused" , add
label define V043057f    0   "0. No mentions (5,8 in C2a; 8880,8888,8889 in C2b1)" , add
label define V043057f    1   "1. One mention" , add
label define V043057f    2   "2. Two mentions" , add
label define V043057f    3   "3. Three mentions" , add
label define V043057f    4   "4. Four mentions" , add
label define V043057f    5   "5. Five mentions" , add
label define V043057f    9   "9. RF (9 in C2a)" , add
label define V043057a    8877   "8877. Other miscellaneous" , add
label define V043057a    8880   "8880. No text; 'none'; 'no'; other uncodeable" , add
label define V043057a    8888   "8888. DK" , add
label define V043057a    8889   "8889. RF" , add
label define V043058f    1   "1. Yes" , add
label define V043058f    5   "5. No" , add
label define V043058f    8   "8. Don't know" , add
label define V043058f    9   "9. Refused" , add
label define V043059f    0   "0. No mentions (5,8 in C2c; 8880,8888,8889 in C2d1)" , add
label define V043059f    1   "1. One mention" , add
label define V043059f    2   "2. Two mentions" , add
label define V043059f    3   "3. Three mentions" , add
label define V043059f    4   "4. Four mentions" , add
label define V043059f    5   "5. Five mentions" , add
label define V043059f    9   "9. RF (9 in C2c)" , add
label define V043059a    8877   "8877. Other miscellaneous" , add
label define V043059a    8880   "8880. No text; 'none'; 'no'; other uncodeable" , add
label define V043059a    8888   "8888. DK" , add
label define V043059a    8889   "8889. RF" , add
label define V043060f    1   "1. Better when one party controls both" , add
label define V043060f    3   "3. Better when control is split" , add
label define V043060f    5   "5. It doesn't matter" , add
label define V043060f    8   "8. Don't know" , add
label define V043060f    9   "9. Refused" , add
label define V043061f    1   "1. Better" , add
label define V043061f    3   "3. Worse" , add
label define V043061f    5   "5. The same [VOL]" , add
label define V043061f    8   "8. Don't know" , add
label define V043061f    9   "9. Refused" , add
label define V043062f    1   "1. Much better" , add
label define V043062f    2   "2. Somewhat better" , add
label define V043062f    3   "3. Same (5 in C4)" , add
label define V043062f    4   "4. Somewhat worse" , add
label define V043062f    5   "5. Much worse" , add
label define V043062f    8   "8. Don't know" , add
label define V043062f    9   "9. Refused" , add
label define V043063f    1   "1. Better" , add
label define V043063f    3   "3. Worse" , add
label define V043063f    5   "5. The same" , add
label define V043063f    8   "8. Don't know" , add
label define V043063f    9   "9. Refused" , add
label define V043064f    1   "1. Much better" , add
label define V043064f    2   "2. Somewhat better" , add
label define V043064f    3   "3. Same (5 in C5)" , add
label define V043064f    4   "4. Somewhat worse" , add
label define V043064f    5   "5. Much worse" , add
label define V043064f    8   "8. Don't know" , add
label define V043064f    9   "9. Refused" , add
label define V043065f    1   "1. Yes" , add
label define V043065f    5   "5. No" , add
label define V043065f    8   "8. Don't know" , add
label define V043065f    9   "9. Refused" , add
label define V043066f    1   "1. Yes" , add
label define V043066f    5   "5. No" , add
label define V043066f    8   "8. Don't know" , add
label define V043066f    9   "9. Refused" , add
label define V043067f    1   "1. Yes" , add
label define V043067f    5   "5. No" , add
label define V043067f    8   "8. Don't know" , add
label define V043067f    9   "9. Refused" , add
label define V043068f    1   "1. Yes" , add
label define V043068f    5   "5. No" , add
label define V043068f    8   "8. Don't know" , add
label define V043068f    9   "9. Refused" , add
label define V043069f    1   "1. Yes" , add
label define V043069f    5   "5. No" , add
label define V043069f    8   "8. Don't know" , add
label define V043069f    9   "9. Refused" , add
label define V043070f    1   "1. Very often" , add
label define V043070f    2   "2. Fairly often" , add
label define V043070f    3   "3. Occasionally" , add
label define V043070f    4   "4. Rarely" , add
label define V043070f    8   "8. Don't know" , add
label define V043070f    9   "9. Refused" , add
label define V043071f    1   "1. Yes" , add
label define V043071f    5   "5. No" , add
label define V043071f    8   "8. Don't know" , add
label define V043071f    9   "9. Refused" , add
label define V043072f    1   "1. Very often" , add
label define V043072f    2   "2. Fairly often" , add
label define V043072f    3   "3. Occasionally" , add
label define V043072f    4   "4. Rarely" , add
label define V043072f    8   "8. Don't know" , add
label define V043072f    9   "9. Refused" , add
label define V043073f    1   "1. Yes" , add
label define V043073f    5   "5. No" , add
label define V043073f    8   "8. Don't know" , add
label define V043073f    9   "9. Refused" , add
label define V043074f    1   "1. Very often" , add
label define V043074f    2   "2. Fairly often" , add
label define V043074f    3   "3. Occasionally" , add
label define V043074f    4   "4. Rarely" , add
label define V043074f    8   "8. Don't know" , add
label define V043074f    9   "9. Refused" , add
label define V043075f    1   "1. Yes" , add
label define V043075f    5   "5. No" , add
label define V043075f    8   "8. Don't know" , add
label define V043075f    9   "9. Refused" , add
label define V043076f    1   "1. Very often" , add
label define V043076f    2   "2. Fairly often" , add
label define V043076f    3   "3. Occasionally" , add
label define V043076f    4   "4. Rarely" , add
label define V043076f    8   "8. Don't know" , add
label define V043076f    9   "9. Refused" , add
label define V043077f    1   "1. Yes" , add
label define V043077f    5   "5. No" , add
label define V043077f    8   "8. Don't know" , add
label define V043077f    9   "9. Refused" , add
label define V043078f    1   "1. Very often" , add
label define V043078f    2   "2. Fairly often" , add
label define V043078f    3   "3. Occasionally" , add
label define V043078f    4   "4. Rarely" , add
label define V043078f    8   "8. Don't know" , add
label define V043078f    9   "9. Refused" , add
label define V043079f    1   "1. Yes" , add
label define V043079f    5   "5. No" , add
label define V043079f    8   "8. Don't know" , add
label define V043079f    9   "9. Refused" , add
label define V043080f    1   "1. Very often" , add
label define V043080f    2   "2. Fairly often" , add
label define V043080f    3   "3. Occasionally" , add
label define V043080f    4   "4. Rarely" , add
label define V043080f    8   "8. Don't know" , add
label define V043080f    9   "9. Refused" , add
label define V043081f    1   "1. Yes" , add
label define V043081f    5   "5. No" , add
label define V043081f    8   "8. Don't know" , add
label define V043081f    9   "9. Refused" , add
label define V043082f    1   "1. Very often" , add
label define V043082f    2   "2. Fairly often" , add
label define V043082f    3   "3. Occasionally" , add
label define V043082f    4   "4. Rarely" , add
label define V043082f    8   "8. Don't know" , add
label define V043082f    9   "9. Refused" , add
label define V043083f    1   "1. Yes" , add
label define V043083f    5   "5. No" , add
label define V043083f    8   "8. Don't know" , add
label define V043083f    9   "9. Refused" , add
label define V043084f    1   "1. Very often" , add
label define V043084f    2   "2. Fairly often" , add
label define V043084f    3   "3. Occasionally" , add
label define V043084f    4   "4. Rarely" , add
label define V043084f    8   "8. Don't know" , add
label define V043084f    9   "9. Refused" , add
label define V043085f    01   "01. Extremely liberal" , add
label define V043085f    02   "02. Liberal" , add
label define V043085f    03   "03. Slightly liberal" , add
label define V043085f    04   "04. Moderate; middle of the road" , add
label define V043085f    05   "05. Slightly conservative" , add
label define V043085f    06   "06. Conservative" , add
label define V043085f    07   "07. Extremely conservative" , add
label define V043085f    80   "80. Haven't thought much [DO NOT PROBE]" , add
label define V043085f    88   "88. Don't know" , add
label define V043085f    89   "89. Refused" , add
label define V043085a    1   "1. Liberal" , add
label define V043085a    3   "3. Conservative" , add
label define V043085a    5   "5. Moderate [VOL]" , add
label define V043085a    8   "8. Don't know" , add
label define V043085a    9   "9. RF" , add
label define V043086f    1   "1. Liberal" , add
label define V043086f    3   "3. Moderate" , add
label define V043086f    5   "5. Conservative" , add
label define V043086f    7   "7. Refused to choose" , add
label define V043086f    8   "8. Don't know" , add
label define V043087f    1   "1. Extremely liberal" , add
label define V043087f    2   "2. Liberal" , add
label define V043087f    3   "3. Slightly liberal" , add
label define V043087f    4   "4. Moderate; middle of the road" , add
label define V043087f    5   "5. Slightly conservative" , add
label define V043087f    6   "6. Conservative" , add
label define V043087f    7   "7. Extremely conservative" , add
label define V043087f    8   "8. Don't know" , add
label define V043087f    9   "9. Refused" , add
label define V043088f    1   "1. Extremely liberal" , add
label define V043088f    2   "2. Liberal" , add
label define V043088f    3   "3. Slightly liberal" , add
label define V043088f    4   "4. Moderate; middle of the road" , add
label define V043088f    5   "5. Slightly conservative" , add
label define V043088f    6   "6. Conservative" , add
label define V043088f    7   "7. Extremely conservative" , add
label define V043088f    8   "8. Don't know" , add
label define V043088f    9   "9. Refused" , add
label define V043089f    1   "1. Extremely liberal" , add
label define V043089f    2   "2. Liberal" , add
label define V043089f    3   "3. Slightly liberal" , add
label define V043089f    4   "4. Moderate; middle of the road" , add
label define V043089f    5   "5. Slightly conservative" , add
label define V043089f    6   "6. Conservative" , add
label define V043089f    7   "7. Extremely conservative" , add
label define V043089f    8   "8. Don't know" , add
label define V043089f    9   "9. Refused" , add
label define V043090f    1   "1. Extremely liberal" , add
label define V043090f    2   "2. Liberal" , add
label define V043090f    3   "3. Slightly liberal" , add
label define V043090f    4   "4. Moderate; middle of the road" , add
label define V043090f    5   "5. Slightly conservative" , add
label define V043090f    6   "6. Conservative" , add
label define V043090f    7   "7. Extremely conservative" , add
label define V043090f    8   "8. Don't know" , add
label define V043090f    9   "9. Refused" , add
label define V043091f    1   "1. Extremely liberal" , add
label define V043091f    2   "2. Liberal" , add
label define V043091f    3   "3. Slightly liberal" , add
label define V043091f    4   "4. Moderate; middle of the road" , add
label define V043091f    5   "5. Slightly conservative" , add
label define V043091f    6   "6. Conservative" , add
label define V043091f    7   "7. Extremely conservative" , add
label define V043091f    8   "8. Don't know" , add
label define V043091f    9   "9. Refused" , add
label define V043092f    1   "1. Care a good deal" , add
label define V043092f    3   "3. Don't care very much" , add
label define V043092f    8   "8. Don't know" , add
label define V043092f    9   "9. Refused" , add
label define V043093f    1   "1. John Kerry" , add
label define V043093f    3   "3. George W. Bush" , add
label define V043093f    5   "5. Ralph Nader" , add
label define V043093f    7   "7. Other (SPECIFY) [VOL]" , add
label define V043093f    8   "8. Don't know" , add
label define V043093f    9   "9. Refused" , add
label define V043094f    00   "00. Will be close - DK winner" , add
label define V043094f    11   "11. Will be close - Kerry will win" , add
label define V043094f    12   "12. Will be close - Bush will win" , add
label define V043094f    13   "13. Will be close - Nader will win" , add
label define V043094f    14   "14. Will be close - other candidate will win" , add
label define V043094f    25   "25. Win by quite a bit - Kerry" , add
label define V043094f    26   "26. Win by quite a bit - Bush" , add
label define V043094f    27   "27. Win by quite a bit - Nader" , add
label define V043094f    28   "28. Win by quite a bit - other candidate" , add
label define V043094f    29   "29. Win by quite a bit - DK who" , add
label define V043094f    88   "88. Don't know" , add
label define V043094f    89   "89. Refused" , add
label define V043094f    99   "99. NA" , add
label define V043095f    1   "1. John Kerry" , add
label define V043095f    3   "3. George W. Bush" , add
label define V043095f    5   "5. Ralph Nader" , add
label define V043095f    7   "7. Other (SPECIFY) [VOL]" , add
label define V043095f    8   "8. Don't know" , add
label define V043095f    9   "9. Refused" , add
label define V043096f    00   "00. Will be close - DK winner" , add
label define V043096f    11   "11. Will be close - Kerry will win" , add
label define V043096f    12   "12. Will be close - Bush will win" , add
label define V043096f    13   "13. Will be close - Nader will win" , add
label define V043096f    14   "14. Will be close - other candidate will win" , add
label define V043096f    25   "25. Win by quite a bit - Kerry" , add
label define V043096f    26   "26. Win by quite a bit - Bush" , add
label define V043096f    27   "27. Win by quite a bit - Nader" , add
label define V043096f    28   "28. Win by quite a bit - other candidate" , add
label define V043096f    29   "29. Win by quite a bit - DK who" , add
label define V043096f    88   "88. Don't know" , add
label define V043096f    89   "89. Refused" , add
label define V043096f    99   "99. NA" , add
label define V043097f    1   "1. Gotten better" , add
label define V043097f    3   "3. Stayed about the same" , add
label define V043097f    5   "5. Gotten worse" , add
label define V043097f    8   "8. Don't know" , add
label define V043097f    9   "9. Refused" , add
label define V043098f    1   "1. Much better" , add
label define V043098f    2   "2. Somewhat better" , add
label define V043098f    3   "3. Same (3 in F1)" , add
label define V043098f    4   "4. Somewhat worse" , add
label define V043098f    5   "5. Much worse" , add
label define V043098f    8   "8. Don't know" , add
label define V043098f    9   "9. Refused" , add
label define V043099f    1   "1. Get better" , add
label define V043099f    3   "3. Stay about the same" , add
label define V043099f    5   "5. Get worse" , add
label define V043099f    8   "8. Don't know" , add
label define V043099f    9   "9. Refused" , add
label define V043100f    1   "1. Much better" , add
label define V043100f    2   "2. Somewhat better" , add
label define V043100f    3   "3. Same (3 in F2)" , add
label define V043100f    4   "4. Somewhat worse" , add
label define V043100f    5   "5. Much worse" , add
label define V043100f    8   "8. Don't know" , add
label define V043100f    9   "9. Refused" , add
label define V043101f    1   "1. Better" , add
label define V043101f    3   "3. Stayed same" , add
label define V043101f    5   "5. Worse" , add
label define V043101f    8   "8. Don't know" , add
label define V043101f    9   "9. Refused" , add
label define V043101f    0   "0. NA" , add
label define V043102f    1   "1. Much better" , add
label define V043102f    2   "2. Somewhat better" , add
label define V043102f    3   "3. Same (3 in F3)" , add
label define V043102f    4   "4. Somewhat worse" , add
label define V043102f    5   "5. Much worse" , add
label define V043102f    8   "8. Don't know" , add
label define V043102f    9   "9. Refused" , add
label define V043103f    1   "1. More unemployment" , add
label define V043103f    3   "3. About the same" , add
label define V043103f    5   "5. Less unemployment" , add
label define V043103f    8   "8. Don't know" , add
label define V043103f    9   "9. Refused" , add
label define V043103f    0   "0. NA" , add
label define V043104f    1   "1. Better" , add
label define V043104f    3   "3. Stayed same" , add
label define V043104f    5   "5. Worse" , add
label define V043104f    8   "8. Don't know" , add
label define V043104f    9   "9. Refused" , add
label define V043104f    0   "0. NA" , add
label define V043105f    1   "1. Much better" , add
label define V043105f    2   "2. Somewhat better" , add
label define V043105f    3   "3. Same (3 in F5)" , add
label define V043105f    4   "4. Somewhat worse" , add
label define V043105f    5   "5. Much worse" , add
label define V043105f    8   "8. Don't know" , add
label define V043105f    9   "9. Refused" , add
label define V043106f    1   "1. Higher inflation" , add
label define V043106f    3   "3. About the same" , add
label define V043106f    5   "5. Lower inflation" , add
label define V043106f    8   "8. Don't know" , add
label define V043106f    9   "9. Refused" , add
label define V043106f    0   "0. NA" , add
label define V043107f    01   "01. U.S. should solve with diplomacy and international pressure" , add
label define V043107f    07   "07. U.S. must be ready to use military force" , add
label define V043107f    80   "80. Haven't thought much about this" , add
label define V043107f    88   "88. Don't know" , add
label define V043107f    89   "89. Refused" , add
label define V043108f    1   "1. Extremely important" , add
label define V043108f    2   "2. Very important" , add
label define V043108f    3   "3. Somewhat important" , add
label define V043108f    4   "4. Not too important" , add
label define V043108f    5   "5. Not at all important" , add
label define V043108f    8   "8. Don't know" , add
label define V043108f    9   "9. Refused" , add
label define V043109f    1   "1. Democrats" , add
label define V043109f    3   "3. Republicans" , add
label define V043109f    5   "5. Wouldn't be much difference between them/no difference" , add
label define V043109f    7   "7. Neither party [VOL]" , add
label define V043109f    8   "8. Don't know" , add
label define V043109f    9   "9. Refused" , add
label define V043110f    1   "1. Democrats" , add
label define V043110f    3   "3. Republicans" , add
label define V043110f    5   "5. About the same by both" , add
label define V043110f    7   "7. Neither party [VOL]" , add
label define V043110f    8   "8. Don't know" , add
label define V043110f    9   "9. Refused" , add
label define V043111f    1   "1. Democrats" , add
label define V043111f    3   "3. Republicans" , add
label define V043111f    5   "5. About the same by both" , add
label define V043111f    7   "7. Neither party [VOL]" , add
label define V043111f    8   "8. Don't know" , add
label define V043111f    9   "9. Refused" , add
label define V043112f    1   "1. Weaker" , add
label define V043112f    3   "3. Stayed about the same" , add
label define V043112f    5   "5. Stronger" , add
label define V043112f    8   "8. Don't know" , add
label define V043112f    9   "9. Refused" , add
label define V043113f    1   "1. Agree" , add
label define V043113f    5   "5. Disagree" , add
label define V043113f    8   "8. Don't know" , add
label define V043113f    9   "9. Refused" , add
label define V043114f    1   "1. Republican" , add
label define V043114f    2   "2. Democrat" , add
label define V043114f    3   "3. Independent" , add
label define V043114f    4   "4. Other party (SPECIFY)" , add
label define V043114f    5   "5. No preference" , add
label define V043114f    8   "8. Don't know" , add
label define V043114f    9   "9. Refused" , add
label define V043114a    1   "1. Strong" , add
label define V043114a    5   "5. Not very strong" , add
label define V043114a    8   "8. Don't know" , add
label define V043114a    9   "9. Refused" , add
label define V043115f    1   "1. Closer to Republican" , add
label define V043115f    3   "3. Neither [VOL]" , add
label define V043115f    5   "5. Closer to Democratic" , add
label define V043115f    8   "8. Don't know" , add
label define V043115f    9   "9. Refused" , add
label define V043116f    0   "0. Strong Democrat (2/1/.)" , add
label define V043116f    1   "1. Weak Democrat (2/5-8-9/.)" , add
label define V043116f    2   "2. Independent-Democrat (3-4-5/./5)" , add
label define V043116f    3   "3. Independent-Independent" , add
label define V043116f    4   "4. Independent-Republican (3-4-5/./1)" , add
label define V043116f    5   "5. Weak Republican (1/5-8-9/.)" , add
label define V043116f    6   "6. Strong Republican (1/1/.)" , add
label define V043116f    7   "7. Other; minor party; refuses to say" , add
label define V043116f    8   "8. Apolitical (5/./3-8-9 if apolitical)" , add
label define V043116f    9   "9. DK (8/./.)" , add
label define V043117f    1   "1. Extremely well" , add
label define V043117f    2   "2. Quite well" , add
label define V043117f    3   "3. Not too well" , add
label define V043117f    4   "4. Not well at all" , add
label define V043117f    8   "8. Don't know" , add
label define V043117f    9   "9. Refused" , add
label define V043118f    1   "1. Extremely well" , add
label define V043118f    2   "2. Quite well" , add
label define V043118f    3   "3. Not too well" , add
label define V043118f    4   "4. Not well at all" , add
label define V043118f    8   "8. Don't know" , add
label define V043118f    9   "9. Refused" , add
label define V043119f    1   "1. Extremely well" , add
label define V043119f    2   "2. Quite well" , add
label define V043119f    3   "3. Not too well" , add
label define V043119f    4   "4. Not well at all" , add
label define V043119f    8   "8. Don't know" , add
label define V043119f    9   "9. Refused" , add
label define V043120f    1   "1. Extremely well" , add
label define V043120f    2   "2. Quite well" , add
label define V043120f    3   "3. Not too well" , add
label define V043120f    4   "4. Not well at all" , add
label define V043120f    8   "8. Don't know" , add
label define V043120f    9   "9. Refused" , add
label define V043121f    1   "1. Extremely well" , add
label define V043121f    2   "2. Quite well" , add
label define V043121f    3   "3. Not too well" , add
label define V043121f    4   "4. Not well at all" , add
label define V043121f    8   "8. Don't know" , add
label define V043121f    9   "9. Refused" , add
label define V043122f    1   "1. Extremely well" , add
label define V043122f    2   "2. Quite well" , add
label define V043122f    3   "3. Not too well" , add
label define V043122f    4   "4. Not well at all" , add
label define V043122f    8   "8. Don't know" , add
label define V043122f    9   "9. Refused" , add
label define V043123f    1   "1. Extremely well" , add
label define V043123f    2   "2. Quite well" , add
label define V043123f    3   "3. Not too well" , add
label define V043123f    4   "4. Not well at all" , add
label define V043123f    8   "8. Don't know" , add
label define V043123f    9   "9. Refused" , add
label define V043124f    1   "1. Extremely well" , add
label define V043124f    2   "2. Quite well" , add
label define V043124f    3   "3. Not too well" , add
label define V043124f    4   "4. Not well at all" , add
label define V043124f    8   "8. Don't know" , add
label define V043124f    9   "9. Refused" , add
label define V043125f    1   "1. Extremely well" , add
label define V043125f    2   "2. Quite well" , add
label define V043125f    3   "3. Not too well" , add
label define V043125f    4   "4. Not well at all" , add
label define V043125f    8   "8. Don't know" , add
label define V043125f    9   "9. Refused" , add
label define V043126f    1   "1. Extremely well" , add
label define V043126f    2   "2. Quite well" , add
label define V043126f    3   "3. Not too well" , add
label define V043126f    4   "4. Not well at all" , add
label define V043126f    8   "8. Don't know" , add
label define V043126f    9   "9. Refused" , add
label define V043127f    1   "1. Extremely well" , add
label define V043127f    2   "2. Quite well" , add
label define V043127f    3   "3. Not too well" , add
label define V043127f    4   "4. Not well at all" , add
label define V043127f    8   "8. Don't know" , add
label define V043127f    9   "9. Refused" , add
label define V043128f    1   "1. Extremely well" , add
label define V043128f    2   "2. Quite well" , add
label define V043128f    3   "3. Not too well" , add
label define V043128f    4   "4. Not well at all" , add
label define V043128f    8   "8. Don't know" , add
label define V043128f    9   "9. Refused" , add
label define V043129f    1   "1. Extremely well" , add
label define V043129f    2   "2. Quite well" , add
label define V043129f    3   "3. Not too well" , add
label define V043129f    4   "4. Not well at all" , add
label define V043129f    8   "8. Don't know" , add
label define V043129f    9   "9. Refused" , add
label define V043130f    1   "1. Extremely well" , add
label define V043130f    2   "2. Quite well" , add
label define V043130f    3   "3. Not too well" , add
label define V043130f    4   "4. Not well at all" , add
label define V043130f    8   "8. Don't know" , add
label define V043130f    9   "9. Refused" , add
label define V043131f    1   "1. Worth it" , add
label define V043131f    5   "5. Not worth it" , add
label define V043131f    8   "8. Don't know" , add
label define V043131f    9   "9. Refused" , add
label define V043132f    1   "1. Approve" , add
label define V043132f    5   "5. Disapprove" , add
label define V043132f    8   "8. Don't know" , add
label define V043132f    9   "9. Refused" , add
label define V043133f    1   "1. Approve strongly" , add
label define V043133f    2   "2. Approve not strongly" , add
label define V043133f    4   "4. Disapprove not strongly" , add
label define V043133f    5   "5. Disapprove strongly" , add
label define V043133f    8   "8. Don't know" , add
label define V043133f    9   "9. Refused" , add
label define V043134f    1   "1. Worth it" , add
label define V043134f    5   "5. Not worth it" , add
label define V043134f    8   "8. Don't know" , add
label define V043134f    9   "9. Refused" , add
label define V043135f    1   "1. Increased" , add
label define V043135f    3   "3. Decreased" , add
label define V043135f    5   "5. Stayed about the same" , add
label define V043135f    8   "8. Don't know" , add
label define V043135f    9   "9. Refused" , add
label define V043136f    01   "01. Govt should provide many fewer services" , add
label define V043136f    07   "07. Govt should provide many more services" , add
label define V043136f    80   "80. Haven't thought much about this" , add
label define V043136f    88   "88. Don't know" , add
label define V043136f    89   "89. Refused" , add
label define V043137f    1   "1. Extremely important" , add
label define V043137f    2   "2. Very important" , add
label define V043137f    3   "3. Somewhat important" , add
label define V043137f    4   "4. Not too important" , add
label define V043137f    5   "5. Not at all important" , add
label define V043137f    8   "8. Don't know" , add
label define V043137f    9   "9. Refused" , add
label define V043138f    1   "1. Govt should provide many fewer services" , add
label define V043138f    7   "7. Govt should provide many more services" , add
label define V043138f    8   "8. Don't know" , add
label define V043138f    9   "9. Refused" , add
label define V043139f    1   "1. Govt should provide many fewer services" , add
label define V043139f    7   "7. Govt should provide many more services" , add
label define V043139f    8   "8. Don't know" , add
label define V043139f    9   "9. Refused" , add
label define V043140f    1   "1. Govt should provide many fewer services" , add
label define V043140f    7   "7. Govt should provide many more services" , add
label define V043140f    8   "8. Don't know" , add
label define V043140f    9   "9. Refused" , add
label define V043141f    1   "1. Govt should provide many fewer services" , add
label define V043141f    7   "7. Govt should provide many more services" , add
label define V043141f    8   "8. Don't know" , add
label define V043141f    9   "9. Refused" , add
label define V043142f    01   "01. Govt should decrease defense spending" , add
label define V043142f    07   "07. Govt should increase defense spending" , add
label define V043142f    80   "80. Haven't thought much about this" , add
label define V043142f    88   "88. Don't know" , add
label define V043142f    89   "89. Refused" , add
label define V043143f    1   "1. Extremely important" , add
label define V043143f    2   "2. Very important" , add
label define V043143f    3   "3. Somewhat important" , add
label define V043143f    4   "4. Not too important" , add
label define V043143f    5   "5. Not at all important" , add
label define V043143f    8   "8. Don't know" , add
label define V043143f    9   "9. Refused" , add
label define V043144f    1   "1. Govt should decrease defense spending" , add
label define V043144f    7   "7. Govt should increase defense spending" , add
label define V043144f    8   "8. Don't know" , add
label define V043144f    9   "9. Refused" , add
label define V043145f    1   "1. Govt should decrease defense spending" , add
label define V043145f    7   "7. Govt should increase defense spending" , add
label define V043145f    8   "8. Don't know" , add
label define V043145f    9   "9. Refused" , add
label define V043146f    1   "1. Govt should decrease defense spending" , add
label define V043146f    7   "7. Govt should increase defense spending" , add
label define V043146f    8   "8. Don't know" , add
label define V043146f    9   "9. Refused" , add
label define V043147f    1   "1. Govt should decrease defense spending" , add
label define V043147f    7   "7. Govt should increase defense spending" , add
label define V043147f    8   "8. Don't know" , add
label define V043147f    9   "9. Refused" , add
label define V043148f    1   "1. Favor" , add
label define V043148f    3   "3. Oppose" , add
label define V043148f    5   "5. Other/neither/depends {SPECIFY}" , add
label define V043148f    7   "7. Haven't thought about" , add
label define V043148f    8   "8. Don't know" , add
label define V043148f    9   "9. Refused" , add
label define V043149f    1   "1. Favored strongly" , add
label define V043149f    2   "2. Favored not strongly" , add
label define V043149f    4   "4. Opposed not strongly" , add
label define V043149f    5   "5. Opposed strongly" , add
label define V043149f    7   "7. Other/neither/depends (5 in N3)" , add
label define V043149f    8   "8. Don't know" , add
label define V043149f    9   "9. Refused" , add
label define V043149f    0   "0. Haven't thought about it (7 in N3)" , add
label define V043150f    01   "01. Govt insurance plan" , add
label define V043150f    07   "07. Private insurance plan" , add
label define V043150f    80   "80. Haven't thought much" , add
label define V043150f    88   "88. Don't know" , add
label define V043150f    89   "89. Refused" , add
label define V043151f    1   "1. Extremely important" , add
label define V043151f    2   "2. Very important" , add
label define V043151f    3   "3. Somewhat important" , add
label define V043151f    4   "4. Not too important" , add
label define V043151f    5   "5. Not at all important" , add
label define V043151f    8   "8. Don't know" , add
label define V043151f    9   "9. Refused" , add
label define V043152f    01   "01. Govt should see to jobs and standard of living" , add
label define V043152f    07   "07. Govt should let each person get ahead on own" , add
label define V043152f    80   "80. Haven't thought much about this" , add
label define V043152f    88   "88. Don't know" , add
label define V043152f    89   "89. Refused" , add
label define V043153f    1   "1. Extremely important" , add
label define V043153f    2   "2. Very important" , add
label define V043153f    3   "3. Somewhat important" , add
label define V043153f    4   "4. Not too important" , add
label define V043153f    5   "5. Not at all important" , add
label define V043153f    8   "8. Don't know" , add
label define V043153f    9   "9. Refused" , add
label define V043154f    1   "1. Govt should see to jobs and standard of living" , add
label define V043154f    7   "7. Govt should let each person get ahead on own" , add
label define V043154f    8   "8. Don't know" , add
label define V043154f    9   "9. Refused" , add
label define V043155f    1   "1. Govt should see to jobs and standard of living" , add
label define V043155f    7   "7. Govt should let each person get ahead on own" , add
label define V043155f    8   "8. Don't know" , add
label define V043155f    9   "9. Refused" , add
label define V043156f    1   "1. Govt should see to jobs and standard of living" , add
label define V043156f    7   "7. Govt should let each person get ahead on own" , add
label define V043156f    8   "8. Don't know" , add
label define V043156f    9   "9. Refused" , add
label define V043157f    1   "1. Govt should see to jobs and standard of living" , add
label define V043157f    7   "7. Govt should let each person get ahead on own" , add
label define V043157f    8   "8. Don't know" , add
label define V043157f    9   "9. Refused" , add
label define V043158f    01   "01. Govt should help blacks" , add
label define V043158f    07   "07. Blacks should help themselves" , add
label define V043158f    80   "80. Haven't thought much about this" , add
label define V043158f    88   "88. Don't know" , add
label define V043158f    89   "89. Refused" , add
label define V043159f    1   "1. Extremely important" , add
label define V043159f    2   "2. Very important" , add
label define V043159f    3   "3. Somewhat important" , add
label define V043159f    4   "4. Not too important" , add
label define V043159f    5   "5. Not at all important" , add
label define V043159f    8   "8. Don't know" , add
label define V043159f    9   "9. Refused" , add
label define V043160f    1   "1. Govt should help blacks" , add
label define V043160f    7   "7. Blacks should help themselves" , add
label define V043160f    8   "8. Don't know" , add
label define V043160f    9   "9. Refused" , add
label define V043161f    1   "1. Govt should help blacks" , add
label define V043161f    7   "7. Blacks should help themselves" , add
label define V043161f    8   "8. Don't know" , add
label define V043161f    9   "9. Refused" , add
label define V043162f    1   "1. Govt should help blacks" , add
label define V043162f    7   "7. Blacks should help themselves" , add
label define V043162f    8   "8. Don't know" , add
label define V043162f    9   "9. Refused" , add
label define V043163f    1   "1. Govt should help blacks" , add
label define V043163f    7   "7. Blacks should help themselves" , add
label define V043163f    8   "8. Don't know" , add
label define V043163f    9   "9. Refused" , add
label define V043164f    1   "1. Increased" , add
label define V043164f    3   "3. Decreased" , add
label define V043164f    5   "5. Kept about the same" , add
label define V043164f    7   "7. Cut out entirely [VOL]" , add
label define V043164f    8   "8. Don't know" , add
label define V043164f    9   "9. Refused" , add
label define V043165f    1   "1. Increased" , add
label define V043165f    3   "3. Decreased" , add
label define V043165f    5   "5. Kept about the same" , add
label define V043165f    7   "7. Cut out entirely [VOL]" , add
label define V043165f    8   "8. Don't know" , add
label define V043165f    9   "9. Refused" , add
label define V043166f    1   "1. Increased" , add
label define V043166f    3   "3. Decreased" , add
label define V043166f    5   "5. Kept about the same" , add
label define V043166f    7   "7. Cut out entirely [VOL]" , add
label define V043166f    8   "8. Don't know" , add
label define V043166f    9   "9. Refused" , add
label define V043167f    1   "1. Increased" , add
label define V043167f    3   "3. Decreased" , add
label define V043167f    5   "5. Kept about the same" , add
label define V043167f    7   "7. Cut out entirely [VOL]" , add
label define V043167f    8   "8. Don't know" , add
label define V043167f    9   "9. Refused" , add
label define V043168f    1   "1. Increased" , add
label define V043168f    3   "3. Decreased" , add
label define V043168f    5   "5. Kept about the same" , add
label define V043168f    7   "7. Cut out entirely [VOL]" , add
label define V043168f    8   "8. Don't know" , add
label define V043168f    9   "9. Refused" , add
label define V043169f    1   "1. Increased" , add
label define V043169f    3   "3. Decreased" , add
label define V043169f    5   "5. Kept about the same" , add
label define V043169f    7   "7. Cut out entirely [VOL]" , add
label define V043169f    8   "8. Don't know" , add
label define V043169f    9   "9. Refused" , add
label define V043170f    1   "1. Increased" , add
label define V043170f    3   "3. Decreased" , add
label define V043170f    5   "5. Kept about the same" , add
label define V043170f    7   "7. Cut out entirely [VOL]" , add
label define V043170f    8   "8. Don't know" , add
label define V043170f    9   "9. Refused" , add
label define V043171f    1   "1. Increased" , add
label define V043171f    3   "3. Decreased" , add
label define V043171f    5   "5. Kept about the same" , add
label define V043171f    7   "7. Cut out entirely [VOL]" , add
label define V043171f    8   "8. Don't know" , add
label define V043171f    9   "9. Refused" , add
label define V043172f    1   "1. Increased" , add
label define V043172f    3   "3. Decreased" , add
label define V043172f    5   "5. Kept about the same" , add
label define V043172f    7   "7. Cut out entirely [VOL]" , add
label define V043172f    8   "8. Don't know" , add
label define V043172f    9   "9. Refused" , add
label define V043173f    1   "1. Increased" , add
label define V043173f    3   "3. Decreased" , add
label define V043173f    5   "5. Kept about the same" , add
label define V043173f    7   "7. Cut out entirely [VOL]" , add
label define V043173f    8   "8. Don't know" , add
label define V043173f    9   "9. Refused" , add
label define V043174f    1   "1. Increased" , add
label define V043174f    3   "3. Decreased" , add
label define V043174f    5   "5. Kept about the same" , add
label define V043174f    7   "7. Cut out entirely [VOL]" , add
label define V043174f    8   "8. Don't know" , add
label define V043174f    9   "9. Refused" , add
label define V043175f    1   "1. More than should pay" , add
label define V043175f    3   "3. About right" , add
label define V043175f    5   "5. Less than should pay" , add
label define V043175f    7   "7. Don't pay at all {VOL}" , add
label define V043175f    8   "8. Don't know" , add
label define V043175f    9   "9. Refused" , add
label define V043176f    1   "1. More than should pay" , add
label define V043176f    3   "3. About right" , add
label define V043176f    5   "5. Less than should pay" , add
label define V043176f    7   "7. Don't pay at all {VOL}" , add
label define V043176f    8   "8. Don't know" , add
label define V043176f    9   "9. Refused" , add
label define V043177f    1   "1. More than should pay" , add
label define V043177f    3   "3. About right" , add
label define V043177f    5   "5. Less than should pay" , add
label define V043177f    7   "7. Don't pay at all {VOL}" , add
label define V043177f    8   "8. Don't know" , add
label define V043177f    9   "9. Refused" , add
label define V043178f    1   "1. Favor" , add
label define V043178f    5   "5. Oppose" , add
label define V043178f    8   "8. Don't know" , add
label define V043178f    9   "9. Refused" , add
label define V043179f    1   "1. Favor strongly" , add
label define V043179f    2   "2. Favor not strongly" , add
label define V043179f    4   "4. Oppose not strongly" , add
label define V043179f    5   "5. Oppose strongly" , add
label define V043179f    8   "8. Don't know" , add
label define V043179f    9   "9. Refused" , add
label define V043180f    1   "1. Favor" , add
label define V043180f    5   "5. Oppose" , add
label define V043180f    8   "8. Don't know" , add
label define V043180f    9   "9. Refused" , add
label define V043181f    1   "1. Favor strongly" , add
label define V043181f    2   "2. Favor not strongly" , add
label define V043181f    4   "4. Oppose not strongly" , add
label define V043181f    5   "5. Oppose strongly" , add
label define V043181f    8   "8. Don't know" , add
label define V043181f    9   "9. Refused" , add
label define V043182f    01   "01. Protect environment, even if it costs jobs" , add
label define V043182f    07   "07. Jobs & standard of living more important" , add
label define V043182f    80   "80. Haven't thought much about this" , add
label define V043182f    88   "88. Don't know" , add
label define V043182f    89   "89. Refused" , add
label define V043183f    1   "1. Extremely important" , add
label define V043183f    2   "2. Very important" , add
label define V043183f    3   "3. Somewhat important" , add
label define V043183f    4   "4. Not too important" , add
label define V043183f    5   "5. Not at all important" , add
label define V043183f    8   "8. Don't know" , add
label define V043183f    9   "9. Refused" , add
label define V043184f    1   "1. Protect environment, even if it costs jobs" , add
label define V043184f    7   "7. Jobs & standard of living more important" , add
label define V043184f    8   "8. Don't know" , add
label define V043184f    9   "9. Refused" , add
label define V043185f    1   "1. Protect environment, even if it costs jobs" , add
label define V043185f    7   "7. Jobs & standard of living more important" , add
label define V043185f    8   "8. Don't know" , add
label define V043185f    9   "9. Refused" , add
label define V043186f    1   "1. Favor" , add
label define V043186f    5   "5. Oppose" , add
label define V043186f    8   "8. Don't know" , add
label define V043186f    9   "9. Refused" , add
label define V043187f    1   "1. Favor strongly" , add
label define V043187f    2   "2. Favor not strongly" , add
label define V043187f    4   "4. Oppose not strongly" , add
label define V043187f    5   "5. Oppose strongly" , add
label define V043187f    8   "8. Don't know" , add
label define V043187f    9   "9. Refused" , add
label define V043188f    1   "1. More difficult" , add
label define V043188f    3   "3. Make it easier" , add
label define V043188f    5   "5. Keep these rules about the same" , add
label define V043188f    8   "8. Don't know" , add
label define V043188f    9   "9. Refused" , add
label define V043189f    1   "1. A lot more difficult" , add
label define V043189f    2   "2. Somewhat more difficult" , add
label define V043189f    3   "3. About the same (5 in P5a)" , add
label define V043189f    4   "4. Somewhat easier" , add
label define V043189f    5   "5. A lot easier" , add
label define V043189f    8   "8. Don't know" , add
label define V043189f    9   "9. Refused" , add
label define V043190f    1   "1. Extremely important" , add
label define V043190f    2   "2. Very important" , add
label define V043190f    3   "3. Somewhat important" , add
label define V043190f    4   "4. Not too important" , add
label define V043190f    5   "5. Not at all important" , add
label define V043190f    8   "8. Don't know" , add
label define V043190f    9   "9. Refused" , add
label define V043191f    1   "1. More difficult" , add
label define V043191f    3   "3. Make it easier" , add
label define V043191f    5   "5. Keep these rules about the same" , add
label define V043191f    8   "8. Don't know" , add
label define V043191f    9   "9. Refused" , add
label define V043192f    1   "1. A lot more difficult" , add
label define V043192f    2   "2. Somewhat more difficult" , add
label define V043192f    3   "3. About the same (5 in P5b)" , add
label define V043192f    4   "4. Somewhat easier" , add
label define V043192f    5   "5. A lot easier" , add
label define V043192f    8   "8. Don't know" , add
label define V043192f    9   "9. Refused" , add
label define V043193f    1   "1. More difficult" , add
label define V043193f    3   "3. Make it easier" , add
label define V043193f    5   "5. Keep these rules about the same" , add
label define V043193f    8   "8. Don't know" , add
label define V043193f    9   "9. Refused" , add
label define V043194f    1   "1. A lot more difficult" , add
label define V043194f    2   "2. Somewhat more difficult" , add
label define V043194f    3   "3. About the same (5 in P5c)" , add
label define V043194f    4   "4. Somewhat easier" , add
label define V043194f    5   "5. A lot easier" , add
label define V043194f    8   "8. Don't know" , add
label define V043194f    9   "9. Refused" , add
label define V043195f    1   "1. Yes" , add
label define V043195f    5   "5. No" , add
label define V043195f    8   "8. Don't know" , add
label define V043195f    9   "9. Refused" , add
label define V043196f    01   "01. Women and men should have equal roles" , add
label define V043196f    07   "07. A woman's place is in the home" , add
label define V043196f    80   "80. Haven't thought much about this" , add
label define V043196f    88   "88. Don't know" , add
label define V043196f    89   "89. Refused" , add
label define V043197f    1   "1. Extremely important" , add
label define V043197f    2   "2. Very important" , add
label define V043197f    3   "3. Somewhat important" , add
label define V043197f    4   "4. Not too important" , add
label define V043197f    5   "5. Not at all important" , add
label define V043197f    8   "8. Don't know" , add
label define V043197f    9   "9. Refused" , add
label define V043198f    1   "1. Women and men should have equal roles" , add
label define V043198f    7   "7. A woman's place is in the home" , add
label define V043198f    8   "8. Don't know" , add
label define V043198f    9   "9. Refused" , add
label define V043199f    1   "1. Women and men should have equal roles" , add
label define V043199f    7   "7. A woman's place is in the home" , add
label define V043199f    8   "8. Don't know" , add
label define V043199f    9   "9. Refused" , add
label define V043200f    1   "1. Women and men should have equal roles" , add
label define V043200f    7   "7. A woman's place is in the home" , add
label define V043200f    8   "8. Don't know" , add
label define V043200f    9   "9. Refused" , add
label define V043201f    1   "1. Women and men should have equal roles" , add
label define V043201f    7   "7. A woman's place is in the home" , add
label define V043201f    8   "8. Don't know" , add
label define V043201f    9   "9. Refused" , add
label define V043202f    1   "1. Yes" , add
label define V043202f    5   "5. No" , add
label define V043202f    8   "8. Don't know" , add
label define V043202f    9   "9. Refused" , add
label define V043203f    1   "1. John Kerry" , add
label define V043203f    2   "2. George W. Bush" , add
label define V043203f    3   "3. Ralph Nader" , add
label define V043203f    5   "5. None (if voter, will not vote for president) [VOL]" , add
label define V043203f    7   "7. Other (SPECIFY)" , add
label define V043203f    8   "8. Don't know" , add
label define V043203f    9   "9. Refused" , add
label define V043204f    00   "00. No preference" , add
label define V043204f    11   "11. Not strong - Kerry" , add
label define V043204f    12   "12. Not strong - Bush" , add
label define V043204f    13   "13. Not strong - Nader" , add
label define V043204f    14   "14. Not strong - other candidate" , add
label define V043204f    25   "25. Strong - Kerry" , add
label define V043204f    26   "26. Strong - Bush" , add
label define V043204f    27   "27. Strong - Nader" , add
label define V043204f    28   "28. Strong - other candidate" , add
label define V043204f    88   "88. Don't know" , add
label define V043204f    89   "89. Refused" , add
label define V043205f    1   "1. Extremely good" , add
label define V043205f    2   "2. Very good" , add
label define V043205f    3   "3. Somewhat good" , add
label define V043205f    4   "4. Not very good" , add
label define V043205f    7   "7. Don't feel anything [VOL]" , add
label define V043205f    8   "8. Don't know" , add
label define V043205f    9   "9. Refused" , add
label define V043206f    1   "1. Agree" , add
label define V043206f    3   "3. Neither agree nor disagree" , add
label define V043206f    5   "5. Disagree" , add
label define V043206f    8   "8. Don't know" , add
label define V043206f    9   "9. Refused" , add
label define V043207f    1   "1. Agree" , add
label define V043207f    3   "3. Neither agree nor disagree" , add
label define V043207f    5   "5. Disagree" , add
label define V043207f    8   "8. Don't know" , add
label define V043207f    9   "9. Refused" , add
label define V043208f    1   "1. Extremely strong" , add
label define V043208f    2   "2. Very strong" , add
label define V043208f    4   "4. Somewhat strong" , add
label define V043208f    5   "5. Not very strong" , add
label define V043208f    8   "8. Don't know" , add
label define V043208f    9   "9. Refused" , add
label define V043209f    1   "1. Extremely important" , add
label define V043209f    2   "2. Very important" , add
label define V043209f    3   "3. Somewhat important" , add
label define V043209f    4   "4. Not too important" , add
label define V043209f    5   "5. Not at all important" , add
label define V043209f    8   "8. Don't know" , add
label define V043209f    9   "9. Refused" , add
label define V043210f    1   "1. Should be allowed" , add
label define V043210f    3   "3. Should not be allowed" , add
label define V043210f    5   "5. Should not be allowed to marry but should be allowed" , add
label define V043210f    7   "7. Other [VOL] (SPECIFY)" , add
label define V043210f    8   "8. Don't know" , add
label define V043210f    9   "9. Refused" , add
label define V043211f    1   "1. Increased" , add
label define V043211f    3   "3. Decreased" , add
label define V043211f    5   "5. Stayed about the same" , add
label define V043211f    8   "8. Don't know" , add
label define V043211f    9   "9. Refused" , add
label define V043212f    1   "1. Increased lot" , add
label define V043212f    2   "2. Increased a little" , add
label define V043212f    3   "3. Same (5 in S2)" , add
label define V043212f    4   "4. Decreased a little" , add
label define V043212f    5   "5. Decreased a lot" , add
label define V043212f    8   "8. Don't know" , add
label define V043212f    9   "9. Refused" , add
label define V043213f    1   "1. Better" , add
label define V043213f    3   "3. Worse" , add
label define V043213f    5   "5. The same" , add
label define V043213f    8   "8. Don't know" , add
label define V043213f    9   "9. Refused" , add
label define V043214f    1   "1. Much better" , add
label define V043214f    2   "2. Somewhat better" , add
label define V043214f    3   "3. Same (5 in S3)" , add
label define V043214f    4   "4. Somewhat worse" , add
label define V043214f    5   "5. Much worse" , add
label define V043214f    8   "8. Don't know" , add
label define V043214f    9   "9. Refused" , add
label define V043215f    1   "1. More secure" , add
label define V043215f    3   "3. Less secure" , add
label define V043215f    5   "5. No change" , add
label define V043215f    8   "8. Don't know" , add
label define V043215f    9   "9. Refused" , add
label define V043216f    1   "1. Much more secure" , add
label define V043216f    2   "2. Somewhat more secure" , add
label define V043216f    3   "3. Same (5 in S4)" , add
label define V043216f    4   "4. Somewhat less secure" , add
label define V043216f    5   "5. Much less secure" , add
label define V043216f    8   "8. Don't know" , add
label define V043216f    9   "9. Refused" , add
label define V043217f    1   "1. Better" , add
label define V043217f    3   "3. Worse" , add
label define V043217f    5   "5. Stayed about the same" , add
label define V043217f    8   "8. Don't know" , add
label define V043217f    9   "9. Refused" , add
label define V043218f    1   "1. Much better" , add
label define V043218f    2   "2. Somewhat better" , add
label define V043218f    3   "3. Same (5 in S5)" , add
label define V043218f    4   "4. Somewhat worse" , add
label define V043218f    5   "5. Much worse" , add
label define V043218f    8   "8. Don't know" , add
label define V043218f    9   "9. Refused" , add
label define V043219f    1   "1. Important" , add
label define V043219f    5   "5. Not important" , add
label define V043219f    8   "8. Don't know" , add
label define V043219f    9   "9. Refused" , add
label define V043220f    0   "0. R says religion not important (5 in W1)" , add
label define V043220f    1   "1. Some" , add
label define V043220f    3   "3. Quite a bit" , add
label define V043220f    5   "5. A great deal" , add
label define V043220f    8   "8. Don't know" , add
label define V043220f    9   "9. Refused" , add
label define V043221f    1   "1. Several times a day" , add
label define V043221f    2   "2. Once a day" , add
label define V043221f    3   "3. A few times a week" , add
label define V043221f    4   "4. Once a week or less" , add
label define V043221f    5   "5. Never" , add
label define V043221f    7   "7. Other (SPECIFY)" , add
label define V043221f    8   "8. Don't know" , add
label define V043221f    9   "9. Refused" , add
label define V043222f    1   "1. The Bible is the actual word of God and is to" , add
label define V043222f    2   "2. The Bible is the word of God but not everything in it" , add
label define V043222f    3   "3. The Bible is a book written by men and is not the" , add
label define V043222f    7   "7. Other (SPECIFY)" , add
label define V043222f    8   "8. Don't know" , add
label define V043222f    9   "9. Refused" , add
label define V043223f   1   "1. Yes" , add
label define V043223f   5   "5. No" , add
label define V043223f   8   "8. Don't know" , add
label define V043223f   9   "9. Refused" , add
label define V043224f   1   "1. Every week" , add
label define V043224f   2   "2. Almost every week" , add
label define V043224f   3   "3. Once or twice a month" , add
label define V043224f   4   "4. A few times a year" , add
label define V043224f   5   "5. Never" , add
label define V043224f   8   "8. Don't know" , add
label define V043224f   9   "9. Refused" , add
label define V043225f   1   "1. Once a week" , add
label define V043225f   2   "2. More often than once a week" , add
label define V043225f   8   "8. Don't know" , add
label define V043225f   9   "9. Refused" , add
label define V043226f   1   "1. Yes" , add
label define V043226f   5   "5. No" , add
label define V043226f   8   "8. Don't know" , add
label define V043226f   9   "9. Refused" , add
label define V043227f   1   "1. Yes" , add
label define V043227f   5   "5. No" , add
label define V043227f   8   "8. Don't know" , add
label define V043227f   9   "9. Refused" , add
label define V043228f   1   "1. Yes" , add
label define V043228f   5   "5. No" , add
label define V043228f   8   "8. Don't know" , add
label define V043228f   9   "9. Refused" , add
label define V043229f   1   "1. Yes" , add
label define V043229f   5   "5. No" , add
label define V043229f   8   "8. Don't know" , add
label define V043229f   9   "9. Refused" , add
label define V043229f   0   "0. NA" , add
label define V043230a   1   "1. Protestant" , add
label define V043230a   2   "2. Catholic" , add
label define V043230a   3   "3. Jewish" , add
label define V043230a   7   "7. Other" , add
label define V043230a   8   "8. Don't know" , add
label define V043230a   9   "9. Refused" , add
label define V043230b   1   "1. Protestant" , add
label define V043230b   2   "2. Catholic" , add
label define V043230b   3   "3. Jewish" , add
label define V043230b   7   "7. Other" , add
label define V043230b   8   "8. Don't know" , add
label define V043230b   9   "9. Refused" , add
label define V043231f   1   "1. Baptist" , add
label define V043231f   2   "2. Episcopalian/Anglican/Church of England" , add
label define V043231f   3   "3. Lutheran" , add
label define V043231f   4   "4. Methodist" , add
label define V043231f   5   "5. Just Protestant" , add
label define V043231f   6   "6. Presbyterian" , add
label define V043231f   7   "7. Reformed" , add
label define V043231f   8   "8. Brethren" , add
label define V043231f   9   "9. Evangelical United Brethren" , add
label define V043231f   10   "10. Christian or just Christian" , add
label define V043231f   11   "11. Christian Scientist" , add
label define V043231f   12   "12. Church (or Churches) of Christ" , add
label define V043231f   13   "13. United Church of Christ " , add
label define V043231f   14   "14. Disciples of Christ" , add
label define V043231f   15   "15. Church of God " , add
label define V043231f   16   "16. Assembly of God " , add
label define V043231f   17   "17. Congregationalist " , add
label define V043231f   18   "18. Holiness " , add
label define V043231f   19   "19. Pentacostal" , add
label define V043231f   20   "20. Friends, Quaker" , add
label define V043231f   21   "21. Orthodox (SPECIFY)" , add
label define V043231f   22   "22. Non-denominational - Protestant" , add
label define V043231f   23   "23. Mormons " , add
label define V043231f   24   "24. Jehovah's Witnesses " , add
label define V043231f   25   "25. Latter Day Saints " , add
label define V043231f   26   "26. Unitarian/Universalist" , add
label define V043231f   27   "27. Buddhist" , add
label define V043231f   28   "28. Hindu " , add
label define V043231f   29   "29. Muslim/Islam" , add
label define V043231f   30   "30. Native American " , add
label define V043231f   80   "80. Other (SPECIFY)" , add
label define V043231f   88   "88. Don't know" , add
label define V043231f   89   "89. Refused" , add
label define V043232f   1   "1. Southern Baptist Convention" , add
label define V043232f   2   "2. American Baptist Churches in USA" , add
label define V043232f   3   "3. American Baptist Association" , add
label define V043232f   4   "4. Independent Baptist" , add
label define V043232f   7   "7. Other (SPECIFY)" , add
label define V043232f   8   "8. Don't know" , add
label define V043232f   9   "9. Refused" , add
label define V043233f   1   "1. Larger Baptist group (SPECIFY)" , add
label define V043233f   2   "2. Local" , add
label define V043233f   8   "8. Don't know" , add
label define V043233f   9   "9. Refused" , add
label define V043234f   1   "1. Evangelical Lutheran Church" , add
label define V043234f   2   "2. Missouri Synod" , add
label define V043234f   7   "7. Other (SPECIFY)" , add
label define V043234f   8   "8. Don't know" , add
label define V043234f   9   "9. Refused" , add
label define V043235f   1   "1. United Methodist Church" , add
label define V043235f   2   "2. African Methodist Episcopal" , add
label define V043235f   7   "7. Other (SPECIFY)" , add
label define V043235f   8   "8. Don't know" , add
label define V043235f   9   "9. Refused" , add
label define V043236f   1   "1. Presbyterian Church USA (formerly" , add
label define V043236f   7   "7. Other (SPECIFY)" , add
label define V043236f   8   "8. Don't know" , add
label define V043236f   9   "9. Refused" , add
label define V043237f   1   "1. Christian Reformed Church" , add
label define V043237f   2   "2. The Reformed Church in America" , add
label define V043237f   7   "7. Other (SPECIFY)" , add
label define V043237f   8   "8. Don't know" , add
label define V043237f   9   "9. Refused" , add
label define V043238f   1   "1. Church of the Brethren" , add
label define V043238f   2   "2. The Plymouth Brethren" , add
label define V043238f   7   "7. Other (SPECIFY)" , add
label define V043238f   8   "8. Don't know" , add
label define V043238f   9   "9. Refused" , add
label define V043239f   1   "1. Disciples of Christ" , add
label define V043239f   2   "2. I am just a Christian" , add
label define V043239f   7   "7. Other (SPECIFY)" , add
label define V043239f   8   "8. Don't know" , add
label define V043239f   9   "9. Refused" , add
label define V043240f   1   "1. Church of Christ" , add
label define V043240f   2   "2. United Church of Christ" , add
label define V043240f   8   "8. Don't know" , add
label define V043240f   9   "9. Refused" , add
label define V043241f   1   "1. Anderson, Indiana" , add
label define V043241f   2   "2. Cleveland, Tennessee" , add
label define V043241f   3   "3. Church of God in Christ" , add
label define V043241f   7   "7. Other (SPECIFY)" , add
label define V043241f   8   "8. Don't know" , add
label define V043241f   9   "9. Refused" , add
label define V043244f   1   "1. Yes" , add
label define V043244f   5   "5. No" , add
label define V043244f   8   "8. Don't know" , add
label define V043244f   9   "9. Refused" , add
label define V043244f   0   "0. NA" , add
label define V043245a   1   "1. Orthodox" , add
label define V043245a   2   "2. Conservative" , add
label define V043245a   3   "3. Reform" , add
label define V043245a   7   "7. Other (SPECIFY)" , add
label define V043245a   8   "8. Don't know" , add
label define V043245a   9   "9. Refused" , add
label define V043245b   1   "1. Orthodox" , add
label define V043245b   2   "2. Conservative" , add
label define V043245b   3   "3. Reform" , add
label define V043245b   7   "7. Other (SPECIFY)" , add
label define V043245b   8   "8. Don't know" , add
label define V043245b   9   "9. Refused" , add
label define V043247f   1   "1. Protestant" , add
label define V043247f   2   "2. Catholic" , add
label define V043247f   3   "3. Eastern Orthodox (Christian)" , add
label define V043247f   4   "4. Jewish" , add
label define V043247f   6   "6. Other" , add
label define V043247f   7   "7. None" , add
label define V043247f   8   "8. DK" , add
label define V043247f   9   "9. RF" , add
label define V043247f   0   "0. NA" , add
label define V043247a   01  "01. General Protestant/Christian" , add
label define V043247a   02  "02. Adventist" , add
label define V043247a   03  "03. Anglican" , add
label define V043247a   04  "04. Baptist" , add
label define V043247a   05  "05. Congregational" , add
label define V043247a   06  "06. European Free Church (Anabaptist)" , add
label define V043247a   07  "07. Holiness" , add
label define V043247a   08  "08. Independent Fundamentalist" , add
label define V043247a   09  "09. Lutheran" , add
label define V043247a   10  "10. Methodist" , add
label define V043247a   11  "11. Pentecostal" , add
label define V043247a   12  "12. Presbyterian" , add
label define V043247a   13  "13. Reformed" , add
label define V043247a   14  "14. Restorationist" , add
label define V043247a   15  "15. Non-traditional Protestant" , add
label define V043247a   16  "16. Roman Catholic" , add
label define V043247a   17  "17. Jewish" , add
label define V043247a   18  "18. Eastern Orthodox" , add
label define V043247a   19  "19. Non Judeo-Christian religion" , add
label define V043247a   20  "20. More than 1 major religion" , add
label define V043247a   77  "77. None" , add
label define V043247a   88  "88. DK" , add
label define V043247a   89  "89. RF" , add
label define V043247a   00  "00. NA" , add
label define V043248f    010   "010. Protestant, no denomination given" , add
label define V043248f    020   "020. Non-denominational Protestant" , add
label define V043248f    030   "030. Community church" , add
label define V043248f    040   "040. Inter-denominational Protestant" , add
label define V043248f    099   "099. Christian (NFS); 'just Christian'" , add
label define V043248f    100   "100. 7th Day Adventist" , add
label define V043248f    109   "109. Adventist (NFS)" , add
label define V043248f    110   "110. Episcopalian; Anglican" , add
label define V043248f    111   "111. Independent Anglican, Episcopalian" , add
label define V043248f    120   "120. American Baptist Association" , add
label define V043248f    121   "121. American Baptist Churches U.S.A." , add
label define V043248f    122   "122. Baptist Bible Fellowship" , add
label define V043248f    123   "123. Baptist General Conference" , add
label define V043248f    124   "124. Baptist Missionary Association of America" , add
label define V043248f    125   "125. Conservative Baptist Association of America" , add
label define V043248f    126   "126. General Association of Regular Baptist Churches" , add
label define V043248f    127   "127. National Association of Free Will Baptists" , add
label define V043248f    128   "128. Primitive Baptists" , add
label define V043248f    129   "129. National Baptist Convention in the U.S.A." , add
label define V043248f    130   "130. National Baptist Convention of America" , add
label define V043248f    131   "131. National Primitive Baptist Convention of the U.S.A." , add
label define V043248f    132   "132. Progressive National Baptist Convention" , add
label define V043248f    134   "134. Reformed Baptist (Calvinist)" , add
label define V043248f    135   "135. Southern Baptist Convention" , add
label define V043248f    147   "147. Fundamental Baptist (no denom. ties)" , add
label define V043248f    148   "148. Local (independent) Baptist churches with" , add
label define V043248f    149   "149. Baptist (NFS)" , add
label define V043248f    150   "150. United Church of Christ (includes Congregational" , add
label define V043248f    155   "155. Congregational Christian" , add
label define V043248f    160   "160. Church of the Brethren" , add
label define V043248f    161   "161. Brethren (NFS)" , add
label define V043248f    162   "162. Mennonite Church" , add
label define V043248f    163   "163. Moravian Church" , add
label define V043248f    164   "164. Old Order Amish" , add
label define V043248f    165   "165. Quakers (Friends)" , add
label define V043248f    166   "166. Evangelical Covenant Church (not Anabaptist in" , add
label define V043248f    167   "167. Evangelical Free Church (not Anabaptist in" , add
label define V043248f    168   "168. Brethren in Christ" , add
label define V043248f    170   "170. Mennonite Brethren" , add
label define V043248f    180   "180. Christian and Missionary Alliance (CMA)" , add
label define V043248f    181   "181. Church of God (Anderson, IN)" , add
label define V043248f    182   "182. Church of the Nazarene" , add
label define V043248f    183   "183. Free Methodist Church" , add
label define V043248f    184   "184. Salvation Army" , add
label define V043248f    185   "185. Wesleyan Church" , add
label define V043248f    186   "186. Church of God of Findlay, OH" , add
label define V043248f    199   "199. Holiness (NFS); Church of God (NFS); R not or NA" , add
label define V043248f    200   "200. Plymouth Brethren" , add
label define V043248f    201   "201. Independent Fundamentalist Churches of America" , add
label define V043248f    219   "219. Independent-Fundamentalist (NFS)" , add
label define V043248f    220   "220. Evangelical Lutheran Church in America (formerly" , add
label define V043248f    221   "221. Lutheran Church--Missouri Synod; LC-MS" , add
label define V043248f    222   "222. Wisconsin Evangelical Lutheran Synod; WELS" , add
label define V043248f    223   "223. Other Conservative Lutheran" , add
label define V043248f    229   "229. Lutheran (NFS)" , add
label define V043248f    230   "230. United Methodist Church; Evangelical United" , add
label define V043248f    231   "231. African Methodist Episcopal Church" , add
label define V043248f    232   "232. African Methodist Episcopal Zion Church" , add
label define V043248f    233   "233. Christian Methodist Episcopal Church" , add
label define V043248f    234   "234. Primitive Methodist" , add
label define V043248f    240   "240. Congregational Methodist (fundamentalist)" , add
label define V043248f    249   "249. Methodist (NFS)" , add
label define V043248f    250   "250. Assemblies of God" , add
label define V043248f    251   "251. Church of God (Cleveland, TN)" , add
label define V043248f    252   "252. Church of God (Huntsville, AL)" , add
label define V043248f    253   "253. International Church of the Four Square Gospel" , add
label define V043248f    254   "254. Pentecostal Church of God" , add
label define V043248f    255   "255. Pentecostal Holiness Church" , add
label define V043248f    256   "256. United Pentecostal Church International" , add
label define V043248f    257   "257. Church of God in Christ (incl. NA whether 258)" , add
label define V043248f    258   "258. Church of God in Christ (International)" , add
label define V043248f    260   "260. Church of God of the Apostolic Faith" , add
label define V043248f    261   "261. Church of God of Prophecy" , add
label define V043248f    262   "262. Vineyard Fellowship" , add
label define V043248f    263   "263. Open Bible Standard Churches" , add
label define V043248f    264   "264. Full Gospel" , add
label define V043248f    267   "267. Apostolic Pentecostal" , add
label define V043248f    268   "268. Spanish Pentecostal" , add
label define V043248f    269   "269. Pentecostal (NFS); Church of God (NFS); R not or" , add
label define V043248f    270   "270. Presbyterian Church in the U.S.A." , add
label define V043248f    271   "271. Cumberland Presbyterian Church" , add
label define V043248f    272   "272. Presbyterian Church in American (PCA)" , add
label define V043248f    275   "275. Evangelical Presbyterian" , add
label define V043248f    276   "276. Reformed Presbyterian" , add
label define V043248f    279   "279. Presbyterian (NFS)" , add
label define V043248f    280   "280. Christian Reformed Church (inaccurately known as" , add
label define V043248f    281   "281. Reformed Church in America" , add
label define V043248f    282   "282. Free Hungarian Reformed Church" , add
label define V043248f    289   "289. Reformed (NFS)" , add
label define V043248f    290   "290. Christian Church (Disciples of Christ)" , add
label define V043248f    291   "291. Christian Churches and Churches of Christ" , add
label define V043248f    292   "292. Churches of Christ; Church of Christ (NFS)" , add
label define V043248f    293   "293. Christian Congregation" , add
label define V043248f    300   "300. Christian Scientists" , add
label define V043248f    301   "301. Mormons; Latter Day Saints" , add
label define V043248f    302   "302. Spiritualists" , add
label define V043248f    303   "303. Unitarian; Universalist" , add
label define V043248f    304   "304. Jehovah's Witnesses" , add
label define V043248f    305   "305. Unity; Unity Church; Christ Church Unity" , add
label define V043248f    306   "306. Fundamentalist Adventist (Worldwide Church of God)" , add
label define V043248f    309   "309. Non-traditional Protestant (NFS)" , add
label define V043248f    400   "400. Roman Catholic" , add
label define V043248f    500   "500. Jewish, no preference" , add
label define V043248f    501   "501. Orthodox" , add
label define V043248f    502   "502. Conservative" , add
label define V043248f    503   "503. Reformed" , add
label define V043248f    524   "524. Jewish, other" , add
label define V043248f    600   "600. Roman Catholic AND Protestant" , add
label define V043248f    700   "700. Greek Rite Catholic" , add
label define V043248f    701   "701. Greek Orthodox" , add
label define V043248f    702   "702. Russian Orthodox" , add
label define V043248f    703   "703. Rumanian Orthodox" , add
label define V043248f    704   "704. Serbian Orthodox" , add
label define V043248f    705   "705. Syrian Orthodox" , add
label define V043248f    706   "706. Armenian Orthodox" , add
label define V043248f    707   "707. Georgian Orthodox" , add
label define V043248f    708   "708. Ukranian Orthodox" , add
label define V043248f    719   "719. Eastern Orthodox (NFS)" , add
label define V043248f    720   "720. Muslim; Mohammedan; Islam" , add
label define V043248f    721   "721. Buddhist" , add
label define V043248f    722   "722. Hindu" , add
label define V043248f    723   "723. Bahai" , add
label define V043248f    724   "724. American Indian Religions (Native American" , add
label define V043248f    725   "725. New Age" , add
label define V043248f    726   "726. Wica (Wiccan)" , add
label define V043248f    727   "727. Pagan" , add
label define V043248f    729   "729. Other non-Christian/non-Jewish" , add
label define V043248f    750   "750. Scientology" , add
label define V043248f    790   "790. Religious/ethical cults" , add
label define V043248f    795   "795. More than 1 major religion (e.g., Christian," , add
label define V043248f    870   "870. Other" , add
label define V043248f    879   "879. R indicates attendance/affiliation but specifies none" , add
label define V043248f    880   "880. None" , add
label define V043248f    881   "881. Agnostics" , add
label define V043248f    882   "882. Atheists" , add
label define V043248f    888   "888. DK" , add
label define V043248f    889   "889. RF" , add
label define V043248f    000   "000. NA" , add
label define V043249a    8888   "8888. DK" , add
label define V043249a    8889   "8889. RF" , add
label define V043249b    88   "88. DK" , add
label define V043249b    89   "89. RF" , add
label define V043250f    98   "88. DK" , add
label define V043250f    99   "89. RF" , add
label define V043250f    00   "00. NA" , add
label define V043251f    1   "1. Married" , add
label define V043251f    2   "2. Widowed" , add
label define V043251f    3   "3. Divorced" , add
label define V043251f    4   "4. Separated" , add
label define V043251f    5   "5. Never married" , add
label define V043251f    6   "6. Partnered, not married {VOL}" , add
label define V043251f    8   "8. Don't know" , add
label define V043251f    9   "9. Refused" , add
label define V043251x    1   "1. Indicated married/partnered in both Y2 and HH listing" , add
label define V043251x    2   "2. Indicated married/partnered in HH listing only" , add
label define V043251x    3   "3. Indicated married or partnered in Y2 only" , add
label define V043251x    4   "4. Not indicated as married/partnered in Y2 or HH listing" , add
label define V043252f    0   "0. 0 grades" , add
label define V043252f    17  "17 or more grades" , add
label define V043252f    88  "88. Don't know" , add
label define V043252f    89  "89. Refused" , add
label define V043253a    1   "1. Yes" , add
label define V043253a    5   "5. No" , add
label define V043253a    8   "8. Don't know" , add
label define V043253a    9   "9. Refused" , add
label define V043253b    1   "1. Bachelor's degree" , add
label define V043253b    2   "2. Master's degree" , add
label define V043253b    3   "3. PhD, LIT, SCD, DFA, DLIT, DPH, DPHIL, JSC, SJD" , add
label define V043253b    4   "4. LLB, JD" , add
label define V043253b    5   "5. MD, DDS, DVM, MVSA, DSC, DO" , add
label define V043253b    6   "6. JDC, STD, THD" , add
label define V043253b    7   "7. Associate degree (AA)" , add
label define V043253b    0   "0. No degree earned" , add
label define V043253b    8   "8. Don't know" , add
label define V043253b    9   "9. Refused" , add
label define V043254f    0   "0. NA/DK number of grades; no HS diploma" , add
label define V043254f    1   "1. 8 grades or less and no diploma or equivalency" , add
label define V043254f    2   "2. 9-11 grades, no further schooling" , add
label define V043254f    3   "3. High school diploma or equivalency test" , add
label define V043254f    4   "4. More than 12 years of schooling, no higher degree" , add
label define V043254f    5   "5. Junior or community college level degrees" , add
label define V043254f    6   "6. BA level degrees; 17+ years, no advanced degree" , add
label define V043254f    7   "7. Advanced degree, including LLB" , add
label define V043254f    8   "8. DK" , add
label define V043254f    9   "9. RF" , add
label define V043255f    0   "0. 0 grades" , add
label define V043255f    17  "17 or more grades" , add
label define V043255f    88  "88. Don't know" , add
label define V043255f    89  "89. Refused" , add
label define V043256a    1   "1. Yes" , add
label define V043256a    5   "5. No" , add
label define V043256a    8   "8. Don't know" , add
label define V043256a    9   "9. Refused" , add
label define V043256b    1   "1. Bachelor's degree" , add
label define V043256b    2   "2. Master's degree" , add
label define V043256b    3   "3. PhD, LIT, SCD, DFA, DLIT, DPH, DPHIL, JSC, SJD" , add
label define V043256b    4   "4. LLB, JD" , add
label define V043256b    5   "5. MD, DDS, DVM, MVSA, DSC, DO" , add
label define V043256b    6   "6. JDC, STD, THD" , add
label define V043256b    7   "7. Associate degree (AA)" , add
label define V043256b    0   "0. No degree earned" , add
label define V043256b    8   "8. Don't know" , add
label define V043256b    9   "9. Refused" , add
label define V043257f    0   "0. NA/DK number of grades; no HS diploma" , add
label define V043257f    1   "1. 8 grades or less and no diploma or equivalency" , add
label define V043257f    2   "2. 9-11 grades, no further schooling" , add
label define V043257f    3   "3. High school diploma or equivalency test" , add
label define V043257f    4   "4. More than 12 years of schooling, no higher degree" , add
label define V043257f    5   "5. Junior or community college level degrees" , add
label define V043257f    6   "6. BA level degrees; 17+ years, no advanced degree" , add
label define V043257f    7   "7. Advanced degree, including LLB" , add
label define V043257f    8   "8. DK" , add
label define V043257f    9   "9. RF" , add
label define V043258f    1   "1. Yes" , add
label define V043258f    5   "5. No" , add
label define V043258f    8   "8. Don't know" , add
label define V043258f    9   "9. Refused" , add
label define V043259f    1   "1. Yes" , add
label define V043259f    5   "5. No" , add
label define V043259f    8   "8. Don't know" , add
label define V043259f    9   "9. Refused" , add
label define V043260a    10  "10. WORKING NOW only" , add
label define V043260a    15  "15. WORKING NOW >=20 hrs/wk and retired" , add
label define V043260a    16  "16. WORKING NOW >=20 hrs/wk and permanently disabled" , add
label define V043260a    17  "17. WORKING NOW >=20 hrs/wk and homemaker" , add
label define V043260a    18  "18. WORKING NOW >=20 hrs/wk and student" , add
label define V043260a    20  "20. TEMPORARILY LAID OFF" , add
label define V043260a    40  "40. UNEMPLOYED" , add
label define V043260a    50  "50. RETIRED, no other occupation" , add
label define V043260a    51  "51. RETIRED and working now <20 hrs/wk" , add
label define V043260a    60  "60. PERMANENTLY DISABLED, not working" , add
label define V043260a    61  "61. PERMANENTLY DISABLED and working now <20 hrs/wk" , add
label define V043260a    70  "70. HOMEMAKER, no other occupation" , add
label define V043260a    71  "71. HOMEMAKER and working now <20 hrs/wk" , add
label define V043260a    75  "75. HOMEMAKER and student, no other occupation" , add
label define V043260a    80  "80. STUDENT, no other occupation" , add
label define V043260a    81  "81. STUDENT and working now <20 hrs/wk" , add
label define V043260a    89  "89. Refused" , add
label define V043260b    1  "1. R WORKING NOW" , add
label define V043260b    2  "2. R TEMPORARILY LAID OFF (TLO)" , add
label define V043260b    4  "4. R UNEMPLOYED" , add
label define V043260b    5  "5. R RETIRED" , add
label define V043260b    6  "6. R PERMANENTLY DISABLED" , add
label define V043260b    7  "7. R HOMEMAKER" , add
label define V043260b    8  "8. R STUDENT" , add
label define V043260b    9  "9. Refused" , add
label define V043260c    1   "1. Working now" , add
label define V043260c    2   "2. Temporarily laid off (TLO)" , add
label define V043260c    4   "4. Unemployed" , add
label define V043260c    5   "5. Retired" , add
label define V043260c    6   "6. Permanently disabled" , add
label define V043260c    7   "7. Homemaker" , add
label define V043260c    8   "8. Student" , add
label define V043260c    9   "9. Refused" , add
label define V043261f    1   "1. Current employment [Y6(1)=10,16,17,18,20,61,71,81]" , add
label define V043261f    2   "2. Past employment (if any) [Y6(1) = 15,40,50,51,60]" , add
label define V043262a   999   "999. DK; NA; Don't know; Not ascertained" , add
label define V043262b   99   "99. DK; NA; Don't know; Not ascertained" , add
label define V043262c    1   "1. Lowest prestige" , add
label define V043262c    6   "6. Highest prestige" , add
label define V043262c    8   "8. Member of military" , add
label define V043262c    9   "9. DK; NA; Don't know; Not ascertained" , add
label define V043262e    999   "999. DK; NA; Don't know; Not ascertained" , add
label define V043262f    1   "1. Someone else" , add
label define V043262f    3   "3. Both self and someone else" , add
label define V043262f    5   "5. Self-employed" , add
label define V043262f    8   "8. Don't know" , add
label define V043262f    9   "9. Refused" , add
label define V043262f    0   "0. NA" , add
label define V043262g    1   "1. Yes" , add
label define V043262g    5   "5. No" , add
label define V043262g    8   "8. Don't know" , add
label define V043262g    9   "9. Refused" , add
label define V043262g    0   "0. NA" , add
label define V043262h    888   "888. Don't know" , add
label define V043262h    889   "889. Refused" , add
label define V043262h    000   "000. NA" , add
label define V043262j    1   "1. A lot" , add
label define V043262j    3   "3. Somewhat" , add
label define V043262j    5   "5. Not much at all" , add
label define V043262j    8   "8. Don't know" , add
label define V043262j    9   "9. Refused" , add
label define V043262k    1   "1. Yes" , add
label define V043262k    5   "5. No" , add
label define V043262k    8   "8. Don't know" , add
label define V043262k    9   "9. Refused" , add
label define V043262k    0   "0. NA" , add
label define V043262m  999   "999. DK; NA; Don't know; Not ascertained" , add
label define V043262n   99   " 99. DK; NA; Don't know; Not ascertained" , add
label define V043262p   01   "01. Executive, Administrative and Managerial (001-039)" , add
label define V043262p   02   "02. Professional Specialty Occupations (040-199)" , add
label define V043262p   03   "03. Technicians and Related Support Occupations (200-235)" , add
label define V043262p   04   "04. Sales Occupation ( 236-285)" , add
label define V043262p   05   "05. Administrative Support, including clerical (286-389)" , add
label define V043262p   06   "06. Private Household (403-407)" , add
label define V043262p   07   "07. Protective Service (408-427)" , add
label define V043262p   08   "08. Service except Protective and Household (428-469)" , add
label define V043262p   09   "09. Farming, Forestry and Fishing Occupations (470-499)" , add
label define V043262p   10   "10. Precision Production, Craft and Repair Occupations(500-699)" , add
label define V043262p   11   "11. Machine Operators, Assemblers and Inspectors (700-799)" , add
label define V043262p   12   "12. Transportation and Material Moving Occupations (800-859)" , add
label define V043262p   13   "13. Handlers, Equipment Cleaners, Helpers and Laborers(860-890)" , add
label define V043262p   14   "14. Member of Armed Forces" , add
label define V043262p   99   "99. DK; NA; Don't know; Not ascertained" , add
label define V043263f    1   "1. Y16a-Y17b Current employment only [10,20,17,18,71,81 in" , add
label define V043263f    2   "2. Y7a-Y15 Past employment only [40,50,60,70,75,80 in Y6(1)]" , add
label define V043263f    3   "3. Both current and past [15,16,51,61 in Y6(1)]" , add
label define V043264f    1   "1. Yes" , add
label define V043264f    5   "5. No" , add
label define V043264f    8   "8. Don't know" , add
label define V043264f    9   "9. Refused" , add
label define V043265f    1   "1. Yes" , add
label define V043265f    5   "5. No" , add
label define V043265f    8   "8. Don't know" , add
label define V043266a    8888   "8888. Don't know" , add
label define V043266a    8889   "8889. Refused" , add
label define V043266b    01   "01. January" , add
label define V043266b    02   "02. February" , add
label define V043266b    03   "03. March" , add
label define V043266b    04   "04. April" , add
label define V043266b    05   "05. May" , add
label define V043266b    06   "06. June" , add
label define V043266b    07   "07. July" , add
label define V043266b    08   "08. August" , add
label define V043266b    09   "09. September" , add
label define V043266b    10   "10. October" , add
label define V043266b    11   "11. November" , add
label define V043266b    12   "12. December" , add
label define V043266b    88   "88. Don't know" , add
label define V043266b    89   "89. Refused" , add
label define V043267f    1   "1. Yes" , add
label define V043267f    5   "5. No" , add
label define V043267f    8   "8. Don't know" , add
label define V043267f    9   "9. Refused" , add
label define V043268f    999   "999. DK; NA; Don't know; Not ascertained" , add
label define V043268a    99   "99. DK; NA; Don't know; Not ascertained" , add
label define V043268b    1   "1. Lowest prestige" , add
label define V043268b    6   "6. Highest prestige" , add
label define V043268b    8   "8. Member of military" , add
label define V043268b    9   "9. DK; NA; Don't know; Not ascertained" , add
label define V043268d  999   "999. DK; NA; Don't know; Not ascertained" , add
label define V043268e   99   " 99. DK; NA; Don't know; Not ascertained" , add
label define V043268f   01   "01. Executive, Administrative and Managerial (001-039)" , add
label define V043268f   02   "02. Professional Specialty Occupations (040-199)" , add
label define V043268f   03   "03. Technicians and Related Support Occupations (200-235)" , add
label define V043268f   04   "04. Sales Occupation ( 236-285)" , add
label define V043268f   05   "05. Administrative Support, including clerical (286-389)" , add
label define V043268f   06   "06. Private Household (403-407)" , add
label define V043268f   07   "07. Protective Service (408-427)" , add
label define V043268f   08   "08. Service except Protective and Household (428-469)" , add
label define V043268f   09   "09. Farming, Forestry and Fishing Occupations (470-499)" , add
label define V043268f   10   "10. Precision Production, Craft and Repair Occupations(500-699)" , add
label define V043268f   11   "11. Machine Operators, Assemblers and Inspectors (700-799)" , add
label define V043268f   12   "12. Transportation and Material Moving Occupations (800-859)" , add
label define V043268f   13   "13. Handlers, Equipment Cleaners, Helpers and Laborers(860-890)" , add
label define V043268f   14   "14. Member of Armed Forces" , add
label define V043268f   99   " 99. DK; NA; Don't know; Not ascertained" , add
label define V043269f    999   "999. DK; NA; Don't know; Not ascertained" , add
label define V043270f    1   "1. Someone else" , add
label define V043270f    3   "3. Both self and someone else" , add
label define V043270f    5   "5. Self-employed" , add
label define V043270f    8   "8. Don't know" , add
label define V043270f    9   "9. Refused" , add
label define V043270f    0   "0. NA" , add
label define V043271f    1   "1. Yes" , add
label define V043271f    5   "5. No" , add
label define V043271f    8   "8. Don't know" , add
label define V043271f    9   "9. Refused" , add
label define V043271f    0   "0. NA" , add
label define V043272f    1   "1. Yes" , add
label define V043272f    5   "5. No" , add
label define V043272f    8   "8. Don't know" , add
label define V043272f    9   "9. Refused" , add
label define V043272f    0   "0. NA" , add
label define V043273f    888   "888. Don't know" , add
label define V043273f    889   "889. Refused" , add
label define V043273f    000   "000. NA" , add
label define V043274f    1   "1. Yes" , add
label define V043274f    5   "5. No" , add
label define V043274f    8   "8. Don't know" , add
label define V043274f    9   "9. Refused" , add
label define V043274f    0   "0. NA" , add
label define V043275f    1   "1. Yes" , add
label define V043275f    5   "5. No" , add
label define V043275f    8   "8. Don't know" , add
label define V043275f    9   "9. Refused" , add
label define V043275f    0   "0. NA" , add
label define V043276f    1   "1. A lot" , add
label define V043276f    3   "3. Somewhat" , add
label define V043276f    5   "5. Not much at all" , add
label define V043276f    8   "8. Don't know" , add
label define V043276f    9   "9. Refused" , add
label define V043277f    1   "1. Yes" , add
label define V043277f    5   "5. No" , add
label define V043278f    999   "999. DK; NA; Don't know; Not ascertained" , add
label define V043278a    99   "99. DK; NA; Don't know; Not ascertained" , add
label define V043278b    1   "1. Lowest prestige" , add
label define V043278b    6   "6. Highest prestige" , add
label define V043278b    8   "8. Member of military" , add
label define V043278b    9   "9. DK; NA; Don't know; Not ascertained" , add
label define V043278d  999   "999. DK; NA; Don't know; Not ascertained" , add
label define V043278e   99   " 99. DK; NA; Don't know; Not ascertained" , add
label define V043278f   01   "01. Executive, Administrative and Managerial (001-039)" , add
label define V043278f   02   "02. Professional Specialty Occupations (040-199)" , add
label define V043278f   03   "03. Technicians and Related Support Occupations (200-235)" , add
label define V043278f   04   "04. Sales Occupation ( 236-285)" , add
label define V043278f   05   "05. Administrative Support, including clerical (286-389)" , add
label define V043278f   06   "06. Private Household (403-407)" , add
label define V043278f   07   "07. Protective Service (408-427)" , add
label define V043278f   08   "08. Service except Protective and Household (428-469)" , add
label define V043278f   09   "09. Farming, Forestry and Fishing Occupations (470-499)" , add
label define V043278f   10   "10. Precision Production, Craft and Repair Occupations(500-699)" , add
label define V043278f   11   "11. Machine Operators, Assemblers and Inspectors (700-799)" , add
label define V043278f   12   "12. Transportation and Material Moving Occupations (800-859)" , add
label define V043278f   13   "13. Handlers, Equipment Cleaners, Helpers and Laborers(860-890)" , add
label define V043278f   14   "14. Member of Armed Forces" , add
label define V043278f   99   " 99. DK; NA; Don't know; Not ascertained" , add
label define V043279f    999   "999. DK; NA; Don't know; Not ascertained" , add
label define V043280f    1   "1. Someone else" , add
label define V043280f    3   "3. Both self and someone else" , add
label define V043280f    5   "5. Self-employed" , add
label define V043280f    8   "8. Don't know" , add
label define V043280f    9   "9. Refused" , add
label define V043281f    1   "1. Yes" , add
label define V043281f    5   "5. No" , add
label define V043281f    8   "8. Don't know" , add
label define V043281f    9   "9. Refused" , add
label define V043282f    888   "888. Don't know" , add
label define V043282f    889   "889. Refused" , add
label define V043283f    1   "1. More" , add
label define V043283f    3   "3. Fewer" , add
label define V043283f    5   "5. About right" , add
label define V043283f    8   "8. Don't know" , add
label define V043283f    9   "9. Refused" , add
label define V043284f    1   "1. A lot" , add
label define V043284f    3   "3. Somewhat" , add
label define V043284f    5   "5. Not much at all" , add
label define V043284f    8   "8. Don't know" , add
label define V043284f    9   "9. Refused" , add
label define V043285f    1   "1. Yes" , add
label define V043285f    5   "5. No" , add
label define V043285f    8   "8. Don't know" , add
label define V043285f    9   "9. Refused" , add
label define V043285f    0   "0. NA" , add
label define V043286f    1   "1. Yes" , add
label define V043286f    5   "5. No" , add
label define V043286f    8   "8. Don't know" , add
label define V043286f    9   "9. Refused" , add
label define V043286f    0   "0. NA" , add
label define V043287f    1   "1. Yes" , add
label define V043287f    5   "5. No" , add
label define V043287f    8   "8. Don't know" , add
label define V043287f    9   "9. Refused" , add
label define V043288f    1   "1. Yes" , add
label define V043288f    5   "5. No" , add
label define V043288f    8   "8. Don't know" , add
label define V043288f    9   "9. Refused" , add
label define V043289f    10   "10. Working now only" , add
label define V043289f    15   "15. Working now and retired" , add
label define V043289f    16   "16. Working now and disabled" , add
label define V043289f    17   "17. Working now and homemaker" , add
label define V043289f    18   "18. Working now and student" , add
label define V043289f    20   "20. Temporarily laid off only" , add
label define V043289f    25   "25. Temporarily laid off and retired" , add
label define V043289f    26   "26. Temporarily laid off and disabled" , add
label define V043289f    27   "27. Temporarily laid off and homemaker" , add
label define V043289f    28   "28. Temporarily laid off and student" , add
label define V043289f    40   "40. Unemployed only" , add
label define V043289f    50   "50. Retired only" , add
label define V043289f    54   "54. Retired and unemployed" , add
label define V043289f    56   "56. Retired and disabled" , add
label define V043289f    57   "57. Retired and homemaker" , add
label define V043289f    58   "58. Retired and student" , add
label define V043289f    60   "60. Disabled only" , add
label define V043289f    64   "64. Disabled and unemployed" , add
label define V043289f    67   "67. Disabled and homemaker" , add
label define V043289f    68   "68. Disabled and student" , add
label define V043289f    70   "70. Homemaker only" , add
label define V043289f    74   "74. Homemaker and unemployed" , add
label define V043289f    78   "78. Homemaker and student" , add
label define V043289f    80   "80. Student only" , add
label define V043289f    84   "84. Student and unemployed" , add
label define V043289f    88   "88. Don't know" , add
label define V043289f    89   "89. Refused" , add
label define V043289a    1   "1. Working now (10,15-18 in Y18a1)" , add
label define V043289a    2   "2. Temporarily laid off (20,25-28 in Y18a1)" , add
label define V043289a    4   "4. Unemployed (40 in Y18a1)" , add
label define V043289a    5   "5. Retired (50,54,56-58 in Y18a1)" , add
label define V043289a    6   "6. Permanently disabled (60,64,67,68 in Y18a1)" , add
label define V043289a    7   "7. Homemaker (70,74,78 in Y18a1)" , add
label define V043289a    8   "8. Student (80,84 in Y18a1)" , add
label define V043289a    9   "9. Don't know (88 in Y18a1)" , add
label define V043289a    0   "0. Refused (89 in Y18a1)" , add
label define V043290f    1   "1. Yes" , add
label define V043290f    5   "5. No" , add
label define V043290f    8   "8. Don't know" , add
label define V043290f    9   "9. Refused" , add
label define V043291f    10   "10. Respondent only" , add
label define V043291f    12   "12. Respondent and wife/female partner" , add
label define V043291f    13   "13. Respondent and husband/male partner" , add
label define V043291f    14   "14. Respondent and someone else" , add
label define V043291f    20   "20. Wife/female partner only" , add
label define V043291f    24   "24. Wife/female partner and someone else" , add
label define V043291f    30   "30. Husband/male partner only" , add
label define V043291f    34   "34. Husband/male partner and someone else" , add
label define V043291f    40   "40. Someone else only" , add
label define V043291f    88   "88. Don't know" , add
label define V043291f    89   "89. Refused" , add
label define V043292f    1   "1. Someone IN ADDITION TO RESPONDENT is age 14 or older" , add
label define V043292f    5   "5. NO ONE OTHER THAN RESPONDENT is age 14 or older in" , add
label define V043292f    8   "8. Coding error by Interviewer; R indicated as married/" , add
label define V043292f    9   "9. Coding error by Interviewer; person in household" , add
label define V043293f    01   "01. A. None or less than $2,999" , add
label define V043293f    02   "02. B. $3,000 -$4,999" , add
label define V043293f    03   "03. C. $5,000 -$6,999" , add
label define V043293f    04   "04. D. $7,000 -$8,999" , add
label define V043293f    05   "05. E. $9,000 -$10,999" , add
label define V043293f    06   "06. F. $11,000-$12,999" , add
label define V043293f    07   "07. G. $13,000-$14,999" , add
label define V043293f    08   "08. H. $15,000-$16,999" , add
label define V043293f    09   "09. J. $17,000-$19,999" , add
label define V043293f    10   "10. K. $20,000-$21,999" , add
label define V043293f    11   "11. M. $22,000-$24,999" , add
label define V043293f    12   "12. N. $25,000-$29,999" , add
label define V043293f    13   "13. P. $30,000-$34,999" , add
label define V043293f    14   "14. Q. $35,000-$39,999" , add
label define V043293f    15   "15. R. $40,000-$44,999" , add
label define V043293f    16   "16. S. $45,000-$49,999" , add
label define V043293f    17   "17. T. $50,000-$59,999" , add
label define V043293f    18   "18. U. $60,000-$69,999" , add
label define V043293f    19   "19. V. $70,000-$79,999" , add
label define V043293f    20   "20. W. $80,000-$89,999" , add
label define V043293f    21   "21. X. $90,000-$104,999" , add
label define V043293f    22   "22. Y. $105,000-$119,000" , add
label define V043293f    23   "23. Z. $120,000 and over" , add
label define V043293f    88   "88. Don't know" , add
label define V043293f    89   "89. Refused" , add
label define V043293f    00   "00. NA (8,9 in Y20)" , add
label define V043293x    01   "01. A. None or less than $2,999" , add
label define V043293x    02   "02. B. $3,000 -$4,999" , add
label define V043293x    03   "03. C. $5,000 -$6,999" , add
label define V043293x    04   "04. D. $7,000 -$8,999" , add
label define V043293x    05   "05. E. $9,000 -$10,999" , add
label define V043293x    06   "06. F. $11,000-$12,999" , add
label define V043293x    07   "07. G. $13,000-$14,999" , add
label define V043293x    08   "08. H. $15,000-$16,999" , add
label define V043293x    09   "09. J. $17,000-$19,999" , add
label define V043293x    10   "10. K. $20,000-$21,999" , add
label define V043293x    11   "11. M. $22,000-$24,999" , add
label define V043293x    12   "12. N. $25,000-$29,999" , add
label define V043293x    13   "13. P. $30,000-$34,999" , add
label define V043293x    14   "14. Q. $35,000-$39,999" , add
label define V043293x    15   "15. R. $40,000-$44,999" , add
label define V043293x    16   "16. S. $45,000-$49,999" , add
label define V043293x    17   "17. T. $50,000-$59,999" , add
label define V043293x    18   "18. U. $60,000-$69,999" , add
label define V043293x    19   "19. V. $70,000-$79,999" , add
label define V043293x    20   "20. W. $80,000-$89,999" , add
label define V043293x    21   "21. X. $90,000-$104,999" , add
label define V043293x    22   "22. Y. $105,000-$119,000" , add
label define V043293x    23   "23. Z. $120,000 and over" , add
label define V043293x    88   "88. Don't know" , add
label define V043293x    89   "89. Refused" , add
label define V043293x    00   "00. NA (8,9 in Y20)" , add
label define V043294f    01   "01. A. None or less than $2,999" , add
label define V043294f    02   "02. B. $3,000 -$4,999" , add
label define V043294f    03   "03. C. $5,000 -$6,999" , add
label define V043294f    04   "04. D. $7,000 -$8,999" , add
label define V043294f    05   "05. E. $9,000 -$10,999" , add
label define V043294f    06   "06. F. $11,000-$12,999" , add
label define V043294f    07   "07. G. $13,000-$14,999" , add
label define V043294f    08   "08. H. $15,000-$16,999" , add
label define V043294f    09   "09. J. $17,000-$19,999" , add
label define V043294f    10   "10. K. $20,000-$21,999" , add
label define V043294f    11   "11. M. $22,000-$24,999" , add
label define V043294f    12   "12. N. $25,000-$29,999" , add
label define V043294f    13   "13. P. $30,000-$34,999" , add
label define V043294f    14   "14. Q. $35,000-$39,999" , add
label define V043294f    15   "15. R. $40,000-$44,999" , add
label define V043294f    16   "16. S. $45,000-$49,999" , add
label define V043294f    17   "17. T. $50,000-$59,999" , add
label define V043294f    18   "18. U. $60,000-$69,999" , add
label define V043294f    19   "19. V. $70,000-$79,999" , add
label define V043294f    20   "20. W. $80,000-$89,999" , add
label define V043294f    21   "21. X. $90,000-$104,999" , add
label define V043294f    22   "22. Y. $105,000-$119,000" , add
label define V043294f    23   "23. Z. $120,000 and over" , add
label define V043294f    88   "88. Don't know" , add
label define V043294f    89   "89. Refused" , add
label define V043295f    1   "1. Yes" , add
label define V043295f    5   "5. No" , add
label define V043295f    8   "8. Don't know" , add
label define V043295f    9   "9. Refused" , add
label define V043296f    1   "1. Middle class" , add
label define V043296f    5   "5. Working class" , add
label define V043296f    7   "7. Other (SPECIFY)" , add
label define V043296f    8   "8. Don't know" , add
label define V043296f    9   "9. Refused" , add
label define V043297f    0   "0. Upper class {VOL}" , add
label define V043297f    1   "1. Middle class" , add
label define V043297f    5   "5. Working class" , add
label define V043297f    6   "6. Lower class {VOL}" , add
label define V043297f    7   "7. Other (SPECIFY)" , add
label define V043297f    8   "8. Don't know" , add
label define V043297f    9   "9. Refused" , add
label define V043298f   00   "00. Lower class (VOLUNTEERED)" , add
label define V043298f   01   "01. Average working class" , add
label define V043298f   02   "02. Working class -- NA if average or upper" , add
label define V043298f   03   "03. Upper working class" , add
label define V043298f   04   "04. Average middle class" , add
label define V043298f   05   "05. Middle class -- NA if average or upper" , add
label define V043298f   06   "06. Upper middle class" , add
label define V043298f   07   "07. Upper class (VOLUNTEERED)" , add
label define V043298f   77   "77. Other" , add
label define V043298f   88   "88. Don't know if working or middle class" , add
label define V043298f   89   "89. Refused; 'neither' or doesn't accept" , add
label define V043299f   10   "10. Black" , add
label define V043299f   12   "12. Black and Asian" , add
label define V043299f   13   "13. Black and Native American" , add
label define V043299f   14   "14. Black and Hispanic" , add
label define V043299f   15   "15. Black and White" , add
label define V043299f   20   "20. Asian" , add
label define V043299f   23   "23. Asian and Native American" , add
label define V043299f   24   "24. Asican and Hispanic" , add
label define V043299f   25   "25. Asian and White" , add
label define V043299f   30   "30. Native American" , add
label define V043299f   34   "34. Native American and Hispanic" , add
label define V043299f   35   "35. Native American and White" , add
label define V043299f   40   "40. Hispanic" , add
label define V043299f   45   "45. Hispanic and White" , add
label define V043299f   50   "50. White (no mention of other race)" , add
label define V043299f   70   "70. Other" , add
label define V043299f   88   "88. Don't know" , add
label define V043299f   89   "89. Refused" , add
label define V043299a   10   "10. Black" , add
label define V043299a   20   "20. Asian" , add
label define V043299a   30   "30. Native American" , add
label define V043299a   40   "40. Hispanic" , add
label define V043299a   50   "50. White (no mention of other race)" , add
label define V043299a   70   "70. Other" , add
label define V043299a   88   "88. Don't know" , add
label define V043299a   89   "89. Refused" , add
label define V043300f    1   "1. Yes" , add
label define V043300f    5   "5. No" , add
label define V043300f    8   "8. Don't know" , add
label define V043300f    9   "9. Refused" , add
label define V043301a    877   "877. None" , add
label define V043301a    888   "888. Don't know" , add
label define V043301a    889   "889. Refused" , add
label define V043301a    000   "000. NA; no mention; none" , add
label define V043302f    0   "0. None" , add
label define V043302f    1   "1. One" , add
label define V043302f    2   "2. Two or more" , add
label define V043302f    9   "9. Respondent refused to answer or doesn't know" , add
label define V043303f    877   "877. None; neither" , add
label define V043303f    888   "888. Don't know" , add
label define V043303f    889   "889. Refused" , add
label define V043303f    000   "000. NA; no mention; none" , add
label define V043303x    877   "877. None" , add
label define V043303x    888   "888. Don't know" , add
label define V043303x    889   "889. Refused" , add
label define V043303x    000   "000. NA; no mention; none" , add
label define V043304x    0   "0. No Hispanic mention" , add
label define V043304x    1   "1. Spanish/Hispanic mention in Y24x" , add
label define V043304x    2   "2. Spanish/Hispanic mention in Y26a/Y26b/Y26c/Y27a" , add
label define V043304x    3   "3. Spanish/Hispanic mention in both" , add
label define V043305f    1   "1. Yes" , add
label define V043305f    5   "5. No" , add
label define V043305f    8   "8. Don't know" , add
label define V043305f    9   "9. Refused" , add
label define V043305f    0   "0. NA" , add
label define V043306f    1   "1. Mexican" , add
label define V043306f    2   "2. Puerto Rican" , add
label define V043306f    3   "3. Cuban" , add
label define V043306f    4   "4. Latin American" , add
label define V043306f    5   "5. Central American" , add
label define V043306f    6   "6. Spanish" , add
label define V043306f    7   "7. Other (SPECIFY) {VOL}" , add
label define V043306f    8   "8. Don't know" , add
label define V043306f    9   "9. Refused" , add
label define V043306f    0   "0. NA" , add
label define V043307f    888   "888. Don't know" , add
label define V043307f    889   "889. Refused" , add
label define V043307f    000   "000. NA" , add
label define V043308f    00   "00. Less than 1 year" , add
label define V043308f    01   "01. 12-18 months; 1 year" , add
label define V043308f    02   "02. 19-24 months; 2 years" , add
label define V043308f    03   "03. 3 years" , add
label define V043308f    76   "76. 76 years or more" , add
label define V043308f    88   "88. Don't know" , add
label define V043308f    89   "89. Refused" , add
label define V043309a    888   "888. Don't know" , add
label define V043309a    889   "889. Refused" , add
label define V043309a    000   "000. NA" , add
label define V043310f    00   "00. Less than 1 mile" , add
label define V043310f    01   "01. One mile" , add
label define V043310f    02   "02. 2-4 miles" , add
label define V043310f    03   "03. 5-9 miles" , add
label define V043310f    04   "04. 10-19 miles" , add
label define V043310f    05   "05. 20-49 miles" , add
label define V043310f    06   "06. 50-99 miles" , add
label define V043310f    07   "07. 100-199 miles" , add
label define V043310f    08   "08. 200-499 miles" , add
label define V043310f    09   "09. 500 miles or more" , add
label define V043310f    90   "90. Other (SPECIFY)" , add
label define V043311f    00   "00. Less than 1 year" , add
label define V043311f    01   "01. 12-18 months; 1 year" , add
label define V043311f    02   "02. 19-24 months; 2 years" , add
label define V043311f    03   "03. 3 years" , add
label define V043311f    76   "76. 76 years or more" , add
label define V043311f    88   "88. Don't know" , add
label define V043311f    89   "89. Refused" , add
label define V043312f    1   "1. Own house" , add
label define V043312f    5   "5. Pay rent" , add
label define V043312f    7   "7. Other (SPECIFY)" , add
label define V043312f    8   "8. Don't know" , add
label define V043312f    9   "9. Refused" , add
label define V043401a    1   "1. Marked" , add
label define V043401a    5   "5. Not marked" , add
label define V043401a    0   "0. NA" , add
label define V043401b    1   "1. Marked" , add
label define V043401b    5   "5. Not marked" , add
label define V043401b    0   "0. NA" , add
label define V043401c    1   "1. Marked" , add
label define V043401c    5   "5. Not marked" , add
label define V043401c    0   "0. NA" , add
label define V043401d    1   "1. Marked" , add
label define V043401d    5   "5. Not marked" , add
label define V043401d    0   "0. NA" , add
label define V043401e    1   "1. Marked" , add
label define V043401e    5   "5. Not marked" , add
label define V043401e    0   "0. NA" , add
label define V043401f    1   "1. Marked" , add
label define V043401f    5   "5. Not marked" , add
label define V043401f    0   "0. NA" , add
label define V043402f    1   "1. Very good" , add
label define V043402f    2   "2. Good" , add
label define V043402f    3   "3. Fair" , add
label define V043402f    4   "4. Poor" , add
label define V043402f    5   "5. Very poor" , add
label define V043402f    0   "0. NA" , add
label define V043403f    1   "1. Very high" , add
label define V043403f    2   "2. Fairly high" , add
label define V043403f    3   "3. Average" , add
label define V043403f    4   "4. Fairly low" , add
label define V043403f    5   "5. Very low" , add
label define V043403f    0   "0. NA" , add
label define V043404f    1   "1. Very high" , add
label define V043404f    2   "2. Fairly high" , add
label define V043404f    3   "3. Average" , add
label define V043404f    4   "4. Fairly low" , add
label define V043404f    5   "5. Very low" , add
label define V043404f    0   "0. NA" , add
label define V043405f    1   "1. Not at all suspicious" , add
label define V043405f    2   "2. Somewhat suspicious" , add
label define V043405f    3   "3. Very suspicious" , add
label define V043405f    0   "0. NA" , add
label define V043406f    1   "1. Very high" , add
label define V043406f    2   "2. Fairly high" , add
label define V043406f    3   "3. Average" , add
label define V043406f    4   "4. Fairly low" , add
label define V043406f    5   "5. Very low" , add
label define V043406f    0   "0. NA" , add
label define V043407f    1   "1. Completely sincere" , add
label define V043407f    2   "2. Usually sincere" , add
label define V043407f    3   "3. Often seemed to be insincere" , add
label define V043407f    0   "0. NA" , add
label define V043408f    1   "1. Yes {SPECIFY}" , add
label define V043408f    5   "5. No" , add
label define V043409f    1   "1. Yes, think R reported correctly" , add
label define V043409f    2   "2. No, think R reported incorrectly" , add
label define V043409f    3   "3. Refused income questions" , add
label define V043409f    4   "4. No, think R reported dishonestly" , add
label define V043409f    0   "0. NA" , add
label define V043409a    01   "01. A. None or less than $2,999" , add
label define V043409a    02   "02. B. $3,000 -$4,999" , add
label define V043409a    03   "03. C. $5,000 -$6,999" , add
label define V043409a    04   "04. D. $7,000 -$8,999" , add
label define V043409a    05   "05. E. $9,000 -$10,999" , add
label define V043409a    06   "06. F. $11,000-$12,999" , add
label define V043409a    07   "07. G. $13,000-$14,999" , add
label define V043409a    08   "08. H. $15,000-$16,999" , add
label define V043409a    09   "09. J. $17,000-$19,999" , add
label define V043409a    10   "10. K. $20,000-$21,999" , add
label define V043409a    11   "11. M. $22,000-$24,999" , add
label define V043409a    12   "12. N. $25,000-$29,999" , add
label define V043409a    13   "13. P. $30,000-$34,999" , add
label define V043409a    14   "14. Q. $35,000-$39,999" , add
label define V043409a    15   "15. R. $40,000-$44,999" , add
label define V043409a    16   "16. S. $45,000-$49,999" , add
label define V043409a    17   "17. T. $50,000-$59,999" , add
label define V043409a    18   "18. U. $60,000-$69,999" , add
label define V043409a    19   "19. V. $70,000-$79,999" , add
label define V043409a    20   "20. W. $80,000-$89,999" , add
label define V043409a    21   "21. X. $90,000-$104,999" , add
label define V043409a    22   "22. Y. $105,000-$119,000" , add
label define V043409a    23   "23. Z. $120,000 and over" , add
label define V043409a    98   "98. IMPOSSIBLE TO ESTIMATE" , add
label define V043409a    00   "00. NA" , add
label define V043410f    97   "97. 97 and older" , add
label define V043410f    98   "98. Hard to guess {SPECIFY}" , add
label define V043410f    0   "0. NA" , add
label define V043411f    1   "1. Male" , add
label define V043411f    2   "2. Female" , add
label define V043411f    0   "0. NA" , add
label define V043412f    1   "1. Low - probably less than high school diploma" , add
label define V043412f    2   "2. Probably has a high school diploma but" , add
label define V043412f    3   "3. Probably a little college" , add
label define V043412f    4   "4. Probably a college degree" , add
label define V043412f    8   "8. Hard to guess {SPECIFY}" , add
label define V043412f    0   "0. NA" , add
label define V043413a    10   "10. Negative - general" , add
label define V043413a    11   "11. Negative - too long" , add
label define V043413a    12   "12. Negative - too complicated" , add
label define V043413a    13   "13. Negative - boring/tedious/repetitious" , add
label define V043413a    15   "15. R wanted to stop before interview completed. After" , add
label define V043413a    20   "20. R complained and/or interviewer observed that R was" , add
label define V043413a    22   "22. R complained and/or interviewer observed that R was" , add
label define V043413a    30   "30. R expressed (especially repeatedly) doubts/apologies/" , add
label define V043413a    31   "31. R expressed (especially repeatedly) doubts/apologies/" , add
label define V043413a    40   "40. R was agitated or stressed by interview PROCESS" , add
label define V043413a    41   "41. R became angry at interview CONTENT" , add
label define V043413a    45   "45. R became concerned about sampling purpose or bias:" , add
label define V043413a    50   "50. R could not read Respondent Booklet" , add
label define V043413a    70   "70. R appeared to enjoy the interview (R was 'cooperative'" , add
label define V043413a    80   "80. Neutral or no feedback (1st mention only" , add
label define V043413a    00   "00. NA" , add
label define V043413b    10   "10. Negative - general" , add
label define V043413b    11   "11. Negative - too long" , add
label define V043413b    12   "12. Negative - too complicated" , add
label define V043413b    13   "13. Negative - boring/tedious/repetitious" , add
label define V043413b    15   "15. R wanted to stop before interview completed. After" , add
label define V043413b    20   "20. R complained and/or interviewer observed that R was" , add
label define V043413b    22   "22. R complained and/or interviewer observed that R was" , add
label define V043413b    30   "30. R expressed (especially repeatedly) doubts/apologies/" , add
label define V043413b    31   "31. R expressed (especially repeatedly) doubts/apologies/" , add
label define V043413b    40   "40. R was agitated or stressed by interview PROCESS" , add
label define V043413b    41   "41. R became angry at interview CONTENT" , add
label define V043413b    45   "45. R became concerned about sampling purpose or bias:" , add
label define V043413b    50   "50. R could not read Respondent Booklet" , add
label define V043413b    70   "70. R appeared to enjoy the interview (R was 'cooperative'" , add
label define V043413c    10   "10. Negative - general" , add
label define V043413c    11   "11. Negative - too long" , add
label define V043413c    12   "12. Negative - too complicated" , add
label define V043413c    13   "13. Negative - boring/tedious/repetitious" , add
label define V043413c    15   "15. R wanted to stop before interview completed. After" , add
label define V043413c    20   "20. R complained and/or interviewer observed that R was" , add
label define V043413c    22   "22. R complained and/or interviewer observed that R was" , add
label define V043413c    30   "30. R expressed (especially repeatedly) doubts/apologies/" , add
label define V043413c    31   "31. R expressed (especially repeatedly) doubts/apologies/" , add
label define V043413c    40   "40. R was agitated or stressed by interview PROCESS" , add
label define V043413c    41   "41. R became angry at interview CONTENT" , add
label define V043413c    45   "45. R became concerned about sampling purpose or bias:" , add
label define V043413c    50   "50. R could not read Respondent Booklet" , add
label define V043413c    70   "70. R appeared to enjoy the interview (R was 'cooperative'" , add
label define V043413d    10   "10. Negative - general" , add
label define V043413d    11   "11. Negative - too long" , add
label define V043413d    12   "12. Negative - too complicated" , add
label define V043413d    13   "13. Negative - boring/tedious/repetitious" , add
label define V043413d    15   "15. R wanted to stop before interview completed. After" , add
label define V043413d    20   "20. R complained and/or interviewer observed that R was" , add
label define V043413d    22   "22. R complained and/or interviewer observed that R was" , add
label define V043413d    30   "30. R expressed (especially repeatedly) doubts/apologies/" , add
label define V043413d    31   "31. R expressed (especially repeatedly) doubts/apologies/" , add
label define V043413d    40   "40. R was agitated or stressed by interview PROCESS" , add
label define V043413d    41   "41. R became angry at interview CONTENT" , add
label define V043413d    45   "45. R became concerned about sampling purpose or bias:" , add
label define V043413d    50   "50. R could not read Respondent Booklet" , add
label define V043413d    70   "70. R appeared to enjoy the interview (R was 'cooperative'" , add
label define V043413e    10   "10. Negative - general" , add
label define V043413e    11   "11. Negative - too long" , add
label define V043413e    12   "12. Negative - too complicated" , add
label define V043413e    13   "13. Negative - boring/tedious/repetitious" , add
label define V043413e    15   "15. R wanted to stop before interview completed. After" , add
label define V043413e    20   "20. R complained and/or interviewer observed that R was" , add
label define V043413e    22   "22. R complained and/or interviewer observed that R was" , add
label define V043413e    30   "30. R expressed (especially repeatedly) doubts/apologies/" , add
label define V043413e    31   "31. R expressed (especially repeatedly) doubts/apologies/" , add
label define V043413e    40   "40. R was agitated or stressed by interview PROCESS" , add
label define V043413e    41   "41. R became angry at interview CONTENT" , add
label define V043413e    45   "45. R became concerned about sampling purpose or bias:" , add
label define V043413e    50   "50. R could not read Respondent Booklet" , add
label define V043413e    70   "70. R appeared to enjoy the interview (R was 'cooperative'" , add
label define V043413f    10   "10. Negative - general" , add
label define V043413f    11   "11. Negative - too long" , add
label define V043413f    12   "12. Negative - too complicated" , add
label define V043413f    13   "13. Negative - boring/tedious/repetitious" , add
label define V043413f    15   "15. R wanted to stop before interview completed. After" , add
label define V043413f    20   "20. R complained and/or interviewer observed that R was" , add
label define V043413f    22   "22. R complained and/or interviewer observed that R was" , add
label define V043413f    30   "30. R expressed (especially repeatedly) doubts/apologies/" , add
label define V043413f    31   "31. R expressed (especially repeatedly) doubts/apologies/" , add
label define V043413f    40   "40. R was agitated or stressed by interview PROCESS" , add
label define V043413f    41   "41. R became angry at interview CONTENT" , add
label define V043413f    45   "45. R became concerned about sampling purpose or bias:" , add
label define V043413f    50   "50. R could not read Respondent Booklet" , add
label define V043413f    70   "70. R appeared to enjoy the interview (R was 'cooperative'" , add
label define V043413g    10   "10. Negative - general" , add
label define V043413g    11   "11. Negative - too long" , add
label define V043413g    12   "12. Negative - too complicated" , add
label define V043413g    13   "13. Negative - boring/tedious/repetitious" , add
label define V043413g    15   "15. R wanted to stop before interview completed. After" , add
label define V043413g    20   "20. R complained and/or interviewer observed that R was" , add
label define V043413g    22   "22. R complained and/or interviewer observed that R was" , add
label define V043413g    30   "30. R expressed (especially repeatedly) doubts/apologies/" , add
label define V043413g    31   "31. R expressed (especially repeatedly) doubts/apologies/" , add
label define V043413g    40   "40. R was agitated or stressed by interview PROCESS" , add
label define V043413g    41   "41. R became angry at interview CONTENT" , add
label define V043413g    45   "45. R became concerned about sampling purpose or bias:" , add
label define V043413g    50   "50. R could not read Respondent Booklet" , add
label define V043413g    70   "70. R appeared to enjoy the interview (R was 'cooperative'" , add
label define V044001f   1   "1. Standard turnout format; Pre patriotism questions" , add
label define V044001f   2   "2. Experimental turnout format; Pre patriotism questions" , add
label define V044001f   3   "3. Standard turnout format; Post patriotism questions" , add
label define V044001f   4   "4. Experimental turnout format; Post patriotism question" , add
label define V044002f   11   "11. November" , add
label define V044002f   12   "12. December" , add
label define V044002f   00   "00. NA" , add
label define V044003f   00   "00. NA" , add
label define V044005f   1   "1. October 29, 2004 version" , add
label define V044006f   11   "11. November" , add
label define V044006f   12   "12. December" , add
label define V044006f   00   "00. NA" , add
label define V044007f   00   "00. NA" , add
label define V044009f   1   "1. October 29, 2004 version" , add
label define V044010a   0   "0. NA" , add
label define V044010b   0   "0. NA" , add
label define V044011f   1   "1. IW conducted in 1 session" , add
label define V044011f   2   "2. IW conducted in 2 sessions" , add
label define V044011f   3   "3. IW conducted in 3 sessions" , add
label define V044011f   4   "4. IW conducted in 4 sessions" , add
label define V044011f   0   "0. NA" , add
label define V044012f   0   "0. Post IW conducted using a single version of the instrument" , add
label define V044012f   1   "1. Post IW conducted using more than a single version" , add
label define V044012f   9   "9. NA" , add
label define V044013f   1   "1. One interviewer conducted the entire interview" , add
label define V044013f   2   "2. Two interviewers conducted the interview" , add
label define V044013f   0   "0. NA" , add
label define V044015a   1    "1. October 29, 2004 version" , add
label define V044015b   1    "1. October 29, 2004 version" , add
label define V044015c   1    "1. October 29, 2004 version" , add
label define V044016a   00   "00. Interview completed in 1 session" , add
label define V044016a   01   "01. Media module (A1-A8)" , add
label define V044016a   02   "02. 1st budget module (E5-E5c)" , add
label define V044016a   03   "03. Liberal-conservative scales (G4-G4a1)" , add
label define V044016a   04   "04. Interventionism (G6-G6g)" , add
label define V044016a   05   "05. Abortion  (G7a-G7c)" , add
label define V044016a   06   "06. Office recognition of political figures (J7-J7d1)" , add
label define V044016a   07   "07. 1st  sexism module (K4a-K4c)" , add
label define V044016a   08   "08. Children's traits (N1-N1d)" , add
label define V044016a   09   "09. Stereotypes (P4-P6d)" , add
label define V044016a   10   "10. CSES module (Q1-Q28)" , add
label define V044016b   00   "00. Interview completed in 1 session" , add
label define V044016b   01   "01. Media module (A1-A8)" , add
label define V044016b   02   "02. 1st budget module (E5-E5c)" , add
label define V044016b   03   "03. Liberal-conservative scales (G4-G4a1)" , add
label define V044016b   04   "04. Interventionism (G6-G6g)" , add
label define V044016b   05   "05. Abortion  (G7a-G7c)" , add
label define V044016b   06   "06. Office recognition of political figures (J7-J7d1)" , add
label define V044016b   07   "07. 1st  sexism module (K4a-K4c)" , add
label define V044016b   08   "08. Children's traits (N1-N1d)" , add
label define V044016b   09   "09. Stereotypes (P4-P6d)" , add
label define V044016b   10   "10. CSES module (Q1-Q28)" , add
label define V044021f   0   "0. Not a refusal conversion situation" , add
label define V044021f   1   "1. Refusal conversion" , add
label define V044023f   1   "1. All interviews conducted face-to-face" , add
label define V044024f   1001   "1001. Completed interview" , add
label define V044024f   5001   "5001. Final refusal by respondent" , add
label define V044024f   5002   "5002. Final refusal, not by respondent" , add
label define V044024f   5005   "5005. Refusal, conversion not attempted" , add
label define V044024f   6002   "6002. Final no contact" , add
label define V044024f   6003   "6003. Interview begun, not resumed" , add
label define V044024f   6004   "6004. Non-interview, permanent condition" , add
label define V044024f   6007   "6007. Non-interview, other reason" , add
label define V044025f   000   "000.00 NA" , add
label define V044026f   1   "1. All interviews were conducted in English" , add
label define V044027f   0   "0. Not selected for verification" , add
label define V044027f   2   "2. Verified, no inconsistencies" , add
label define V044027f   3   "3. Verified with discrepancies" , add
label define V044027f   4   "4. Failed verification" , add
label define V044027f   5   "5. Unable to verify (unable to contact respondent)" , add
label define V044027f   6   "6. Verification limit met (used when the case if flagged for" , add
label define V044028f   0   "0. Not flagged for evaluation" , add
label define V044028f   1   "1. Flagged for evaluation; not evaluated" , add
label define V044028f   2   "2. Evaluated" , add
label define V044029f   1   "1. Yes, tape-recorded" , add
label define V044029f   5   "5. No" , add
label define V044030f   20   "20. $20" , add
label define V044030f   50   "50. $50" , add
label define V044031f   00   "00. Respondent refused payment" , add
label define V044031f   20   "20. $20" , add
label define V044031f   50   "50. $50" , add
label define V044031f   99   "99. NA" , add
label define V044033f   1   "1. All respondents paid by check" , add
label define V044034f   0   "0. No Post-election incentive" , add
label define V044035f   0   "0. Persuasion letters not tracked" , add
label define V044036a    0   "0. Positive comment not coded at any call" , add
label define V044036a    1   "1. Positive comment coded for at least one call" , add
label define V044036b    0   "0. Time-delay comment not coded at any call" , add
label define V044036b    1   "1. Time-delay comment coded for at least one call" , add
label define V044036c    0   "0. Negative comment not coded at any call" , add
label define V044036c    1   "1. Negative comment coded for at least one call" , add
label define V044036d    0   "0. Eligibility comment not coded at any call" , add
label define V044036d    1   "1. Eligibility comment coded for at least one call" , add
label define V044036e    0   "0. Privacy comment not coded at any call" , add
label define V044036e    1   "1. Privacy comment coded for at least one call" , add
label define V044036f    0   "0. Political disinterest comment not coded at any call" , add
label define V044036f    1   "1. Political disinterest comment coded for at least one call" , add
label define V044037a    1   "1. Coded at 1 or more calls" , add
label define V044037a    5   "5. Not coded" , add
label define V044037b    1   "1. Coded at 1 or more calls" , add
label define V044037b    5   "5. Not coded" , add
label define V044037c    1   "1. Coded at 1 or more calls" , add
label define V044037c    5   "5. Not coded" , add
label define V044037d    1   "1. Coded at 1 or more calls" , add
label define V044037d    5   "5. Not coded" , add
label define V044037e    1   "1. Coded at 1 or more calls" , add
label define V044037e    5   "5. Not coded" , add
label define V044037f    1   "1. Coded at 1 or more calls" , add
label define V044037f    5   "5. Not coded" , add
label define V044037g    1   "1. Coded at 1 or more calls" , add
label define V044037g    5   "5. Not coded" , add
label define V044037h    1   "1. Coded at 1 or more calls" , add
label define V044037h    5   "5. Not coded" , add
label define V044037j    1   "1. Coded at 1 or more calls" , add
label define V044037j    5   "5. Not coded" , add
label define V044037k    1   "1. Coded at 1 or more calls" , add
label define V044037k    5   "5. Not coded" , add
label define V044037m    1   "1. Coded at 1 or more calls" , add
label define V044037m    5   "5. Not coded" , add
label define V044037n    1   "1. Coded at 1 or more calls" , add
label define V044037n    5   "5. Not coded" , add
label define V044037p    1   "1. Coded at 1 or more calls" , add
label define V044037p    5   "5. Not coded" , add
label define V044037q    1   "1. Coded at 1 or more calls" , add
label define V044037q    5   "5. Not coded" , add
label define V044037r    1   "1. Coded at 1 or more calls" , add
label define V044037r    5   "5. Not coded" , add
label define V044037s    1   "1. Coded at 1 or more calls" , add
label define V044037s    5   "5. Not coded" , add
label define V044037t    1   "1. Coded at 1 or more calls" , add
label define V044037t    5   "5. Not coded" , add
label define V044037u    1   "1. Coded at 1 or more calls" , add
label define V044037u    5   "5. Not coded" , add
label define V044037v    1   "1. Coded at 1 or more calls" , add
label define V044037v    5   "5. Not coded" , add
label define V044037w    1   "1. Coded at 1 or more calls" , add
label define V044037w    5   "5. Not coded" , add
label define V044037y    1   "1. Coded at 1 or more calls" , add
label define V044037y    5   "5. Not coded" , add
label define V044038f   0   "0. Respondent did not initially refuse" , add
label define V044038f   1   "1. Respondent initial refusal" , add
label define V044039f   0   "0. Informant did not initially refuse" , add
label define V044039f   1   "1. Informant initial refusal" , add
label define V044201f   0   "0. No errors in the Post-election instrument" , add
label define V044401f   1   "1. John Kerry thermometer administered first (D1b)" , add
label define V044401f   2   "2. Ralph Nader thermometer administered first (D1c)" , add
label define V044402a   1   "1. Administered 1st" , add
label define V044402a   2   "2. Administered 2nd" , add
label define V044402a   3   "3. Administered 3rd" , add
label define V044402a   4   "4. Administered 4th" , add
label define V044402b   1   "1. Administered 1st" , add
label define V044402b   2   "2. Administered 2nd" , add
label define V044402b   3   "3. Administered 3rd" , add
label define V044402b   4   "4. Administered 4th" , add
label define V044402c   1   "1. Administered 1st" , add
label define V044402c   2   "2. Administered 2nd" , add
label define V044402c   3   "3. Administered 3rd" , add
label define V044402c   4   "4. Administered 4th" , add
label define V044402d   1   "1. Administered 1st" , add
label define V044402d   2   "2. Administered 2nd" , add
label define V044402d   3   "3. Administered 3rd" , add
label define V044402d   4   "4. Administered 4th" , add
label define V044403a   1   "1. Administered 1st" , add
label define V044403a   2   "2. Administered 2nd" , add
label define V044403a   3   "3. Administered 3rd" , add
label define V044403a   4   "4. Administered 4th" , add
label define V044403a   5   "5. Administered 5th" , add
label define V044403a   6   "6. Administered 6th" , add
label define V044403b   1   "1. Administered 1st" , add
label define V044403b   2   "2. Administered 2nd" , add
label define V044403b   3   "3. Administered 3rd" , add
label define V044403b   4   "4. Administered 4th" , add
label define V044403b   5   "5. Administered 5th" , add
label define V044403b   6   "6. Administered 6th" , add
label define V044403c   1   "1. Administered 1st" , add
label define V044403c   2   "2. Administered 2nd" , add
label define V044403c   3   "3. Administered 3rd" , add
label define V044403c   4   "4. Administered 4th" , add
label define V044403c   5   "5. Administered 5th" , add
label define V044403c   6   "6. Administered 6th" , add
label define V044403d   1   "1. Administered 1st" , add
label define V044403d   2   "2. Administered 2nd" , add
label define V044403d   3   "3. Administered 3rd" , add
label define V044403d   4   "4. Administered 4th" , add
label define V044403d   5   "5. Administered 5th" , add
label define V044403d   6   "6. Administered 6th" , add
label define V044403e   1   "1. Administered 1st" , add
label define V044403e   2   "2. Administered 2nd" , add
label define V044403e   3   "3. Administered 3rd" , add
label define V044403e   4   "4. Administered 4th" , add
label define V044403e   5   "5. Administered 5th" , add
label define V044403e   6   "6. Administered 6th" , add
label define V044403f   1   "1. Administered 1st" , add
label define V044403f   2   "2. Administered 2nd" , add
label define V044403f   3   "3. Administered 3rd" , add
label define V044403f   4   "4. Administered 4th" , add
label define V044403f   5   "5. Administered 5th" , add
label define V044403f   6   "6. Administered 6th" , add
label define V044406a   1   "1. Administered 1st" , add
label define V044406a   2   "2. Administered 2nd" , add
label define V044406a   3   "3. Administered 3rd" , add
label define V044406a   4   "4. Administered 4th" , add
label define V044406a   5   "5. Administered 5th" , add
label define V044406a   6   "6. Administered 6th" , add
label define V044406a   7   "7. Administered 7th" , add
label define V044406a   8   "8. Administered 8th" , add
label define V044406a   9   "9. Administered 9th" , add
label define V044406b   1   "1. Administered 1st" , add
label define V044406b   2   "2. Administered 2nd" , add
label define V044406b   3   "3. Administered 3rd" , add
label define V044406b   4   "4. Administered 4th" , add
label define V044406b   5   "5. Administered 5th" , add
label define V044406b   6   "6. Administered 6th" , add
label define V044406b   7   "7. Administered 7th" , add
label define V044406b   8   "8. Administered 8th" , add
label define V044406b   9   "9. Administered 9th" , add
label define V044406c   1   "1. Administered 1st" , add
label define V044406c   2   "2. Administered 2nd" , add
label define V044406c   3   "3. Administered 3rd" , add
label define V044406c   4   "4. Administered 4th" , add
label define V044406c   5   "5. Administered 5th" , add
label define V044406c   6   "6. Administered 6th" , add
label define V044406c   7   "7. Administered 7th" , add
label define V044406c   8   "8. Administered 8th" , add
label define V044406c   9   "9. Administered 9th" , add
label define V044406d   1   "1. Administered 1st" , add
label define V044406d   2   "2. Administered 2nd" , add
label define V044406d   3   "3. Administered 3rd" , add
label define V044406d   4   "4. Administered 4th" , add
label define V044406d   5   "5. Administered 5th" , add
label define V044406d   6   "6. Administered 6th" , add
label define V044406d   7   "7. Administered 7th" , add
label define V044406d   8   "8. Administered 8th" , add
label define V044406d   9   "9. Administered 9th" , add
label define V044406e   1   "1. Administered 1st" , add
label define V044406e   2   "2. Administered 2nd" , add
label define V044406e   3   "3. Administered 3rd" , add
label define V044406e   4   "4. Administered 4th" , add
label define V044406e   5   "5. Administered 5th" , add
label define V044406e   6   "6. Administered 6th" , add
label define V044406e   7   "7. Administered 7th" , add
label define V044406e   8   "8. Administered 8th" , add
label define V044406e   9   "9. Administered 9th" , add
label define V044406f   1   "1. Administered 1st" , add
label define V044406f   2   "2. Administered 2nd" , add
label define V044406f   3   "3. Administered 3rd" , add
label define V044406f   4   "4. Administered 4th" , add
label define V044406f   5   "5. Administered 5th" , add
label define V044406f   6   "6. Administered 6th" , add
label define V044406f   7   "7. Administered 7th" , add
label define V044406f   8   "8. Administered 8th" , add
label define V044406f   9   "9. Administered 9th" , add
label define V044406g   1   "1. Administered 1st" , add
label define V044406g   2   "2. Administered 2nd" , add
label define V044406g   3   "3. Administered 3rd" , add
label define V044406g   4   "4. Administered 4th" , add
label define V044406g   5   "5. Administered 5th" , add
label define V044406g   6   "6. Administered 6th" , add
label define V044406g   7   "7. Administered 7th" , add
label define V044406g   8   "8. Administered 8th" , add
label define V044406g   9   "9. Administered 9th" , add
label define V044406h   1   "1. Administered 1st" , add
label define V044406h   2   "2. Administered 2nd" , add
label define V044406h   3   "3. Administered 3rd" , add
label define V044406h   4   "4. Administered 4th" , add
label define V044406h   5   "5. Administered 5th" , add
label define V044406h   6   "6. Administered 6th" , add
label define V044406h   7   "7. Administered 7th" , add
label define V044406h   8   "8. Administered 8th" , add
label define V044406h   9   "9. Administered 9th" , add
label define V044406j   1   "1. Administered 1st" , add
label define V044406j   2   "2. Administered 2nd" , add
label define V044406j   3   "3. Administered 3rd" , add
label define V044406j   4   "4. Administered 4th" , add
label define V044406j   5   "5. Administered 5th" , add
label define V044406j   6   "6. Administered 6th" , add
label define V044406j   7   "7. Administered 7th" , add
label define V044406j   8   "8. Administered 8th" , add
label define V044406j   9   "9. Administered 9th" , add
label define V044407f   1   "1. Democratic House candidate placement administered first (G4b)" , add
label define V044407f   2   "2. Republican House candidate placement administered first (G4c)" , add
label define V044408f   1   "1. Democratic House candidate placement administered first (G5b)" , add
label define V044408f   2   "2. Republican House candidate placement administered first (G5c)" , add
label define V044409f   1   "1. George Bush placement administered first (G6b)" , add
label define V044409f   2   "2. John Kerry placement administered first (G6c)" , add
label define V044410f   1   "1. Democratic House candidate placement administered first (G6d)" , add
label define V044410f   2   "2. Republican House candidate placement administered first (G6e)" , add
label define V044411f   1   "1. Democratic party placement administered first (G6f)" , add
label define V044411f   2   "2. Republican party placement administered first (G6g)" , add
label define V044412f   1   "1. George Bush placement administered first (G7b)" , add
label define V044412f   2   "2. John Kerry placement administered first (G7c)" , add
label define V044413f   1   "1. Democratic House candidate placement administered first (G7d)" , add
label define V044413f   2   "2. Republican House candidate placement administered first (G7e)" , add
label define V044414f   1   "1. Democratic party  placement administered first (G7f)" , add
label define V044414f   2   "2. Republican party  placement administered first (G7g)" , add
label define V044415a   1   "1. Administered 1st" , add
label define V044415a   2   "2. Administered 2nd" , add
label define V044415a   3   "3. Administered 3rd" , add
label define V044415b   1   "1. Administered 1st" , add
label define V044415b   2   "2. Administered 2nd" , add
label define V044415b   3   "3. Administered 3rd" , add
label define V044415c   1   "1. Administered 1st" , add
label define V044415c   2   "2. Administered 2nd" , add
label define V044415c   3   "3. Administered 3rd" , add
label define V044416a   1   "1. Administered 1st" , add
label define V044416a   2   "2. Administered 2nd" , add
label define V044416a   3   "3. Administered 3rd" , add
label define V044416b   1   "1. Administered 1st" , add
label define V044416b   2   "2. Administered 2nd" , add
label define V044416b   3   "3. Administered 3rd" , add
label define V044416c   1   "1. Administered 1st" , add
label define V044416c   2   "2. Administered 2nd" , add
label define V044416c   3   "3. Administered 3rd" , add
label define V044417a   1   "1. Administered 1st" , add
label define V044417a   2   "2. Administered 2nd" , add
label define V044417a   3   "3. Administered 3rd" , add
label define V044417b   1   "1. Administered 1st" , add
label define V044417b   2   "2. Administered 2nd" , add
label define V044417b   3   "3. Administered 3rd" , add
label define V044417c   1   "1. Administered 1st" , add
label define V044417c   2   "2. Administered 2nd" , add
label define V044417c   3   "3. Administered 3rd" , add
label define V044502f   12   "12. Democratic incumbent running - Republican challenger" , add
label define V044502f   13   "13. Democratic incumbent running - other challenger" , add
label define V044502f   14   "14. Democratic incumbent running - unopposed" , add
label define V044502f   19   "19. Democratic incumbent running - Repub and other challengers" , add
label define V044502f   21   "21. Republican incumbent running - Democratic challenger" , add
label define V044502f   23   "23. Republican incumbent running - other challenger" , add
label define V044502f   24   "24. Republican incumbent running - unopposed" , add
label define V044502f   29   "29. Republican incumbent running - Dem and other challengers" , add
label define V044502f   31   "31. Other incumbent running - Democratic challenger" , add
label define V044502f   32   "32. Other incumbent running - Republican challenger" , add
label define V044502f   34   "34. Other incumbent running - unopposed" , add
label define V044502f   35   "35. Other incumbent running - Democratic, Republican challengers" , add
label define V044502f   36   "36. Other incumbent running -- Republican and other challengers" , add
label define V044502f   37   "37. Other incumbent running -- Democratic and other challengers" , add
label define V044502f   39   "39. Other incumbent running -- Democr, Republ, other challengers" , add
label define V044502f   40   "40. Democratic and Republican incumbents running - no other cand" , add
label define V044502f   41   "41. 2 Democratic incumbents running - no other candidate" , add
label define V044502f   42   "42. 2 Republican incumbents running - no other candidate" , add
label define V044502f   43   "43. Dem and Repub incumbents running - other candidate(s)" , add
label define V044502f   44   "44. Democratic non-incumbent only - no retiree/unclear who is " , add
label define V044502f   45   "45. Republican non-incumbent only - no retiree/unclear who is " , add
label define V044502f   46   "46. Democratic and Republican cands - no retiree/unclear who is" , add
label define V044502f   47   "47. Democratic and other cands - no retiree/unclear who is" , add
label define V044502f   48   "48. Republican and other cands - no retiree/unclear who is " , add
label define V044502f   49   "49. Democratic, Republican, other cands - no retiree/unclear who" , add
label define V044502f   51   "51. Dem incumbent not running -- Democratic candidate unopposed" , add
label define V044502f   52   "52. Dem incumbent not running -- Republican candidate unopposed" , add
label define V044502f   53   "53. Dem incumbent not running -- other candidate unopposed" , add
label define V044502f   55   "55. Dem incumbent not running -- Democratic and Republican cands" , add
label define V044502f   56   "56. Dem incumbent not running -- Republican and other cands" , add
label define V044502f   57   "57. Dem incumbent not running -- Democratic and other cands" , add
label define V044502f   59   "59. Dem incumbent not running -- Democr, Republ, other cands" , add
label define V044502f   61   "61. Rep incumbent not running -- Democratic candidate unopposed" , add
label define V044502f   62   "62. Rep incumbent not running -- Republican candidate unopposed" , add
label define V044502f   63   "63. Rep incumbent not running -- other candidate unopposed" , add
label define V044502f   65   "65. Rep incumbent not running -- Democratic and Republican cands" , add
label define V044502f   66   "66. Rep incumbent not running -- Republican and other cands" , add
label define V044502f   67   "67. Rep incumbent not running -- Democratic and other cands" , add
label define V044502f   69   "69. Rep incumbent not running -- Democr, Republ, other cands" , add
label define V044502f   71   "71. Other incumbent not running -- Democratic cand unopposed" , add
label define V044502f   72   "72. Other incumbent not running -- Republican cand unopposed" , add
label define V044502f   73   "73. Other incumbent not running -- other candidate unopposed" , add
label define V044502f   75   "75. Other incumbent not running -- Democratic, Republican cands" , add
label define V044502f   76   "76. Other incumbent not running -- Republican and other cands" , add
label define V044502f   77   "77. Other incumbent not running -- Democratic and other cands" , add
label define V044502f   79   "79. Other incumbent not running -- Democr, Republ, other cands" , add
label define V044502f   91   "91. Rep incumbent not running -Democratic and 2 Republican cands" , add
label define V044502f   92   "92. Rep incumbent not running -Republican and 2 Democratic cands" , add
label define V044502f   93   "93. Dem incumbent not running -Democratic and 2 Republican cands" , add
label define V044502f   94   "94. Dem incumbent not running -Republican and 2 Democratic cands" , add
label define V044503b   31   "31.  Democratic candidate in open House race" , add
label define V044503b   33   "33.  Democratic House running incumbent" , add
label define V044503b   35   "35.  Democratic House challenger" , add
label define V044503c   1   "1. Male" , add
label define V044503c   2   "2. Female" , add
label define V044504b   32   "32.  Republican candidate in open House race" , add
label define V044504b   34   "34.  Republican House running incumbent" , add
label define V044504b   36   "36.  Republican House challenger" , add
label define V044504c   1   "1. Male" , add
label define V044504c   2   "2. Female" , add
label define V044505b   37   "37.  Independent/3rd-party House candidate -  nonincumbent" , add
label define V044505b   38   "38.  Independent/3rd-party House candidate  - 2nd nonincument" , add
label define V044505b   39   "39.  Independent/3rd-party House incumbent" , add
label define V044505c   1   "1. Male" , add
label define V044505c   2   "2. Female" , add
label define V044506b   41   "41. Retiring Democratic House Representative" , add
label define V044506b   42   "42. Retiring Republican House Representative" , add
label define V044506b   43   "43. Retiring Independent/3rd-Party House Representative" , add
label define V044506c   1   "1. Male" , add
label define V044506c   2   "2. Female" , add
label define V044507f   12   "12. Democratic incumbent running - Republican challenger" , add
label define V044507f   13   "13. Democratic incumbent running - other challenger" , add
label define V044507f   14   "14. Democratic incumbent running - unopposed" , add
label define V044507f   19   "19. Democratic incumbent running - Repub and other challengers" , add
label define V044507f   21   "21. Republican incumbent running - Democratic challenger" , add
label define V044507f   23   "23. Republican incumbent running - other challenger" , add
label define V044507f   24   "24. Republican incumbent running - unopposed" , add
label define V044507f   29   "29. Republican incumbent running - Dem and other challengers" , add
label define V044507f   31   "31. Other incumbent running - Democratic challenger" , add
label define V044507f   32   "32. Other incumbent running - Republican challenger" , add
label define V044507f   34   "34. Other incumbent running - unopposed" , add
label define V044507f   35   "35. Other incumbent running - Democratic, Republican challengers" , add
label define V044507f   36   "36. Other incumbent running -- Republican and other challengers" , add
label define V044507f   37   "37. Other incumbent running -- Democratic and other challengers" , add
label define V044507f   39   "39. Other incumbent running -- Democr, Republ, other challengers" , add
label define V044507f   51   "51. Dem incumbent not running -- Democratic candidate unopposed" , add
label define V044507f   52   "52. Dem incumbent not running -- Republican candidate unopposed" , add
label define V044507f   53   "53. Dem incumbent not running -- other candidate unopposed" , add
label define V044507f   55   "55. Dem incumbent not running -- Democratic and Republican cands" , add
label define V044507f   56   "56. Dem incumbent not running -- Republican and other cands" , add
label define V044507f   57   "57. Dem incumbent not running -- Democratic and other cands" , add
label define V044507f   59   "59. Dem incumbent not running -- Democr, Republ, other cands" , add
label define V044507f   61   "61. Rep incumbent not running -- Democratic candidate unopposed" , add
label define V044507f   62   "62. Rep incumbent not running -- Republican candidate unopposed" , add
label define V044507f   63   "63. Rep incumbent not running -- other candidate unopposed" , add
label define V044507f   65   "65. Rep incumbent not running -- Democratic and Republican cands" , add
label define V044507f   66   "66. Rep incumbent not running -- Republican and other cands" , add
label define V044507f   67   "67. Rep incumbent not running -- Democratic and other cands" , add
label define V044507f   69   "69. Rep incumbent not running -- Democr, Republ, other cands" , add
label define V044507f   71   "71. Other incumbent not running --Democratic candidate unopposed" , add
label define V044507f   72   "72. Other incumbent not running --Republican candidate unopposed" , add
label define V044507f   73   "73. Other incumbent not running -- other candidate unopposed" , add
label define V044507f   75   "75. Other incumbent not running -- Democratic, Republican cands" , add
label define V044507f   76   "76. Other incumbent not running -- Republican and other cands" , add
label define V044507f   77   "77. Other incumbent not running -- Democratic and other cands" , add
label define V044507f   79   "79. Other incumbent not running -- Democr, Republ, other cands" , add
label define V044507f   81   "81. No race in state - Democratic incumbents" , add
label define V044507f   82   "82. No race in state - Republican incumbents" , add
label define V044507f   85   "85. No race in state - Democratic and Republican incumbents" , add
label define V044507f   87   "87. No race in state - Democratic and other incumbent" , add
label define V044507f   88   "88. No race in state - Republican and other incumbent" , add
label define V044508b   01   "01. Democratic candidate in open Senate race" , add
label define V044508b   03   "03. Democratic Senate running incumbent" , add
label define V044508b   05   "05. Democratic Senate challenger" , add
label define V044508c   1   "1. Male" , add
label define V044508c   2   "2. Female" , add
label define V044509b   02   "02. Republican candidate in open Senate race" , add
label define V044509b   04   "04. Republican Senate running incumbent" , add
label define V044509b   06   "06. Republican Senate challenger" , add
label define V044509c   1   "1. Male" , add
label define V044509c   2   "2. Female" , add
label define V044510b   07   "07. Independent/3rd-party Senate candidate -  nonincumbent" , add
label define V044510b   08   "08. Independent/3rd-party Senate candidate  - 2nd nonincument" , add
label define V044510b   09   "09. Independent/3rd-party Senate incumbent" , add
label define V044510c   1   "1. Male" , add
label define V044510c   2   "2. Female" , add
label define V044511b   11   "11. Democratic Junior Senator" , add
label define V044511b   12   "12. Republican Junior Senator" , add
label define V044511b   13   "13. Independent/3rd-Party Junior Senator" , add
label define V044511b   17   "17. Democratic Senior Senator" , add
label define V044511b   18   "18. Republican Senior Senator" , add
label define V044511b   19   "19. Independent/3rd Party Senior Senator" , add
label define V044511c   1   "1. Male" , add
label define V044511c   2   "2. Female" , add 
label define V044512b   17   "17. Democratic Senior Senator" , add
label define V044512b   18   "18. Republican Senior Senator" , add
label define V044512b   19   "19. Independent/3rd Party Senior Senator" , add
label define V044512c   1   "1. Male" , add
label define V044512c   2   "2. Female" , add
label define V044513b   11   "11. Democratic Junior Senator" , add
label define V044513b   12   "12. Republican Junior Senator" , add
label define V044513b   13   "13. Independent/3rd-Party Junior Senator" , add
label define V044513c   1   "1. Male"    
label define V044513c   2   "2. Female" , add
label define V044514a   1   "1. Democratic candidate" , add
label define V044514a   5   "5. Republican candidate" , add
label define V044514a   7   "7. Independent/3rd-party candidate" , add
label define V044514b   31   "31. Democratic House candidate in open race" , add
label define V044514b   32   "32. Republican House candidate in open race" , add
label define V044514b   33   "33. Democratic House incumbent" , add
label define V044514b   34   "34. Republican House incumbent" , add
label define V044514b   35   "35. Democratic House challenger" , add
label define V044514b   36   "36. Republican House challenger" , add
label define V044514b   37   "37. Non-incumbent independent/3rd-party House candidate" , add
label define V044514b   39   "39. Incumbent independent/3rd-party House candidate" , add
label define V044516a   1   "1. Democratic candidate" , add
label define V044516a   5   "5. Republican candidate" , add
label define V044516a   7   "7. Independent/3rd-party candidate" , add
label define V044516b   1   "1. Democratic Senate candidate in open race" , add
label define V044516b   2   "2. Republican Senate candidate in open race" , add
label define V044516b   3   "3. Democratic Senate incumbent" , add
label define V044516b   4   "4. Republican Senate incumbent" , add
label define V044516b   5   "5. Democratic Senate challenger" , add
label define V044516b   6   "6. Republican Senate challenger" , add
label define V044516b   7   "7. Non-incumbent independent/3rd-party Senate candidate" , add
label define V044516b   9   "9. Incumbent independent/3rd-party Senate candidate" , add
label define V045001f   1   "1. Very much interested" , add
label define V045001f   3   "3. Somewhat interested" , add
label define V045001f   5   "5. Not much interested" , add
label define V045001f   8   "8. Don't know" , add
label define V045001f   9   "9. Refused" , add
label define V045002f   1   "1. Yes" , add
label define V045002f   5   "5. No" , add
label define V045002f   8   "8. Don't know" , add
label define V045002f   9   "9. Refused" , add
label define V045002a   1   "1. A good many" , add
label define V045002a   3   "3. Several" , add
label define V045002a   5   "5. Just one or two" , add
label define V045002a   8   "8. Don't know" , add
label define V045002a   9   "9. Refused" , add
label define V045003f   0   "0. None" , add
label define V045003f   1   "1. One day" , add
label define V045003f   2   "2. Two days" , add
label define V045003f   3   "3. Three days" , add
label define V045003f   4   "4. Four days" , add
label define V045003f   5   "5. Five days" , add
label define V045003f   6   "6. Six days" , add
label define V045003f   7   "7. Every day" , add
label define V045003f   8   "8. Don't know" , add
label define V045003f   9   "9. Refused" , add
label define V045003a   1   "1. A great deal" , add
label define V045003a   2   "2. Quite a bit" , add
label define V045003a   3   "3. Some" , add
label define V045003a   4   "4. Very little" , add
label define V045003a   5   "5. None" , add
label define V045003a   8   "8. Don't know" , add
label define V045003a   9   "9. Refused" , add
label define V045004f   1   "1. Yes" , add
label define V045004f   5   "5. No" , add
label define V045004f   8   "8. Don't know" , add
label define V045004f   9   "9. Refused" , add
label define V045004a   1   "1. A great deal" , add
label define V045004a   2   "2. Quite a bit" , add
label define V045004a   3   "3. Some" , add
label define V045004a   4   "4. Very little" , add
label define V045004a   5   "5. None" , add
label define V045004a   8   "8. Don't know" , add
label define V045004a   9   "9. Refused" , add
label define V045005f   1   "1. Yes" , add
label define V045005f   5   "5. No" , add
label define V045005f   8   "8. Don't know" , add
label define V045005f   9   "9. Refused" , add
label define V045005a   1   "1. A good many" , add
label define V045005a   3   "3. Several" , add
label define V045005a   5   "5. Just one or two" , add
label define V045005a   8   "8. Don't know" , add
label define V045005a   9   "9. Refused" , add
label define V045006f   1   "1. A great deal" , add
label define V045006f   2   "2. Quite a bit" , add
label define V045006f   3   "3. Some" , add
label define V045006f   4   "4. Very little" , add
label define V045006f   5   "5. None" , add
label define V045006f   8   "8. Don't know" , add
label define V045006f   9   "9. Refused" , add
label define V045007f   1   "1. Just about always" , add
label define V045007f   2   "2. Most of the time" , add
label define V045007f   3   "3. Only some of the time" , add
label define V045007f   4   "4. Almost never" , add
label define V045007f   5   "5. None of the time [VOL]" , add
label define V045007f   8   "8. Don't know" , add
label define V045007f   9   "9. Refused" , add
label define V045008f   1   "1. Yes" , add
label define V045008f   5   "5. No" , add
label define V045008f   8   "8. Don't know" , add
label define V045008f   9   "9. Refused" , add
label define V045008a   1   "1. Democrats" , add
label define V045008a   5   "5. Republicans" , add
label define V045008a   6   "6. Both" , add
label define V045008a   7   "7. Other {SPECIFY}" , add
label define V045008a   8   "8. Don't know" , add
label define V045008a   9   "9. Refused" , add
label define V045009f   1   "1. Yes" , add
label define V045009f   5   "5. No" , add
label define V045009f   8   "8. Don't know" , add
label define V045009f   9   "9. Refused" , add
label define V045010f   1   "1. Yes" , add
label define V045010f   5   "5. No" , add
label define V045010f   8   "8. Don't know" , add
label define V045010f   9   "9. Refused" , add
label define V045011f   1   "1. Yes" , add
label define V045011f   5   "5. No" , add
label define V045011f   8   "8. Don't know" , add
label define V045011f   9   "9. Refused" , add
label define V045012f   1   "1. Yes" , add
label define V045012f   5   "5. No" , add
label define V045012f   8   "8. Don't know" , add
label define V045012f   9   "9. Refused" , add
label define V045013f   1   "1. Yes" , add
label define V045013f   5   "5. No" , add
label define V045013f   8   "8. Don't know" , add
label define V045013f   9   "9. Refused" , add
label define V045014f   1   "1. Yes" , add
label define V045014f   5   "5. No" , add
label define V045014f   8   "8. Don't know" , add
label define V045014f   9   "9. Refused" , add
label define V045014a   1   "1. Democrats" , add
label define V045014a   3   "3. Republicans" , add
label define V045014a   5   "5. Other {SPECIFY}" , add
label define V045014a   6   "6. Both Democratic candidate and Republican candidate {VOL}" , add
label define V045014a   8   "8. Don't know" , add
label define V045014a   9   "9. Refused" , add
label define V045015f   1   "1. Yes" , add
label define V045015f   5   "5. No" , add
label define V045015f   8   "8. Don't know" , add
label define V045015f   9   "9. Refused" , add
label define V045015a   1   "1. Democrats" , add
label define V045015a   3   "3. Republicans" , add
label define V045015a   5   "5. Other {SPECIFY}" , add
label define V045015a   6   "6. Both Democratics and Republicans" , add
label define V045015a   8   "8. Don't know" , add
label define V045015a   9   "9. Refused" , add
label define V045016f   1   "1. Yes" , add
label define V045016f   5   "5. No" , add
label define V045016f   8   "8. Don't know" , add
label define V045016f   9   "9. Refused" , add
label define V045017a   1   "1. Yes, voted" , add
label define V045017a   5   "5. No, didn't vote" , add
label define V045017a   8   "8. Don't know" , add
label define V045017a   9   "9. Refused" , add
label define V045017b   1   "1. I did not vote (in the election this November)." , add
label define V045017b   2   "2. I thought about voting this time, but didn't." , add
label define V045017b   3   "3. I usually vote, but didn't this time." , add
label define V045017b   4   "4. I am sure I voted" , add
label define V045017b   8   "8. Don't know" , add
label define V045017b   9   "9. Refused" , add
label define V045018f   1   "1. Yes" , add
label define V045018f   5   "5. No" , add
label define V045018f   6   "6. VOL:  NOT REQUIRED TO REGISTER IN R'S STATE" , add
label define V045018f   8   "8. Don't know" , add
label define V045018f   9   "9. Refused" , add
label define V045018x   1   "1. R voter" , add
label define V045018x   2   "2. R nonvoter - registered" , add
label define V045018x   3   "3. R nonvoter - not registered" , add
label define V045018x   4   "4. R nonvoter - DK/RF if registered" , add
label define V045018x   5   "5. R nonvoter - not required to register" , add
label define V045018x   6   "6. DK/RF if voter" , add
label define V045019f   1   "1. Yes, registered in preload county" , add
label define V045019f   5   "5. No, registered in other county" , add
label define V045019f   7   "7. R VOLUNTEERS: preload county is incorrect" , add
label define V045019f   8   "8. Don't know" , add
label define V045019f   9   "9. Refused" , add
label define V045019a   88   "88. Don't know" , add
label define V045019a   89   "89. Refused" , add
label define V045019b   88888   "88888. Don't know" , add
label define V045019b   88889   "88889. Refused" , add
label define V045020x   1   "1. Voter registered in preload county" , add
label define V045020x   2   "2. Voter registered outside preload county" , add
label define V045020x   3   "3. Voter- says preload county is incorrect" , add
label define V045020x   4   "4. Voter - registration location is DK/RF" , add
label define V045020x   5   "5. Nonvoter" , add
label define V045021x   1   "1. Yes" , add
label define V045021x   5   "5. No" , add
label define V045022x   1   "1. Yes" , add
label define V045022x   5   "5. No" , add
label define V045022x   7   "7. Not enough information to determine" , add
label define V045023f   1   "1. Election day" , add
label define V045023f   5   "5. Some time before this" , add
label define V045023f   8   "8. Don't know" , add
label define V045023f   9   "9. Refused" , add
label define V045023a   01   "01. Less than one week, 1-6 days" , add
label define V045023a   02   "02. One week; 7 days" , add
label define V045023a   03   "03. 1-2 weeks; 8-14 days" , add
label define V045023a   04   "04. 2-3 weeks; 15-21 days" , add
label define V045023a   05   "05. 3-4 weeks; 22-28 days" , add
label define V045023a   06   "06. One month; 29-31 days" , add
label define V045023a   07   "07. More than one month; 32-60 days" , add
label define V045023a   11   "11. A few days; a couple of days; several days -- NFS" , add
label define V045023a   12   "12. A few weeks; a couple of weeks; several weeks -- NFS;" , add
label define V045023a   87   "87. Other" , add
label define V045023a   88   "88. Don't know" , add
label define V045023a   89   "89. Refused" , add
label define V045024f   1   "1. In person" , add
label define V045024f   5   "5. Absentee ballot" , add
label define V045024f   7   "7. R VOLUNTEERS: BY MAIL {OREGON ONLY}" , add
label define V045024f   8   "8. Don't know" , add
label define V045024f   9   "9. Refused" , add
label define V045025f   1   "1. Yes, voted for President" , add
label define V045025f   5   "5. No, didn't vote for President" , add
label define V045025f   8   "8. Don't know" , add
label define V045025f   9   "9. Refused" , add
label define V045026f   1   "1. John Kerry" , add
label define V045026f   3   "3. George W. Bush" , add
label define V045026f   5   "5. Ralph Nader" , add
label define V045026f   7   "7. Other {SPECIFY}" , add
label define V045026f   8   "8. Don't know" , add
label define V045026f   9   "9. Refused" , add
label define V045026a   1   "1. Strong" , add
label define V045026a   5   "5. Not strong" , add
label define V045026a   8   "8. Don't know" , add
label define V045026a   9   "9. Refused" , add
label define V045027f   01   "01. Knew all along/from the first; always vote for the" , add
label define V045027f   02   "02. Before the convention because of Kerry's/ Bush's/" , add
label define V045027f   03   "03. At the time of the Republican convention/ when Bush" , add
label define V045027f   04   "04. During the Democratic convention when Kerry was" , add
label define V045027f   05   "05. After the convention(s); during the campaign (NFS);" , add
label define V045027f   06   "06. Five to seven weeks before the election" , add
label define V045027f   07   "07. One month; three weeks; October; after the" , add
label define V045027f   08   "08. About two weeks before the election; 'ten days'" , add
label define V045027f   09   "09. In the last few days of the campaign; the last part" , add
label define V045027f   10   "10. On election day" , add
label define V045027f   11   "11. During/after the primaries (not codeable in 02);" , add
label define V045027f   87   "87. Other" , add
label define V045027f   88   "88. Don't know" , add
label define V045027f   89   "89. Refused" , add
label define V045028f   1   "1. Yes" , add
label define V045028f   5   "5. No" , add
label define V045028f   8   "8. Don't know" , add
label define V045028f   9   "9. Refused" , add
label define V045029f   1   "1. John Kerry" , add
label define V045029f   3   "3. George W. Bush" , add
label define V045029f   5   "5. Ralph Nader" , add
label define V045029f   7   "7. Other {SPECIFY}" , add
label define V045029f   8   "8. Don't know" , add
label define V045029f   9   "9. Refused" , add
label define V045029a   1   "1. Strong" , add
label define V045029a   5   "5. Not strong" , add
label define V045029a   8   "8. Don't know" , add
label define V045029a   9   "9. Refused" , add
label define V045030x   1   "1. Voter - in-county" , add
label define V045030x   2   "2. Voter - not in-county" , add
label define V045030x   5   "5. Nonvoter" , add
label define V045030x   7   "7. Washington D.C. in-county" , add
label define V045031x   1  "1. Yes, voted for House of Representatives" , add
label define V045031x   5  "5. No, didn't vote for House of Representatives" , add
label define V045031x   7  "7. OUTSIDE DISTRICT - R VOLUNTEERS: voted in Washington DC" , add
label define V045031x   8   "8. Don't know" , add
label define V045031x   9   "9. Refused" , add
label define V045032x   1   "1. Democratic candidate" , add
label define V045032x   3   "3. Republican candidate" , add
label define V045032x   5   "5. Independent/third party candidate" , add
label define V045032x   7   "7. Other candidate {SPECIFY}" , add
label define V045032x   8   "8. Don't know" , add
label define V045032x   9   "9. Refused" , add
label define V045033x   31   "31. Democratic candidate in open House race" , add
label define V045033x   32   "32. Republican candidate in open House race" , add
label define V045033x   33   "33. Democratic House running incumbent" , add
label define V045033x   34   "34. Republican House running incumbent" , add
label define V045033x   35   "35. Democratic House challenger" , add
label define V045033x   36   "36. Republican House challenger" , add
label define V045033x   37   "37. Independent/3rd party House candidate - nonincumbent" , add
label define V045033x   39   "39. Independent/3rd party House candidate - incumbent" , add
label define V045033x   70   "70. Third party or independent House candidate" , add
label define V045033x   71   "71. Democratic candidate in open House race" , add
label define V045033x   72   "72. Republican candidate in open House race" , add
label define V045033x   73   "73. Democratic House incumbent" , add
label define V045033x   74   "74. Republican House incumbent" , add
label define V045033x   75   "75. Democratic House challenger" , add
label define V045033x   76   "76. Republican House challenger" , add
label define V045033x   81   "81. Democrat - no name given" , add
label define V045033x   82   "82. Republican - no name given" , add
label define V045033x   87   "87. IN COUNTY OF IW: Name not on candidate list;" , add
label define V045033x   88   "88. Don't know" , add
label define V045033x   89   "89. Refused" , add
label define V045034f   1   "1. Yes" , add
label define V045034f   5   "5. No" , add
label define V045034f   7   "7. R VOLUNTEERS: names are not correct for R's district" , add
label define V045034f   8   "8. Don't know" , add
label define V045034f   9   "9. Refused" , add
label define V045034f   0   "0. NA" , add
label define V045035f   1   "1. Democratic candidate" , add
label define V045035f   3   "3. Republican candidate" , add
label define V045035f   5   "5. Independent/third party candidate" , add
label define V045035f   7   "7. Other candidate {SPECIFY}" , add
label define V045035f   8   "8. Don't know" , add
label define V045035f   9   "9. Refused" , add
label define V045035x   31   "31. Democratic candidate in open House race" , add
label define V045035x   32   "32. Republican candidate in open House race" , add
label define V045035x   33   "33. Democratic House running incumbent" , add
label define V045035x   34   "34. Republican House running incumbent" , add
label define V045035x   35   "35. Democratic House challenger" , add
label define V045035x   36   "36. Republican House challenger" , add
label define V045035x   37   "37. Independent/3rd party House candidate - nonincumbent" , add
label define V045035x   39   "39. Independent/3rd party House candidate - incumbent" , add
label define V045035x   87   "87. Name not on candidate list" , add
label define V045035x   88   "88. Don't know" , add
label define V045035x   89   "89. Refused" , add
label define V045036x   1   "1. In-county voter, Senate race in state" , add
label define V045036x   2   "2. In-county voter, no Senate race in state" , add
label define V045036x   3   "3. Out-of-county voter, voted in state with race" , add
label define V045036x   4   "4. Out-of-county voter, voted in state without race" , add
label define V045036x   5   "5. Nonvoter - race in state" , add
label define V045036x   6   "6. Nonvoter - no race in state" , add
label define V045037x   1   "1. Yes, voted for Senate" , add
label define V045037x   5   "5. No, didn't vote for Senate" , add
label define V045037x   8   "8. Don't know" , add
label define V045037x   9   "9. Refused" , add
label define V045038x   1   "1. Democratic candidate" , add
label define V045038x   2   "2. LOUISIANA ONLY: other democratic candidate" , add
label define V045038x   3   "3. Republican candidate" , add
label define V045038x   5   "5. Independent/third party candidate" , add
label define V045038x   7   "7. Other candidate {SPECIFY}" , add
label define V045038x   8   "8. Don't know" , add
label define V045038x   9   "9. Refused" , add
label define V045039x   01   "01. Democratic candidate in open Senate race" , add
label define V045039x   02   "02. Republican candidate in open Senate race" , add
label define V045039x   03   "03. Democratic Senate running incumbent" , add
label define V045039x   04   "04. Republican Senate running incumbent" , add
label define V045039x   05   "05. Democratic Senate challenger" , add
label define V045039x   06   "06. Republican Senate challenger" , add
label define V045039x   07   "07. Independent/3rd-party Senate cand -  nonincumbent" , add
label define V045039x   08   "08. Independent/3rd-party Senate cand  - 2nd nonincument" , add
label define V045039x   09   "09. Independent/3rd-party Senate incumbent" , add
label define V045039x   70   "70. Third party or independent House candidate" , add
label define V045039x   71   "71. Democratic candidate in open House race" , add
label define V045039x   72   "72. Republican candidate in open House race" , add
label define V045039x   73   "73. Democratic House incumbent" , add
label define V045039x   74   "74. Republican House incumbent" , add
label define V045039x   75   "75. Democratic House challenger" , add
label define V045039x   76   "76. Republican House challenger" , add
label define V045039x   81   "81. Democrat - no name given" , add
label define V045039x   82   "82. Republican - no name given" , add
label define V045039x   87   "87. IN COUNTY OF IW: Name not on candidate list;" , add
label define V045039x   88   "88. Don't know" , add
label define V045039x   89   "89. Refused" , add
label define V045040f   1   "1. Yes" , add
label define V045040f   5   "5. No" , add
label define V045040f   8   "8. Don't know" , add
label define V045040f   9   "9. Refused" , add
label define V045041f   1   "1. Democratic candidate" , add
label define V045041f   3   "3. Republican candidate" , add
label define V045041f   5   "5. Independent/third party candidate" , add
label define V045041f   7   "7. Other candidate {SPECIFY}" , add
label define V045041f   8   "8. Don't know" , add
label define V045041f   9   "9. Refused" , add
label define V045041x   01   "01. Democratic candidate in open Senate race" , add
label define V045041x   02   "02. Republican candidate in open Senate race" , add
label define V045041x   03   "03. Democratic Senate running incumbent" , add
label define V045041x   04   "04. Republican Senate running incumbent" , add
label define V045041x   05   "05. Democratic Senate challenger" , add
label define V045041x   06   "06. Republican Senate challenger" , add
label define V045041x   07   "07. Independent/3rd-party Senate cand -  nonincumbent" , add
label define V045041x   08   "08. Independent/3rd-party Senate cand  - 2nd nonincument" , add
label define V045041x   09   "09. Independent/3rd-party Senate incumbent" , add
label define V045041x   87   "87. Name not on candidate list" , add
label define V045041x   88   "88. Don't know" , add
label define V045041x   89   "89. Refused" , add
label define V045043f   777   "777. Don't recognize" , add
label define V045043f   888   "888. Don't know where to rate" , add
label define V045043f   889   "889. Refused" , add
label define V045044f   777   "777. Don't recognize" , add
label define V045044f   888   "888. Don't know where to rate" , add
label define V045044f   889   "889. Refused" , add
label define V045045f   777   "777. Don't recognize" , add
label define V045045f   888   "888. Don't know where to rate" , add
label define V045045f   889   "889. Refused" , add
label define V045046f   777   "777. Don't recognize" , add
label define V045046f   888   "888. Don't know where to rate" , add
label define V045046f   889   "889. Refused" , add
label define V045047f   777   "777. Don't recognize" , add
label define V045047f   888   "888. Don't know where to rate" , add
label define V045047f   889   "889. Refused" , add
label define V045048f   777   "777. Don't recognize" , add
label define V045048f   888   "888. Don't know where to rate" , add
label define V045048f   889   "889. Refused" , add
label define V045049f   777   "777. Don't recognize" , add
label define V045049f   888   "888. Don't know where to rate" , add
label define V045049f   889   "889. Refused" , add
label define V045050f   777   "777. Don't recognize" , add
label define V045050f   888   "888. Don't know where to rate" , add
label define V045050f   889   "889. Refused" , add
label define V045051f   777   "777. Don't recognize" , add
label define V045051f   888   "888. Don't know where to rate" , add
label define V045051f   889   "889. Refused" , add
label define V045052f   777   "777. Don't recognize" , add
label define V045052f   888   "888. Don't know where to rate" , add
label define V045052f   889   "889. Refused" , add
label define V045053f   777   "777. Don't recognize" , add
label define V045053f   888   "888. Don't know where to rate" , add
label define V045053f   889   "889. Refused" , add
label define V045054f   777   "777. Don't recognize" , add
label define V045054f   888   "888. Don't know where to rate" , add
label define V045054f   889   "889. Refused" , add
label define V045055f   777   "777. Don't recognize" , add
label define V045055f   888   "888. Don't know where to rate" , add
label define V045055f   889   "889. Refused" , add
label define V045056f   777   "777. Don't recognize" , add
label define V045056f   888   "888. Don't know where to rate" , add
label define V045056f   889   "889. Refused" , add
label define V045057f   777   "777. Don't recognize" , add
label define V045057f   888   "888. Don't know where to rate" , add
label define V045057f   889   "889. Refused" , add
label define V045058f   777   "777. Don't recognize" , add
label define V045058f   888   "888. Don't know where to rate" , add
label define V045058f   889   "889. Refused" , add
label define V045059f   777   "777. Don't recognize" , add
label define V045059f   888   "888. Don't know where to rate" , add
label define V045059f   889   "889. Refused" , add
label define V045060f   777   "777. Don't recognize" , add
label define V045060f   888   "888. Don't know where to rate" , add
label define V045060f   889   "889. Refused" , add
label define V045061f   777   "777. Don't recognize" , add
label define V045061f   888   "888. Don't know where to rate" , add
label define V045061f   889   "889. Refused" , add
label define V045062f   777   "777. Don't recognize" , add
label define V045062f   888   "888. Don't know where to rate" , add
label define V045062f   889   "889. Refused" , add
label define V045063f   777   "777. Don't recognize" , add
label define V045063f   888   "888. Don't know where to rate" , add
label define V045063f   889   "889. Refused" , add
label define V045064f   777   "777. Don't recognize" , add
label define V045064f   888   "888. Don't know where to rate" , add
label define V045064f   889   "889. Refused" , add
label define V045065f   777   "777. Don't recognize" , add
label define V045065f   888   "888. Don't know where to rate" , add
label define V045065f   889   "889. Refused" , add
label define V045066f   777   "777. Don't recognize" , add
label define V045066f   888   "888. Don't know where to rate" , add
label define V045066f   889   "889. Refused" , add
label define V045067f   777   "777. Don't recognize" , add
label define V045067f   888   "888. Don't know where to rate" , add
label define V045067f   889   "889. Refused" , add
label define V045068f   777   "777. Don't recognize" , add
label define V045068f   888   "888. Don't know where to rate" , add
label define V045068f   889   "889. Refused" , add
label define V045069f   777   "777. Don't recognize" , add
label define V045069f   888   "888. Don't know where to rate" , add
label define V045069f   889   "889. Refused" , add
label define V045070f   777   "777. Don't recognize" , add
label define V045070f   888   "888. Don't know where to rate" , add
label define V045070f   889   "889. Refused" , add
label define V045071f   777   "777. Don't recognize" , add
label define V045071f   888   "888. Don't know where to rate" , add
label define V045071f   889   "889. Refused" , add
label define V045072f   777   "777. Don't recognize" , add
label define V045072f   888   "888. Don't know where to rate" , add
label define V045072f   889   "889. Refused" , add
label define V045073f   777   "777. Don't recognize" , add
label define V045073f   888   "888. Don't know where to rate" , add
label define V045073f   889   "889. Refused" , add
label define V045074f   777   "777. Don't recognize" , add
label define V045074f   888   "888. Don't know where to rate" , add
label define V045074f   889   "889. Refused" , add
label define V045075f   777   "777. Don't recognize" , add
label define V045075f   888   "888. Don't know where to rate" , add
label define V045075f   889   "889. Refused" , add
label define V045076f   777   "777. Don't recognize" , add
label define V045076f   888   "888. Don't know where to rate" , add
label define V045076f   889   "889. Refused" , add
label define V045077f   777   "777. Don't recognize" , add
label define V045077f   888   "888. Don't know where to rate" , add
label define V045077f   889   "889. Refused" , add
label define V045078f   777   "777. Don't recognize" , add
label define V045078f   888   "888. Don't know where to rate" , add
label define V045078f   889   "889. Refused" , add
label define V045079f   777   "777. Don't recognize" , add
label define V045079f   888   "888. Don't know where to rate" , add
label define V045079f   889   "889. Refused" , add
label define V045080f   777   "777. Don't recognize" , add
label define V045080f   888   "888. Don't know where to rate" , add
label define V045080f   889   "889. Refused" , add
label define V045081f   777   "777. Don't recognize" , add
label define V045081f   888   "888. Don't know where to rate" , add
label define V045081f   889   "889. Refused" , add
label define V045082f   777   "777. Don't recognize" , add
label define V045082f   888   "888. Don't know where to rate" , add
label define V045082f   889   "889. Refused" , add
label define V045083f   777   "777. Don't recognize" , add
label define V045083f   888   "888. Don't know where to rate" , add
label define V045083f   889   "889. Refused" , add
label define V045084f   777   "777. Don't recognize" , add
label define V045084f   888   "888. Don't know where to rate" , add
label define V045084f   889   "889. Refused" , add
label define V045085f   777   "777. Don't recognize" , add
label define V045085f   888   "888. Don't know where to rate" , add
label define V045085f   889   "889. Refused" , add
label define V045086f   777   "777. Don't recognize" , add
label define V045086f   888   "888. Don't know where to rate" , add
label define V045086f   889   "889. Refused" , add
label define V045087f   777   "777. Don't recognize" , add
label define V045087f   888   "888. Don't know where to rate" , add
label define V045087f   889   "889. Refused" , add
label define V045088f   777   "777. Don't recognize" , add
label define V045088f   888   "888. Don't know where to rate" , add
label define V045088f   889   "889. Refused" , add
label define V045089f   1   "1. The Democrats" , add
label define V045089f   5   "5. The Republicans" , add
label define V045089f   8   "8. Don't know" , add
label define V045089f   9   "9. Refused" , add
label define V045090f   1   "1. The Democrats" , add
label define V045090f   5   "5. The Republicans" , add
label define V045090f   8   "8. Don't know" , add
label define V045090f   9   "9. Refused" , add
label define V045091f   1   "1. Democratic running incumbent" , add
label define V045091f   2   "2. Republican running incumbent" , add
label define V045091f   3   "3. Other running incumbent" , add
label define V045091f   4   "4. Democratic retiring incumbent" , add
label define V045091f   5   "5. Republican retiring incumbent" , add
label define V045091f   6   "6. Other retiring incumbent" , add
label define V045091f   7   "7. No identifiable incumbent or Washington DC" , add
label define V045092f   1   "1. Approve" , add
label define V045092f   5   "5. Disapprove" , add
label define V045092f   8   "8. Don't know" , add
label define V045092f   9   "9. Refused" , add
label define V045092a   1   "1. Approve strongly" , add
label define V045092a   2   "2. Approve not strongly" , add
label define V045092a   4   "4. Disapprove not strongly" , add
label define V045092a   5   "5. Disapprove strongly" , add
label define V045092a   8   "8. Don't know" , add
label define V045092a   9   "9. Refused" , add
label define V045093f   1   "1. More than half" , add
label define V045093f   2   "2. Half" , add
label define V045093f   3   "3. Less than half" , add
label define V045093f   7   "7. Don't know; not sure" , add
label define V045093f   9   "9. Refused" , add
label define V045093f   0   "0. No running House incumbent" , add
label define V045094f   1   "1. Very good" , add
label define V045094f   2   "2. Fairly good" , add
label define V045094f   3   "3. Fairly poor" , add
label define V045094f   4   "4. Very poor" , add
label define V045094f   8   "8. Don't know" , add
label define V045094f   9   "9. Refused" , add
label define V045095f   1   "1. Most of the time" , add
label define V045095f   2   "2. Some of the time" , add
label define V045095f   3   "3. Only now and then" , add
label define V045095f   4   "4. Hardly at all" , add
label define V045095f   8   "8. Don't know" , add
label define V045095f   9   "9. Refused" , add
label define V045096f   1   "1. Yes, favor" , add
label define V045096f   5   "5. No, don't favor" , add
label define V045096f   8   "8. Don't know" , add
label define V045096f   9   "9. Refused" , add
label define V045097f   1   "1. Yes, favor" , add
label define V045097f   5   "5. No, don't favor" , add
label define V045097f   8   "8. Don't know" , add
label define V045097f   9   "9. Refused" , add
label define V045098f   1   "1. Yes, favor" , add
label define V045098f   5   "5. No, don't favor" , add
label define V045098f   8   "8. Don't know" , add
label define V045098f   9   "9. Refused" , add
label define V045099f   1   "1. Very important" , add
label define V045099f   3   "3. Somewhat important" , add
label define V045099f   5   "5. Not important at all" , add
label define V045099f   8   "8. Don't know" , add
label define V045099f   9   "9. Refused" , add
label define V045100f   1   "1. Very important" , add
label define V045100f   3   "3. Somewhat important" , add
label define V045100f   5   "5. Not important at all" , add
label define V045100f   8   "8. Don't know" , add
label define V045100f   9   "9. Refused" , add
label define V045101f   1   "1. Very important" , add
label define V045101f   3   "3. Somewhat important" , add
label define V045101f   5   "5. Not important at all" , add
label define V045101f   8   "8. Don't know" , add
label define V045101f   9   "9. Refused" , add
label define V045102f   1   "1. Very important" , add
label define V045102f   3   "3. Somewhat important" , add
label define V045102f   5   "5. Not important at all" , add
label define V045102f   8   "8. Don't know" , add
label define V045102f   9   "9. Refused" , add
label define V045103f   1   "1. Very important" , add
label define V045103f   3   "3. Somewhat important" , add
label define V045103f   5   "5. Not important at all" , add
label define V045103f   8   "8. Don't know" , add
label define V045103f   9   "9. Refused" , add
label define V045104f   1   "1. Very important" , add
label define V045104f   3   "3. Somewhat important" , add
label define V045104f   5   "5. Not important at all" , add
label define V045104f   8   "8. Don't know" , add
label define V045104f   9   "9. Refused" , add
label define V045105f   1   "1. Very important" , add
label define V045105f   3   "3. Somewhat important" , add
label define V045105f   5   "5. Not important at all" , add
label define V045105f   8   "8. Don't know" , add
label define V045105f   9   "9. Refused" , add
label define V045106f   1   "1. Very important" , add
label define V045106f   3   "3. Somewhat important" , add
label define V045106f   5   "5. Not important at all" , add
label define V045106f   8   "8. Don't know" , add
label define V045106f   9   "9. Refused" , add
label define V045107f   1   "1. Very important" , add
label define V045107f   3   "3. Somewhat important" , add
label define V045107f   5   "5. Not important at all" , add
label define V045107f   8   "8. Don't know" , add
label define V045107f   9   "9. Refused" , add
label define V045108f   1   "1. Extremely important" , add
label define V045108f   2   "2. Very important" , add
label define V045108f   3   "3. Somewhat important" , add
label define V045108f   4   "4. Not at all important" , add
label define V045108f   8   "8. Don't know" , add
label define V045108f   9   "9. Refused" , add
label define V045109f   1   "1. Yes, have interest in question" , add
label define V045109f   5   "5. No, haven't had interest" , add
label define V045109f   8   "8. Don't know" , add
label define V045109f   9   "9. Refused" , add
label define V045109a   1   "1. Government in Washington should see to it that" , add
label define V045109a   5   "5. This is not the Federal government's business" , add
label define V045109a   7   "7. Other {SPECIFY}" , add
label define V045109a   8   "8. Don't know" , add
label define V045109a   9   "9. Refused" , add
label define V045109b   1   "1. Feel govt should see to jobs - strongly" , add
label define V045109b   2   "2. Feel govt should see to jobs - not strongly" , add
label define V045109b   4   "4. Feel not govt business - not strongly" , add
label define V045109b   5   "5. Feel not govt business - strongly" , add
label define V045109b   8   "8. Don't know" , add
label define V045109b   9   "9. Refused" , add
label define V045110f   1   "1. Yes, favor" , add
label define V045110f   5   "5. No, don't favor" , add
label define V045110f   8   "8. Don't know" , add
label define V045110f   9   "9. Refused" , add
label define V045111f   1   "1. Yes, favor" , add
label define V045111f   5   "5. No, don't favor" , add
label define V045111f   8   "8. Don't know" , add
label define V045111f   9   "9. Refused" , add
label define V045112f   1   "1. Yes, favor" , add
label define V045112f   5   "5. No, don't favor" , add
label define V045112f   8   "8. Don't know" , add
label define V045112f   9   "9. Refused" , add
label define V045113f   1   "1. Larger" , add
label define V045113f   3   "3. Smaller" , add
label define V045113f   5   "5. About the same" , add
label define V045113f   8   "8. Don't know" , add
label define V045113f   9   "9. Refused" , add
label define V045113a   1   "1. Much larger" , add
label define V045113a   2   "2. Somewhat larger" , add
label define V045113a   3   "3. About the same" , add
label define V045113a   4   "4. Somewhat smaller" , add
label define V045113a   5   "5. Much smaller" , add
label define V045113a   8   "8. Don't know" , add
label define V045113a   9   "9. Refused" , add
label define V045113b   1   "1. Good thing" , add
label define V045113b   3   "3. Bad thing" , add
label define V045113b   7   "7. Haven't thought" , add
label define V045113b   8   "8. Don't know" , add
label define V045113b   9   "9. Refused" , add
label define V045114f   1   "1. Favor" , add
label define V045114f   5   "5. Oppose" , add
label define V045114f   7   "7. Haven't thought much about this" , add
label define V045114f   8   "8. Don't know" , add
label define V045114f   9   "9. Refused" , add
label define V045115f   1   "1. Increased a lot" , add
label define V045115f   2   "2. Increased a little" , add
label define V045115f   3   "3. Left the same as it is now" , add
label define V045115f   4   "4. Decreased a little" , add
label define V045115f   5   "5. Decreased a lot" , add
label define V045115f   8   "8. Don't know" , add
label define V045115f   9   "9. Refused" , add
label define V045116f   1   "1. Extremely likely" , add
label define V045116f   2   "2. Very likely" , add
label define V045116f   3   "3. Somewhat likely" , add
label define V045116f   4   "4. Not at all likely" , add
label define V045116f   8   "8. Don't know" , add
label define V045116f   9   "9. Refused" , add
label define V045117f   01   "01. Extremely liberal" , add
label define V045117f   02   "02. Liberal" , add
label define V045117f   03   "03. Slightly liberal" , add
label define V045117f   04   "04. Moderate; middle of the road" , add
label define V045117f   05   "05. Slightly conservative" , add
label define V045117f   06   "06. Conservative" , add
label define V045117f   07   "07. Extremely conservative" , add
label define V045117f   80   "80. Haven't thought much {DO NOT PROBE}" , add
label define V045117f   88   "88. Don't know" , add
label define V045117f   89   "89. Refused" , add
label define V045117a   1   "1. Liberal" , add
label define V045117a   3   "3. Conservative" , add
label define V045117a   5   "5. Moderate" , add
label define V045117a   7   "7. R Refused to choose" , add
label define V045117a   8   "8. Don't know" , add
label define V045118f   1   "1. Liberal" , add
label define V045118f   3   "3. Conservative" , add
label define V045118f   5   "5. Moderate" , add
label define V045118f   7   "7. R Refused to choose" , add
label define V045118f   8   "8. Don't know" , add
label define V045119f   1   "1. Extremely liberal" , add
label define V045119f   2   "2. Liberal" , add
label define V045119f   3   "3. Slightly liberal" , add
label define V045119f   4   "4. Moderate; middle of the road" , add
label define V045119f   5   "5. Slightly conservative" , add
label define V045119f   6   "6. Conservative" , add
label define V045119f   7   "7. Extremely conservative" , add
label define V045119f   8   "8. Don't know" , add
label define V045119f   9   "9. Refused" , add
label define V045119f   0   "0. NA" , add
label define V045120f   1   "1. Extremely liberal" , add
label define V045120f   2   "2. Liberal" , add
label define V045120f   3   "3. Slightly liberal" , add
label define V045120f   4   "4. Moderate; middle of the road" , add
label define V045120f   5   "5. Slightly conservative" , add
label define V045120f   6   "6. Conservative" , add
label define V045120f   7   "7. Extremely conservative" , add
label define V045120f   8   "8. Don't know" , add
label define V045120f   9   "9. Refused" , add
label define V045121f   01   "01. Govt should provide many fewer services" , add
label define V045121f   07   "07. Govt should provide many more services" , add
label define V045121f   80   "80. Haven't thought much about this" , add
label define V045121f   88   "88. Don't know" , add
label define V045121f   89   "89. Refused" , add
label define V045122f   1   "1. Govt should provide many fewer services" , add
label define V045122f   7   "7. Govt should provide many more services" , add
label define V045122f   8   "8. Don't know" , add
label define V045122f   9   "9. Refused" , add
label define V045122f   0   "0. NA" , add
label define V045123f   1   "1. Govt should provide many fewer services" , add
label define V045123f   7   "7. Govt should provide many more services" , add
label define V045123f   8   "8. Don't know" , add
label define V045123f   9   "9. Refused" , add
label define V045124f   01   "01. Should solve with diplomacy" , add
label define V045124f   07   "07. Must be ready to use military force" , add
label define V045124f   80   "80. Haven't thought much about this" , add
label define V045124f   88   "88. Don't know" , add
label define V045124f   89   "89. Refused" , add
label define V045125f   1   "1. Extremely important" , add
label define V045125f   2   "2. Very important" , add
label define V045125f   3   "3. Somewhat important" , add
label define V045125f   4   "4. Not too important" , add
label define V045125f   5   "5. Not at all important" , add
label define V045125f   8   "8. Don't know" , add
label define V045125f   9   "9. Refused" , add
label define V045126f   1   "1. Should solve with diplomacy" , add
label define V045126f   7   "7. Must be ready to use military force" , add
label define V045126f   8   "8. Don't know" , add
label define V045126f   9   "9. Refused" , add
label define V045127f   1   "1. Should solve with diplomacy" , add
label define V045127f   7   "7. Must be ready to use military force" , add
label define V045127f   8   "8. Don't know" , add
label define V045127f   9   "9. Refused" , add
label define V045128f   1   "1. Should solve with diplomacy" , add
label define V045128f   7   "7. Must be ready to use military force" , add
label define V045128f   8   "8. Don't know" , add
label define V045128f   9   "9. Refused" , add
label define V045128f   0   "0. NA" , add
label define V045129f   1   "1. Should solve with diplomacy" , add
label define V045129f   7   "7. Must be ready to use military force" , add
label define V045129f   8   "8. Don't know" , add
label define V045129f   9   "9. Refused" , add
label define V045130f   1   "1. Should solve with diplomacy" , add
label define V045130f   7   "7. Must be ready to use military force" , add
label define V045130f   8   "8. Don't know" , add
label define V045130f   9   "9. Refused" , add
label define V045131f   1   "1. Should solve with diplomacy" , add
label define V045131f   7   "7. Must be ready to use military force" , add
label define V045131f   8   "8. Don't know" , add
label define V045131f   9   "9. Refused" , add
label define V045132f   1   "1. By law, abortion should never be permitted" , add
label define V045132f   2   "2. The law should permit abortion only in case of rape, inces" , add
label define V045132f   3   "3. The law should permit abortion for reasons other than rape" , add
label define V045132f   4   "4. By law, a woman should always be able to obtain an abortio" , add
label define V045132f   7   "7. Other {SPECIFY} {VOL}" , add
label define V045132f   8   "8. Don't know" , add
label define V045132f   9   "9. Refused" , add
label define V045133f   1   "1. Extremely important" , add
label define V045133f   2   "2. Very important" , add
label define V045133f   3   "3. Somewhat important" , add
label define V045133f   4   "4. Not too important" , add
label define V045133f   5   "5. Not at all important" , add
label define V045133f   8   "8. Don't know" , add
label define V045133f   9   "9. Refused" , add
label define V045134f   1   "1. By law, abortion should never be permitted" , add
label define V045134f   2   "2. The law should permit abortion only in case of rape, inces" , add
label define V045134f   3   "3. The law should permit abortion for reasons other than rape" , add
label define V045134f   4   "4. By law, a woman should always be able to obtain an abortio" , add
label define V045134f   7   "7. Other {SPECIFY} {VOL}" , add
label define V045134f   8   "8. Don't know" , add
label define V045134f   9   "9. Refused" , add
label define V045135f   1   "1. By law, abortion should never be permitted" , add
label define V045135f   2   "2. The law should permit abortion only in case of rape, inces" , add
label define V045135f   3   "3. The law should permit abortion for reasons other than rape" , add
label define V045135f   4   "4. By law, a woman should always be able to obtain an abortio" , add
label define V045135f   7   "7. Other {SPECIFY} {VOL}" , add
label define V045135f   8   "8. Don't know" , add
label define V045135f   9   "9. Refused" , add
label define V045136f   1   "1. By law, abortion should never be permitted" , add
label define V045136f   2   "2. The law should permit abortion only in case of rape, inces" , add
label define V045136f   3   "3. The law should permit abortion for reasons other than rape" , add
label define V045136f   4   "4. By law, a woman should always be able to obtain an abortio" , add
label define V045136f   7   "7. Other {SPECIFY} {VOL}" , add
label define V045136f   8   "8. Don't know" , add
label define V045136f   9   "9. Refused" , add
label define V045136f   0   "0. NA" , add
label define V045137f   1   "1. By law, abortion should never be permitted" , add
label define V045137f   2   "2. The law should permit abortion only in case of rape, inces" , add
label define V045137f   3   "3. The law should permit abortion for reasons other than rape" , add
label define V045137f   4   "4. By law, a woman should always be able to obtain an abortio" , add
label define V045137f   7   "7. Other {SPECIFY} {VOL}" , add
label define V045137f   8   "8. Don't know" , add
label define V045137f   9   "9. Refused" , add
label define V045138f   1   "1. By law, abortion should never be permitted" , add
label define V045138f   2   "2. The law should permit abortion only in case of rape, inces" , add
label define V045138f   3   "3. The law should permit abortion for reasons other than rape" , add
label define V045138f   4   "4. By law, a woman should always be able to obtain an abortio" , add
label define V045138f   7   "7. Other {SPECIFY} {VOL}" , add
label define V045138f   8   "8. Don't know" , add
label define V045138f   9   "9. Refused" , add
label define V045139f   1   "1. By law, abortion should never be permitted" , add
label define V045139f   2   "2. The law should permit abortion only in case of rape, inces" , add
label define V045139f   3   "3. The law should permit abortion for reasons other than rape" , add
label define V045139f   4   "4. By law, a woman should always be able to obtain an abortio" , add
label define V045139f   7   "7. Other {SPECIFY} {VOL}" , add
label define V045139f   8   "8. Don't know" , add
label define V045139f   9   "9. Refused" , add
label define V045140f   01   "01. Govt should help Hispanics" , add
label define V045140f   07   "07. Should help themselves" , add
label define V045140f   80   "80. Haven't thought much about it" , add
label define V045140f   88   "88. Don't know" , add
label define V045140f   89   "89. Refused" , add
label define V045141f   1   "1. Extremely important" , add
label define V045141f   2   "2. Very important" , add
label define V045141f   3   "3. Somewhat important" , add
label define V045141f   4   "4. Not too important" , add
label define V045141f   5   "5. Not at all important" , add
label define V045141f   8   "8. Don't know" , add
label define V045141f   9   "9. Refused" , add
label define V045142f   1   "1. Discourage companies" , add
label define V045142f   3   "3. Encourage companies" , add
label define V045142f   5   "5. Should stay out of this matter" , add
label define V045142f   8   "8. Don't know" , add
label define V045142f   9   "9. Refused" , add
label define V045142a   1   "1. A great deal" , add
label define V045142a   5   "5. Only a little" , add
label define V045142a   8   "8. Don't know" , add
label define V045142a   9   "9. Refused" , add
label define V045143f   1   "1. Favor" , add
label define V045143f   5   "5. Oppose" , add
label define V045143f   7   "7. Neither favor nor oppose" , add
label define V045143f   8   "8. Don't know" , add
label define V045143f   9   "9. Refused" , add
label define V045143a   1   "1. Favor strongly" , add
label define V045143a   2   "2. Favor not strongly" , add
label define V045143a   4   "4. Oppose not strongly" , add
label define V045143a   5   "5. Oppose strongly " , add
label define V045143a   8   "8. Don't know" , add
label define V045143a   9   "9. Refused" , add
label define V045143b   1   "1. Favor strongly" , add
label define V045143b   2   "2. Favor not strongly" , add
label define V045143b   3   "3. Lead toward favoring" , add
label define V045143b   4   "4. Don't lean either way" , add
label define V045143b   5   "5. Lean toward opposing" , add
label define V045143b   6   "6. Oppose not strongly" , add
label define V045143b   7   "7. Oppose strongly" , add
label define V045143b   8   "8. Don't know" , add
label define V045143b   9   "9. Refused" , add
label define V045144f   1   "1. Favor" , add
label define V045144f   5   "5. Oppose" , add
label define V045144f   7   "7. Neither/depends/other {VOL} {SPECIFY}" , add
label define V045144f   8   "8. Don't know" , add
label define V045144f   9   "9. Refused" , add
label define V045144a   1   "1. Favor strongly" , add
label define V045144a   2   "2. Favor not strongly" , add
label define V045144a   4   "4. Oppose not strongly" , add
label define V045144a   5   "5. Oppose strongly " , add
label define V045144a   8   "8. Don't know" , add
label define V045144a   9   "9. Refused" , add
label define V045145f   1   "1. Extremely good" , add
label define V045145f   2   "2. Very good" , add
label define V045145f   3   "3. Somewhat good" , add
label define V045145f   4   "4. Not very good" , add
label define V045145f   7   "7. Don't feel anything {VOL}" , add
label define V045145f   8   "8. Don't know" , add
label define V045145f   9   "9. Refused" , add
label define V045145x   1   "1. Extremely good" , add
label define V045145x   2   "2. Very good" , add
label define V045145x   3   "3. Somewhat good" , add
label define V045145x   4   "4. Not very good" , add
label define V045145x   7   "7. Don't feel anything {VOL}" , add
label define V045145x   8   "8. Don't know" , add
label define V045145x   9   "9. Refused" , add
label define V045146f   1   "1. Agree" , add
label define V045146f   3   "3. Neither agree nor disagree" , add
label define V045146f   5   "5. Disagree" , add
label define V045146f   8   "8. Don't know" , add
label define V045146f   9   "9. Refused" , add
label define V045146x   1   "1. Agree" , add
label define V045146x   3   "3. Neither agree nor disagree" , add
label define V045146x   5   "5. Disagree" , add
label define V045146x   8   "8. Don't know" , add
label define V045146x   9   "9. Refused" , add
label define V045147f   1   "1. Agree" , add
label define V045147f   3   "3. Neither agree nor disagree" , add
label define V045147f   5   "5. Disagree" , add
label define V045147f   8   "8. Don't know" , add
label define V045147f   9   "9. Refused" , add
label define V045147x   1   "1. Agree" , add
label define V045147x   3   "3. Neither agree nor disagree" , add
label define V045147x   5   "5. Disagree" , add
label define V045147x   8   "8. Don't know" , add
label define V045147x   9   "9. Refused" , add
label define V045148f   1   "1. Extremely strong" , add
label define V045148f   2   "2. Very strong" , add
label define V045148f   4   "4. Somewhat strong" , add
label define V045148f   5   "5. Not Very strong" , add
label define V045148f   8   "8. Don't know" , add
label define V045148f   9   "9. Refused" , add
label define V045148x   1   "1. Extremely strong" , add
label define V045148x   2   "2. Very strong" , add
label define V045148x   4   "4. Somewhat strong" , add
label define V045148x   5   "5. Not Very strong" , add
label define V045148x   8   "8. Don't know" , add
label define V045148x   9   "9. Refused" , add
label define V045149f   1   "1. Extremely important" , add
label define V045149f   2   "2. Very important" , add
label define V045149f   3   "3. Somewhat important" , add
label define V045149f   4   "4. Not too important" , add
label define V045149f   5   "5. Not at all important" , add
label define V045149f   8   "8. Don't know" , add
label define V045149f   9   "9. Refused" , add
label define V045149x   1   "1. Extremely important" , add
label define V045149x   2   "2. Very important" , add
label define V045149x   3   "3. Somewhat important" , add
label define V045149x   4   "4. Not too important" , add
label define V045149x   5   "5. Not at all important" , add
label define V045149x   8   "8. Don't know" , add
label define V045149x   9   "9. Refused" , add
label define V045150f   1   "1. Gov't bigger because it's involved in things people sho" , add
label define V045150f   2   "2. Gov't bigger because problems bigger" , add
label define V045150f   8   "8. Don't know" , add
label define V045150f   9   "9. Refused" , add
label define V045151f   1   "1. Need a strong gov't to handle complex economic problems" , add
label define V045151f   2   "2. Free market can handle without gov't involvement" , add
label define V045151f   8   "8. Don't know" , add
label define V045151f   9   "9. Refused" , add
label define V045152f   1   "1. The less government the better" , add
label define V045152f   2   "2. More things government should be doing" , add
label define V045152f   8   "8. Don't know" , add
label define V045152f   9   "9. Refused" , add
label define V045153f   1   "1. Yes" , add
label define V045153f   5   "5. No" , add
label define V045153f   8   "8. Don't know" , add
label define V045153f   9   "9. Refused" , add
label define V045153a   88   "88. Don't know" , add
label define V045153a   89   "89. Refused" , add
label define V045154f   1   "1. Yes, listen" , add
label define V045154f   5   "5. No, don't listen" , add
label define V045154f   8   "8. Don't know" , add
label define V045154f   9   "9. Refused" , add
label define V045155f   1   "1. Yes" , add
label define V045155f   5   "5. No" , add
label define V045155f   8   "8. Don't know" , add
label define V045155f   9   "9. Refused" , add
label define V045155a   1   "1. Yes" , add
label define V045155a   5   "5. No" , add
label define V045155a   8   "8. Don't know" , add
label define V045155a   9   "9. Refused" , add
label define V045156f   1   "1. Favor" , add
label define V045156f   5   "5. Oppose" , add
label define V045156f   8   "8. Don't know" , add
label define V045156f   9   "9. Refused" , add
label define V045156a   1   "1. Favor strongly" , add
label define V045156a   2   "2. Favor not strongly" , add
label define V045156a   4   "4. Oppose not strongly" , add
label define V045156a   5   "5. Oppose strongly " , add
label define V045156a   8   "8. Don't know" , add
label define V045156a   9   "9. Refused" , add
label define V045157f   1   "1. Homosexuals should be allowed to serve" , add
label define V045157f   5   "5. Homosexuals should not be allowed to serve" , add
label define V045157f   8   "8. Don't know" , add
label define V045157f   9   "9. Refused" , add
label define V045157a   1   "1. Feel homosexuals should be allowed - strongly" , add
label define V045157a   2   "2. Feel homosexuals should be allowed - not strongly" , add
label define V045157a   4   "4. Feel homosexuals should not be allowed - not strongly" , add
label define V045157a   5   "5. Feel homosexuals should not be allowed - strongly" , add
label define V045157a   8   "8. Don't know" , add
label define V045157a   9   "9. Refused" , add
label define V045158f   1   "1. Yes" , add
label define V045158f   5   "5. No" , add
label define V045158f   8   "8. Don't know" , add
label define V045158f   9   "9. Refused" , add
label define V045159f   1   "1. Yes, differences" , add
label define V045159f   5   "5. No, no differences" , add
label define V045159f   8   "8. Don't know" , add
label define V045159f   9   "9. Refused" , add
label define V045160f   1   "1. Yes" , add
label define V045160f   5   "5. No" , add
label define V045160f   8   "8. Don't know" , add
label define V045160f   9   "9. Refused" , add
label define V045160a   1   "1. Democrats" , add
label define V045160a   5   "5. Republicans" , add
label define V045160a   8   "8. Don't know" , add
label define V045160a   9   "9. Refused" , add
label define V045161f   1   "1. Yes, have interest" , add
label define V045161f   5   "5. No, don't have interest" , add
label define V045161f   8   "8. Don't know" , add
label define V045161f   9   "9. Refused" , add
label define V045161a   1   "1. Govt should see to it" , add
label define V045161a   5   "5. Not the Federal govt's business" , add
label define V045161a   7   "7. Other {SPECIFY}" , add
label define V045161a   8   "8. Don't know" , add
label define V045161a   9   "9. Refused" , add
label define V045161b   1   "1. Feel govt should see to jobs - strongly" , add
label define V045161b   2   "2. Feel govt should see to jobs - not strongly" , add
label define V045161b   4   "4. Feel not govt business - not strongly" , add
label define V045161b   5   "5. Feel not govt business - strongly" , add
label define V045161b   8   "8. Don't know" , add
label define V045161b   9   "9. Refused" , add
label define V045162f   1   "1. Correctly identifies as Speaker of the House" , add
label define V045162f   5   "5. Identification is incomplete or wrong" , add
label define V045162f   8   "8. R makes no attempt to guess" , add
label define V045162f   9   "9. Refused" , add
label define V045162a   1   "1. Yes" , add
label define V045162a   5   "5. No" , add
label define V045163f   1   "1. Correctly identifies as Vice_President of the U.S." , add
label define V045163f   5   "5. Identification is incomplete or wrong" , add
label define V045163f   8   "8. R makes no attempt to guess" , add
label define V045163f   9   "9. Refused" , add
label define V045163a   1   "1. Yes" , add
label define V045163a   5   "5. No" , add
label define V045164f   1   "1. Correctly identifies as Prime Minister of England/" , add
label define V045164f   5   "5. Identification is incomplete or wrong" , add
label define V045164f   8   "8. R makes no attempt to guess" , add
label define V045164f   9   "9. Refused" , add
label define V045164a   1   "1. Yes" , add
label define V045164a   5   "5. No" , add
label define V045165f   1   "1. Correctly identifies as Chief Justice of the Supreme" , add
label define V045165f   5   "5. Identification is incomplete or wrong" , add
label define V045165f   8   "8. R makes no attempt to guess" , add
label define V045165f   9   "9. Refused" , add
label define V045165a   1   "1. Yes" , add
label define V045165a   5   "5. No" , add
label define V045166f   1   "1. Yes" , add
label define V045166f   5   "5. No" , add
label define V045166f   8   "8. Don't know" , add
label define V045166f   9   "9. Refused" , add
label define V045167f   1   "1. Yes" , add
label define V045167f   5   "5. No" , add
label define V045167f   8   "8. Don't know" , add
label define V045167f   9   "9. Refused" , add
label define V045168f   1   "1. Yes" , add
label define V045168f   5   "5. No" , add
label define V045168f   8   "8. Don't know" , add
label define V045168f   9   "9. Refused" , add
label define V045169f   1   "1. Yes" , add
label define V045169f   5   "5. No" , add
label define V045169f   8   "8. Don't know" , add
label define V045169f   9   "9. Refused" , add
label define V045170f   1   "1. Yes" , add
label define V045170f   5   "5. No" , add
label define V045170f   8   "8. Don't know" , add
label define V045170f   9   "9. Refused" , add
label define V045170a   0   "0.    No organizations" , add
label define V045170a   1   "1. One organization" , add
label define V045170a   97   "97.   97 or more organizations" , add
label define V045170a   88   "88. Don't know" , add
label define V045170a   89   "89. Refused" , add
label define V045171f   1   "1. Yes" , add
label define V045171f   5   "5. No" , add
label define V045171f   8   "8. Don't know" , add
label define V045171f   9   "9. Refused" , add
label define V045172f   1   "1. Yes" , add
label define V045172f   5   "5. No" , add
label define V045172f   8   "8. Don't know" , add
label define V045172f   9   "9. Refused" , add
label define V045173f   001   "001. Female only" , add
label define V045173f   002   "002. Black only" , add
label define V045173f   003   "003. Hispanic only" , add
label define V045173f   012   "012. Female and black" , add
label define V045173f   013   "013. Female and Hispanic" , add
label define V045173f   023   "023. Black and Hispanic" , add
label define V045173f   123   "123. Female, black and Hispanic" , add
label define V045173f   000   "000. Not female, black or Hispanic" , add
label define V045174f   1   "1. Yes" , add
label define V045174f   5   "5. No" , add
label define V045174f   7   "7. Depends {VOL}" , add
label define V045174f   8   "8. Don't know" , add
label define V045174f   9   "9. Refused" , add
label define V045174f   0   "0. NA" , add
label define V045174a   1   "1. A lot" , add
label define V045174a   3   "3. Some" , add
label define V045174a   5   "5. Not very much at all" , add
label define V045174a   8   "8. Don't know" , add
label define V045174a   9   "9. Refused" , add
label define V045175f   1   "1. A lot" , add
label define V045175f   2   "2. Fairly often" , add
label define V045175f   3   "3. Once in a while" , add
label define V045175f   4   "4. Hardly ever" , add
label define V045175f   8   "8. Don't know" , add
label define V045175f   9   "9. Refused" , add
label define V045175f   0   "0. NA" , add
label define V045176f   1   "1. A lot" , add
label define V045176f   2   "2. Fairly often" , add
label define V045176f   3   "3. Once in a while" , add
label define V045176f   4   "4. Hardly ever" , add
label define V045176f   8   "8. Don't know" , add
label define V045176f   9   "9. Refused" , add
label define V045176f   0   "0. NA" , add
label define V045177f   1   "1. Yes" , add
label define V045177f   5   "5. No" , add
label define V045177f   7   "7. Depends {VOL}" , add
label define V045177f   8   "8. Don't know" , add
label define V045177f   9   "9. Refused" , add
label define V045177f   0   "0. NA" , add
label define V045177a   1   "1. A lot" , add
label define V045177a   3   "3. Some" , add
label define V045177a   5   "5. Not very much at all" , add
label define V045177a   8   "8. Don't know" , add
label define V045177a   9   "9. Refused" , add
label define V045178f   1   "1. A lot" , add
label define V045178f   2   "2. Fairly often" , add
label define V045178f   3   "3. Once in a while" , add
label define V045178f   4   "4. Hardly ever" , add
label define V045178f   8   "8. Don't know" , add
label define V045178f   9   "9. Refused" , add
label define V045178f   0   "0. NA" , add
label define V045179f   1   "1. A lot" , add
label define V045179f   2   "2. Fairly often" , add
label define V045179f   3   "3. Once in a while" , add
label define V045179f   4   "4. Hardly ever" , add
label define V045179f   8   "8. Don't know" , add
label define V045179f   9   "9. Refused" , add
label define V045179f   0   "0. NA" , add 
label define V045180f   1   "1. Yes" , add
label define V045180f   5   "5. No" , add
label define V045180f   7   "7. Depends {VOL}" , add
label define V045180f   8   "8. Don't know" , add
label define V045180f   9   "9. Refused" , add
label define V045180f   0   "0. NA" , add
label define V045180a   1   "1. A lot" , add
label define V045180a   3   "3. Some" , add
label define V045180a   5   "5. Not very much at all" , add
label define V045180a   8   "8. Don't know" , add
label define V045180a   9   "9. Refused" , add
label define V045181f   1   "1. A lot" , add
label define V045181f   2   "2. Fairly often" , add
label define V045181f   3   "3. Once in a while" , add
label define V045181f   4   "4. Hardly ever" , add
label define V045181f   8   "8. Don't know" , add
label define V045181f   9   "9. Refused" , add
label define V045181f   0   "0. NA" , add
label define V045182f   1   "1. A lot" , add
label define V045182f   2   "2. Fairly often" , add
label define V045182f   3   "3. Once in a while" , add
label define V045182f   4   "4. Hardly ever" , add
label define V045182f   8   "8. Don't know" , add
label define V045182f   9   "9. Refused" , add
label define V045182f   0   "0. NA" , add
label define V045183f   1   "1. Agree strongly" , add
label define V045183f   2   "2. Agree Somewhat" , add
label define V045183f   3   "3. Neither agree nor disagree" , add
label define V045183f   4   "4. Disagree Somewhat" , add
label define V045183f   5   "5. Disagree strongly" , add
label define V045183f   8   "8. Don't know" , add
label define V045183f   9   "9. Refused" , add
label define V045184f   1   "1. Agree strongly" , add
label define V045184f   2   "2. Agree Somewhat" , add
label define V045184f   3   "3. Neither agree nor disagree" , add
label define V045184f   4   "4. Disagree Somewhat" , add
label define V045184f   5   "5. Disagree strongly" , add
label define V045184f   8   "8. Don't know" , add
label define V045184f   9   "9. Refused" , add
label define V045185f   1   "1. Agree strongly" , add
label define V045185f   2   "2. Agree Somewhat" , add
label define V045185f   3   "3. Neither agree nor disagree" , add
label define V045185f   4   "4. Disagree Somewhat" , add
label define V045185f   5   "5. Disagree strongly" , add
label define V045185f   8   "8. Don't know" , add
label define V045185f   9   "9. Refused" , add
label define V045186f   1   "1. Most people can be trusted" , add
label define V045186f   5   "5. Can't be too careful" , add
label define V045186f   8   "8. Don't know" , add
label define V045186f   9   "9. Refused" , add
label define V045187f   1   "1. Take advantage" , add
label define V045187f   5   "5. Try to be fair" , add
label define V045187f   8   "8. Don't know" , add
label define V045187f   9   "9. Refused" , add
label define V045188f   1   "1. Try to be helpful" , add
label define V045188f   5   "5. Just looking out for themselves" , add
label define V045188f   8   "8. Don't know" , add
label define V045188f   9   "9. Refused" , add
label define V045189f   1   "1. Agree strongly" , add
label define V045189f   2   "2. Agree somewhat" , add
label define V045189f   3   "3. Neither agree nor disagree" , add
label define V045189f   4   "4. Disagree somewhat" , add
label define V045189f   5   "5. Disagree strongly" , add
label define V045189f   8   "8. Don't know" , add
label define V045189f   9   "9. Refused" , add
label define V045190f   1   "1. Agree strongly" , add
label define V045190f   2   "2. Agree somewhat" , add
label define V045190f   3   "3. Neither agree nor disagree" , add
label define V045190f   4   "4. Disagree somewhat" , add
label define V045190f   5   "5. Disagree strongly" , add
label define V045190f   8   "8. Don't know" , add
label define V045190f   9   "9. Refused" , add
label define V045191f   1   "1. Agree strongly" , add
label define V045191f   2   "2. Agree somewhat" , add
label define V045191f   3   "3. Neither agree nor disagree" , add
label define V045191f   4   "4. Disagree somewhat" , add
label define V045191f   5   "5. Disagree strongly" , add
label define V045191f   8   "8. Don't know" , add
label define V045191f   9   "9. Refused" , add
label define V045192f   1   "1. Agree strongly" , add
label define V045192f   2   "2. Agree somewhat" , add
label define V045192f   3   "3. Neither agree nor disagree" , add
label define V045192f   4   "4. Disagree somewhat" , add
label define V045192f   5   "5. Disagree strongly" , add
label define V045192f   8   "8. Don't know" , add
label define V045192f   9   "9. Refused" , add
label define V045193f   1   "1. Agree strongly" , add
label define V045193f   2   "2. Agree somewhat" , add
label define V045193f   3   "3. Neither agree nor disagree" , add
label define V045193f   4   "4. Disagree somewhat" , add
label define V045193f   5   "5. Disagree strongly" , add
label define V045193f   8   "8. Don't know" , add
label define V045193f   9   "9. Refused" , add
label define V045194f   1   "1. Agree strongly" , add
label define V045194f   2   "2. Agree somewhat" , add
label define V045194f   3   "3. Neither agree nor disagree" , add
label define V045194f   4   "4. Disagree somewhat" , add
label define V045194f   5   "5. Disagree strongly" , add
label define V045194f   8   "8. Don't know" , add
label define V045194f   9   "9. Refused" , add
label define V045195f   1   "1. Agree strongly" , add
label define V045195f   2   "2. Agree somewhat" , add
label define V045195f   3   "3. Neither agree nor disagree" , add
label define V045195f   4   "4. Disagree somewhat" , add
label define V045195f   5   "5. Disagree strongly" , add
label define V045195f   8   "8. Don't know" , add
label define V045195f   9   "9. Refused" , add
label define V045196f   1   "1. Agree strongly" , add
label define V045196f   2   "2. Agree somewhat" , add
label define V045196f   3   "3. Neither agree nor disagree" , add
label define V045196f   4   "4. Disagree somewhat" , add
label define V045196f   5   "5. Disagree strongly" , add
label define V045196f   8   "8. Don't know" , add
label define V045196f   9   "9. Refused" , add
label define V045197f   1   "1. Just about always" , add
label define V045197f   2   "2. Most of the time" , add
label define V045197f   3   "3. Only some of the time" , add
label define V045197f   4   "4. Never {VOL}" , add
label define V045197f   8   "8. Don't know" , add
label define V045197f   9   "9. Refused" , add
label define V045198f   1   "1. Gov't run by a few big interests" , add
label define V045198f   5   "5. Gov't run for the benefit of all" , add
label define V045198f   8   "8. Don't know" , add
label define V045198f   9   "9. Refused" , add
label define V045199f   1   "1. Waste a lot" , add
label define V045199f   3   "3. Waste some" , add
label define V045199f   5   "5. Don't waste very much" , add
label define V045199f   8   "8. Don't know" , add
label define V045199f   9   "9. Refused" , add
label define V045200f   1   "1. Quite a few are crooked" , add
label define V045200f   3   "3. Not very many are crooked" , add
label define V045200f   5   "5. Hardly any are crooked" , add
label define V045200f   8   "8. Don't know" , add
label define V045200f   9   "9. Refused" , add
label define V045201f   1   "1. Agree strongly" , add
label define V045201f   2   "2. Agree somewhat" , add
label define V045201f   3   "3. Neither agree nor disagree" , add
label define V045201f   4   "4. Disagree somewhat" , add
label define V045201f   5   "5. Disagree strongly" , add
label define V045201f   8   "8. Don't know" , add
label define V045201f   9   "9. Refused" , add
label define V045202f   1   "1. Agree strongly" , add
label define V045202f   2   "2. Agree somewhat" , add
label define V045202f   3   "3. Neither agree nor disagree" , add
label define V045202f   4   "4. Disagree somewhat" , add
label define V045202f   5   "5. Disagree strongly" , add
label define V045202f   8   "8. Don't know" , add
label define V045202f   9   "9. Refused" , add
label define V045203f   1   "1. A good deal" , add
label define V045203f   3   "3. Some" , add
label define V045203f   5   "5. Not much" , add
label define V045203f   8   "8. Don't know" , add
label define V045203f   9   "9. Refused" , add
label define V045204f   1   "1. A good deal" , add
label define V045204f   3   "3. Some" , add
label define V045204f   5   "5. Not much" , add
label define V045204f   8   "8. Don't know" , add
label define V045204f   9   "9. Refused" , add
label define V045205f   1   "1. Agree" , add
label define V045205f   3   "3. Neither agree nor disagree" , add
label define V045205f   5   "5. Disagree" , add
label define V045205f   8   "8. Don't know" , add
label define V045205f   9   "9. Refused" , add
label define V045206f   1   "1. Agree" , add
label define V045206f   3   "3. Neither agree nor disagree" , add
label define V045206f   5   "5. Disagree" , add
label define V045206f   8   "8. Don't know" , add
label define V045206f   9   "9. Refused" , add
label define V045207f   1   "1. For preferential hiring and promotion of blacks" , add
label define V045207f   5   "5. Against preferential hiring and promotion of blacks" , add
label define V045207f   7   "7. Other {SPECIFY}" , add
label define V045207f   8   "8. Don't know" , add
label define V045207f   9   "9. Refused" , add
label define V045207a   1   "1. Favor strongly" , add
label define V045207a   2   "2. Favor not strongly" , add
label define V045207a   4   "4. Oppose not strongly" , add
label define V045207a   5   "5. Oppose strongly " , add
label define V045207a   8   "8. Don't know" , add
label define V045207a   9   "9. Refused" , add
label define V045208f   1   "1. Independence" , add
label define V045208f   3   "3. Both {VOL}" , add
label define V045208f   5   "5. Respect for elders" , add
label define V045208f   7   "7. Neither {VOL}" , add
label define V045208f   8   "8. Don't know" , add
label define V045208f   9   "9. Refused" , add
label define V045209f   1   "1. Curiosity" , add
label define V045209f   3   "3. Both {VOL}" , add
label define V045209f   5   "5. Good manners" , add
label define V045209f   7   "7. Neither {VOL}" , add
label define V045209f   8   "8. Don't know" , add
label define V045209f   9   "9. Refused" , add
label define V045210f   1   "1. Obedience" , add
label define V045210f   3   "3. Both {VOL}" , add
label define V045210f   5   "5. Self-reliance" , add
label define V045210f   7   "7. Neither {VOL}" , add
label define V045210f   8   "8. Don't know" , add
label define V045210f   9   "9. Refused" , add
label define V045211f   1   "1. Being considerate" , add
label define V045211f   3   "3. Both {VOL}" , add
label define V045211f   5   "5. Well behaved" , add
label define V045211f   7   "7. Neither {VOL}" , add
label define V045211f   8   "8. Don't know" , add
label define V045211f   9   "9. Refused" , add
label define V045212f   1   "1. Agree strongly" , add
label define V045212f   2   "2. Agree somewhat" , add
label define V045212f   3   "3. Neither agree nor disagree" , add
label define V045212f   4   "4. Disagree somewhat" , add
label define V045212f   5   "5. Disagree strongly" , add
label define V045212f   8   "8. Don't know" , add
label define V045212f   9   "9. Refused" , add
label define V045213f   1   "1. Agree strongly" , add
label define V045213f   2   "2. Agree somewhat" , add
label define V045213f   3   "3. Neither agree nor disagree" , add
label define V045213f   4   "4. Disagree somewhat" , add
label define V045213f   5   "5. Disagree strongly" , add
label define V045213f   8   "8. Don't know" , add
label define V045213f   9   "9. Refused" , add
label define V045214f   1   "1. Agree strongly" , add
label define V045214f   2   "2. Agree somewhat" , add
label define V045214f   3   "3. Neither agree nor disagree" , add
label define V045214f   4   "4. Disagree somewhat" , add
label define V045214f   5   "5. Disagree strongly" , add
label define V045214f   8   "8. Don't know" , add
label define V045214f   9   "9. Refused" , add
label define V045215f   1   "1. Agree strongly" , add
label define V045215f   2   "2. Agree somewhat" , add
label define V045215f   3   "3. Neither agree nor disagree" , add
label define V045215f   4   "4. Disagree somewhat" , add
label define V045215f   5   "5. Disagree strongly" , add
label define V045215f   8   "8. Don't know" , add
label define V045215f   9   "9. Refused" , add
label define V045216f   1   "1. Agree strongly" , add
label define V045216f   2   "2. Agree somewhat" , add
label define V045216f   3   "3. Neither agree nor disagree" , add
label define V045216f   4   "4. Disagree somewhat" , add
label define V045216f   5   "5. Disagree strongly" , add
label define V045216f   8   "8. Don't know" , add
label define V045216f   9   "9. Refused" , add
label define V045217f   1   "1. Agree strongly" , add
label define V045217f   2   "2. Agree somewhat" , add
label define V045217f   3   "3. Neither agree nor disagree" , add
label define V045217f   4   "4. Disagree somewhat" , add
label define V045217f   5   "5. Disagree strongly" , add
label define V045217f   8   "8. Don't know" , add
label define V045217f   9   "9. Refused" , add
label define V045218f   1   "1. Almost everything" , add
label define V045218f   2   "2. Many things" , add
label define V045218f   3   "3. Some things" , add
label define V045218f   4   "4. Very few things" , add
label define V045218f   8   "8. Don't know" , add
label define V045218f   9   "9. Refused" , add
label define V045219f   1   "1. Fewer opinions" , add
label define V045219f   3   "3. About the same number of opinions" , add
label define V045219f   5   "5. More opinions" , add
label define V045219f   8   "8. Don't know" , add
label define V045219f   9   "9. Refused" , add
label define V045219a   1   "1. A lot fewer opinions" , add
label define V045219a   2   "2. Somewhat fewer opinions" , add
label define V045219a   3   "3. About the same number of opinions" , add
label define V045219a   4   "4. Somewhat more opinions" , add
label define V045219a   5   "5. A lot more opinions" , add
label define V045219a   8   "8. Don't know" , add
label define V045219a   9   "9. Refused" , add
label define V045220f   1   "1. Like" , add
label define V045220f   3   "3. Dislike" , add
label define V045220f   5   "5. Neither like nor dislike" , add
label define V045220f   8   "8. Don't know" , add
label define V045220f   9   "9. Refused" , add
label define V045220a   1   "1. Like it  lot" , add
label define V045220a   2   "2. Like it somewhat" , add
label define V045220a   3   "3. Neither like nor dislike it" , add
label define V045220a   4   "4. Dislike it somewhat" , add
label define V045220a   5   "5. Dislike it a lot" , add
label define V045220a   8   "8. Don't know" , add
label define V045220a   9   "9. Refused" , add
label define V045221f   1   "1. Simple" , add
label define V045221f   5   "5. Complex" , add
label define V045221f   8   "8. Don't know" , add
label define V045221f   9   "9. Refused" , add
label define V045222f   1   "1. Hard-working" , add
label define V045222f   7   "7. Lazy" , add
label define V045222f   8   "8. Don't know" , add
label define V045222f   9   "9. Refused" , add
label define V045223f   1   "1. Hard-working" , add
label define V045223f   7   "7. Lazy" , add
label define V045223f   8   "8. Don't know" , add
label define V045223f   9   "9. Refused" , add
label define V045224f   1   "1. Hard-working" , add
label define V045224f   7   "7. Lazy" , add
label define V045224f   8   "8. Don't know" , add
label define V045224f   9   "9. Refused" , add
label define V045225f   1   "1. Hard-working" , add
label define V045225f   7   "7. Lazy" , add
label define V045225f   8   "8. Don't know" , add
label define V045225f   9   "9. Refused" , add
label define V045226f   1   "1. Intelligent" , add
label define V045226f   7   "7. Unintelligent" , add
label define V045226f   8   "8. Don't know" , add
label define V045226f   9   "9. Refused" , add
label define V045227f   1   "1. Intelligent" , add
label define V045227f   7   "7. Unintelligent" , add
label define V045227f   8   "8. Don't know" , add
label define V045227f   9   "9. Refused" , add
label define V045228f   1   "1. Intelligent" , add
label define V045228f   7   "7. Unintelligent" , add
label define V045228f   8   "8. Don't know" , add
label define V045228f   9   "9. Refused" , add
label define V045229f   1   "1. Intelligent" , add
label define V045229f   7   "7. Unintelligent" , add
label define V045229f   8   "8. Don't know" , add
label define V045229f   9   "9. Refused" , add
label define V045230f   1   "1. Trustworthy" , add
label define V045230f   7   "7. Untrustworthy" , add
label define V045230f   8   "8. Don't know" , add
label define V045230f   9   "9. Refused" , add
label define V045231f   1   "1. Trustworthy" , add
label define V045231f   7   "7. Untrustworthy" , add
label define V045231f   8   "8. Don't know" , add
label define V045231f   9   "9. Refused" , add
label define V045232f   1   "1. Trustworthy" , add
label define V045232f   7   "7. Untrustworthy" , add
label define V045232f   8   "8. Don't know" , add
label define V045232f   9   "9. Refused" , add
label define V045233f   1   "1. Trustworthy" , add
label define V045233f   7   "7. Untrustworthy" , add
label define V045233f   8   "8. Don't know" , add
label define V045233f   9   "9. Refused" , add
label define V045235f   1   "1. Yes" , add
label define V045235f   5   "5. No" , add
label define V045235f   8   "8. Don't know" , add
label define V045235f   9   "9. Refused" , add
label define V045235a   1   "1. Frequently" , add
label define V045235a   2   "2. Occasionally" , add
label define V045235a   3   "3. Rarely" , add
label define V045235a   8   "8. Don't know" , add
label define V045235a   9   "9. Refused" , add
label define V045236f   1   "1. Yes" , add
label define V045236f   5   "5. No" , add
label define V045236f   8   "8. Don't know" , add
label define V045236f   9   "9. Refused" , add
label define V045236a   1   "1. Frequently" , add
label define V045236a   2   "2. Occasionally" , add
label define V045236a   3   "3. Rarely" , add
label define V045236a   8   "8. Don't know" , add
label define V045236a   9   "9. Refused" , add
label define V045237f   1   "1. Yes" , add
label define V045237f   5   "5. No" , add
label define V045237f   8   "8. Don't know" , add
label define V045237f   9   "9. Refused" , add
label define V045238f   995   "995. 'There were no issues'; 'there were no issues, just" , add
label define V045238f   996   "996. 'There was no campaign in my district'" , add
label define V045238f   998   "998. DK" , add
label define V045238f   999   "999. NA" , add
label define V045238f   000   "000. No problems mentioned" , add
label define V045239f   1   "1. Very good job" , add
label define V045239f   2   "2. Good job" , add
label define V045239f   3   "3. Bad job" , add
label define V045239f   4   "4. Very bad job" , add
label define V045239f   8   "8. Don't know" , add
label define V045239f   9   "9. Refused" , add
label define V045240f   1   "1. Very good job" , add
label define V045240f   2   "2. Good job" , add
label define V045240f   3   "3. Bad job" , add
label define V045240f   4   "4. Very bad job" , add
label define V045240f   8   "8. Don't know" , add
label define V045240f   9   "9. Refused" , add
label define V045241f   1   "1. Very satisfied" , add
label define V045241f   2   "2. Fairly satisfied" , add
label define V045241f   3   "3. Not very satisfied" , add
label define V045241f   4   "4. Not at all satisfied" , add
label define V045241f   8   "8. Don't know" , add
label define V045241f   9   "9. Refused" , add
label define V045242f   1   "1. It makes a difference who is in power" , add
label define V045242f   5   "5. It doesn't make a difference who is in power" , add
label define V045242f   8   "8. Don't know" , add
label define V045242f   9   "9. Refused" , add
label define V045243f   1   "1. Who people vote for won't make a difference" , add
label define V045243f   5   "5. Who people vote for can make a difference" , add
label define V045243f   8   "8. Don't know" , add
label define V045243f   9   "9. Refused" , add
label define V045244f   1   "1. Agree strongly" , add
label define V045244f   2   "2. Agree" , add
label define V045244f   3   "3. Disagree" , add
label define V045244f   4   "4. Disagree strongly" , add
label define V045244f   8   "8. Don't know" , add
label define V045244f   9   "9. Refused" , add
label define V045245f   1   "1. R voted for Democratic presidential candidate" , add
label define V045245f   3   "3. R voted for Republican presidential candidate" , add
label define V045245f   5   "5. R voted for Reform party presidential candidate" , add
label define V045245f   6   "6. R voted for other candidate - party identified" , add
label define V045245f   7   "7. R voted for other candidate - party not identified" , add
label define V045245f   8   "8. Don't know who voted for (8 in C6a)" , add
label define V045245f   9   "9. Refused (9 in C6a)" , add
label define V045246f   1   "1. Very good job" , add
label define V045246f   2   "2. Good job" , add
label define V045246f   3   "3. Bad job" , add
label define V045246f   4   "4. Very bad job" , add
label define V045246f   8   "8. Don't know" , add
label define V045246f   9   "9. Refused" , add
label define V045247f   1   "1. Very well" , add
label define V045247f   2   "2. Quite well" , add
label define V045247f   3   "3. Not very well" , add
label define V045247f   4   "4. Not well at all" , add
label define V045247f   8   "8. Don't know" , add
label define V045247f   9   "9. Refused" , add
label define V045248f   1   "1. Yes" , add
label define V045248f   5   "5. No" , add
label define V045248f   8   "8. Don't know" , add
label define V045248f   9   "9. Refused" , add
label define V045248a   1   "1. Democratic" , add
label define V045248a   5   "5. Republican" , add
label define V045248a   7   "7. Other {SPECIFY}" , add
label define V045248a   8   "8. Don't know" , add
label define V045248a   9   "9. Refused" , add
label define V045249f   1   "1. Yes" , add
label define V045249f   5   "5. No" , add
label define V045249f   8   "8. Don't know" , add
label define V045249f   9   "9. Refused" , add
label define V045249a   1   "1. George W. Bush" , add
label define V045249a   3   "3. John Kerry" , add
label define V045249a   5   "5. Ralph Nader" , add
label define V045249a   7   "7. Other {SPECIFY}" , add
label define V045249a   8   "8. Don't know" , add
label define V045249a   9   "9. Refused" , add
label define V045250f   1   "1. Yes" , add
label define V045250f   5   "5. No" , add
label define V045250f   8   "8. Don't know" , add
label define V045250f   9   "9. Refused" , add
label define V045250a   1   "1. Democratic" , add
label define V045250a   3   "3. Republican" , add
label define V045250a   5   "5. Reform party" , add
label define V045250a   7   "7. Other {SPECIFY}" , add
label define V045250a   8   "8. Don't know" , add
label define V045250a   9   "9. Refused" , add
label define V045250b   1   "1. Democratic" , add
label define V045250b   3   "3. Republican" , add
label define V045250b   5   "5. Reform party" , add
label define V045250b   7   "7. Other {SPECIFY}" , add
label define V045250b   8   "8. Don't know" , add
label define V045250b   9   "9. Refused" , add
label define V045251f   0   "0. No party mentioned as close, or not determined" , add
label define V045251f   1   "1. One party mentioned" , add
label define V045251f   2   "2. Two or more parties mentioned" , add
label define V045251f   8   "8. Interviewer error: no mentions coded as 1 or 2 mentions" , add
label define V045252f   1   "1. Democratic" , add
label define V045252f   5   "5. Republican" , add
label define V045252f   7   "7. Other {SPECIFY}" , add
label define V045252f   8   "8. Don't know" , add
label define V045252f   9   "9. Refused" , add
label define V045253f   1   "1. Yes" , add
label define V045253f   5   "5. No" , add
label define V045253f   8   "8. Don't know" , add
label define V045253f   9   "9. Refused" , add
label define V045253f   0   "0. NA" , add
label define V045253a   1   "1. Democratic" , add
label define V045253a   5   "5. Republican" , add
label define V045253a   7   "7. Other {SPECIFY}" , add
label define V045253a   8   "8. Don't know" , add
label define V045253a   9   "9. Refused" , add
label define V045255f   1   "1. Very close" , add
label define V045255f   2   "2. Somewhat close" , add
label define V045255f   3   "3. Not very close" , add
label define V045255f   8   "8. Don't know" , add
label define V045255f   9   "9. Refused" , add
label define V045257f   00   "00. Strongly dislike" , add
label define V045257f   10   "10. Strongly like" , add
label define V045257f   87   "87. Haven't heard of" , add
label define V045257f   88   "88. Don't know" , add
label define V045257f   89   "89. Refused" , add
label define V045258f   00   "00. Strongly dislike" , add
label define V045258f   10   "10. Strongly like" , add
label define V045258f   87   "87. Haven't heard of" , add
label define V045258f   88   "88. Don't know" , add
label define V045258f   89   "89. Refused" , add
label define V045259f   00   "00. Strongly dislike" , add
label define V045259f   10   "10. Strongly like" , add
label define V045259f   87   "87. Haven't heard of" , add
label define V045259f   88   "88. Don't know" , add
label define V045259f   89   "89. Refused" , add
label define V045260f   00   "00. Left" , add
label define V045260f   10   "10. Right" , add
label define V045260f   87   "87. Haven't heard of" , add
label define V045260f   88   "88. Don't know" , add
label define V045260f   89   "89. Refused" , add
label define V045261f   00   "00. Left" , add
label define V045261f   10   "10. Right" , add
label define V045261f   87   "87. Haven't heard of" , add
label define V045261f   88   "88. Don't know" , add
label define V045261f   89   "89. Refused" , add
label define V045262f   00   "00. Left" , add
label define V045262f   10   "10. Right" , add
label define V045262f   87   "87. Haven't heard of" , add
label define V045262f   88   "88. Don't know" , add
label define V045262f   89   "89. Refused" , add
label define V045263f   00   "00. Left" , add
label define V045263f   10   "10. Right" , add
label define V045263f   87   "87. Haven't heard of" , add
label define V045263f   88   "88. Don't know" , add
label define V045263f   89   "89. Refused" , add
label define V045264f   00   "00. Left" , add
label define V045264f   10   "10. Right" , add
label define V045264f   87   "87. Haven't heard of" , add
label define V045264f   88   "88. Don't know" , add
label define V045264f   89   "89. Refused" , add
label define V045265f   00   "00. Left" , add
label define V045265f   10   "10. Right" , add
label define V045265f   87   "87. Haven't heard of" , add
label define V045265f   88   "88. Don't know" , add
label define V045265f   89   "89. Refused" , add
label define V045266f   1   "1. Yes" , add
label define V045266f   5   "5. No" , add
label define V045266f   8   "8. Don't know" , add
label define V045266f   9   "9. Refused" , add
label define V045267f   1   "1. Yes" , add
label define V045267f   5   "5. No" , add
label define V045267f   8   "8. Don't know" , add
label define V045267f   9   "9. Refused" , add
label define V045268f   1   "1. Yes" , add
label define V045268f   5   "5. No" , add
label define V045268f   8   "8. Don't know" , add
label define V045268f   9   "9. Refused" , add
label define V045269f   1   "1. A lot of respect for individual freedom" , add
label define V045269f   2   "2. Some respect" , add
label define V045269f   3   "3. Not much respect" , add
label define V045269f   4   "4. No respect at all" , add
label define V045269f   8   "8. Don't know" , add
label define V045269f   9   "9. Refused" , add
label define V045270f   1   "1. Very widespread" , add
label define V045270f   2   "2. Quite widespread" , add
label define V045270f   3   "3. Not very widespread" , add
label define V045270f   4   "4. It hardly happens at all" , add
label define V045270f   8   "8. Don't know" , add
label define V045270f   9   "9. Refused" , add
label define V045271f   00   "00. Left" , add
label define V045271f   10   "10. Right" , add
label define V045271f   88   "88. Don't know" , add
label define V045271f   89   "89. Refused" , add
label define V045300a    0   "0. No indication" , add
label define V045300a    1   "1. Indicated" , add
label define V045300b    0   "0. No indication" , add
label define V045300b    1   "1. Indicated" , add
label define V045301a    1   "1. Marked" , add
label define V045301a    5   "5. Not marked" , add
label define V045301a    0   "0. NA" , add
label define V045301b    1   "1. Marked" , add
label define V045301b    5   "5. Not marked" , add
label define V045301b    0   "0. NA" , add
label define V045301c    1   "1. Marked" , add
label define V045301c    5   "5. Not marked" , add
label define V045301c    0   "0. NA" , add
label define V045301d    1   "1. Marked" , add
label define V045301d    5   "5. Not marked" , add
label define V045301d    0   "0. NA" , add
label define V045301e    1   "1. Marked" , add
label define V045301e    5   "5. Not marked" , add
label define V045301e    0   "0. NA" , add
label define V045301f    1   "1. Marked" , add
label define V045301f    5   "5. Not marked" , add
label define V045301f    0   "0. NA" , add
label define V045302f    1   "1. Very good" , add
label define V045302f    2   "2. Good" , add
label define V045302f    3   "3. Fair" , add
label define V045302f    4   "4. Poor" , add
label define V045302f    5   "5. Very poor" , add
label define V045302f    0   "0. NA" , add
label define V045303f    1   "1. Very high" , add
label define V045303f    2   "2. Fairly high" , add
label define V045303f    3   "3. Acerage" , add
label define V045303f    4   "4. Fairly low" , add
label define V045303f    5   "5. Very low" , add
label define V045303f    0   "0. NA" , add
label define V045304f    1   "1. Very high" , add
label define V045304f    2   "2. Fairly high" , add
label define V045304f    3   "3. Acerage" , add
label define V045304f    4   "4. Fairly low" , add
label define V045304f    5   "5. Very low" , add
label define V045304f    0   "0. NA" , add
label define V045305f    1   "1. Not at all suspicious" , add
label define V045305f    2   "2. Somewhat suspicious" , add
label define V045305f    3   "3. Very suspicious" , add
label define V045305f    0   "0. NA" , add
label define V045306f    1   "1. Very high" , add
label define V045306f    2   "2. Fairly high" , add
label define V045306f    3   "3. Average" , add
label define V045306f    4   "4. Fairly low" , add
label define V045306f    5   "5. Very low" , add
label define V045306f    0   "0. NA" , add
label define V045307f    1   "1. Completely sincere" , add
label define V045307f    2   "2. Usually sincere" , add
label define V045307f    3   "3. Often seemed to be insincere" , add
label define V045307f    0   "0. NA" , add
label define V045307a    1   "1. Yes {SPECIFY}" , add
label define V045307a    5   "5. No" , add
label define V045308a    10   "10. Negative - general" , add
label define V045308a    11   "11. Negative - too long" , add
label define V045308a    12   "12. Negative - too complicated" , add
label define V045308a    13   "13. Negative - boring/tedious/repetitious" , add
label define V045308a    15   "15. R wanted to stop before interview completed. After" , add
label define V045308a    20   "20. R complained and/or interviewer observed that R was" , add
label define V045308a    22   "22. R complained and/or interviewer observed that R was" , add
label define V045308a    30   "30. R expressed (especially repeatedly) doubts/apologies/" , add
label define V045308a    31   "31. R expressed (especially repeatedly) doubts/apologies/" , add
label define V045308a    40   "40. R was agitated or stressed by interview PROCESS" , add
label define V045308a    41   "41. R became angry at interview CONTENT" , add
label define V045308a    45   "45. R became concerned about sampling purpose or bias:" , add
label define V045308a    50   "50. R could not read Respondent Booklet" , add
label define V045308a    70   "70. R appeared to enjoy the interview (R was 'cooperative" , add
label define V045308a    80   "80. Neutral or no feedback (1st mention only" , add
label define V045308a    00   "00. NA" , add
label define V045308b    10   "10. Negative - general" , add
label define V045308b    11   "11. Negative - too long" , add
label define V045308b    12   "12. Negative - too complicated" , add
label define V045308b    13   "13. Negative - boring/tedious/repetitious" , add
label define V045308b    15   "15. R wanted to stop before interview completed. After" , add
label define V045308b    20   "20. R complained and/or interviewer observed that R was" , add
label define V045308b    22   "22. R complained and/or interviewer observed that R was" , add
label define V045308b    30   "30. R expressed (especially repeatedly) doubts/apologies/" , add
label define V045308b    31   "31. R expressed (especially repeatedly) doubts/apologies/" , add
label define V045308b    40   "40. R was agitated or stressed by interview PROCESS" , add
label define V045308b    41   "41. R became angry at interview CONTENT" , add
label define V045308b    45   "45. R became concerned about sampling purpose or bias:" , add
label define V045308b    50   "50. R could not read Respondent Booklet" , add
label define V045308b    70   "70. R appeared to enjoy the interview (R was 'cooperative" , add
label define V045308c    10   "10. Negative - general" , add
label define V045308c    11   "11. Negative - too long" , add
label define V045308c    12   "12. Negative - too complicated" , add
label define V045308c    13   "13. Negative - boring/tedious/repetitious" , add
label define V045308c    15   "15. R wanted to stop before interview completed. After" , add
label define V045308c    20   "20. R complained and/or interviewer observed that R was" , add
label define V045308c    22   "22. R complained and/or interviewer observed that R was" , add
label define V045308c    30   "30. R expressed (especially repeatedly) doubts/apologies/" , add
label define V045308c    31   "31. R expressed (especially repeatedly) doubts/apologies/" , add
label define V045308c    40   "40. R was agitated or stressed by interview PROCESS" , add
label define V045308c    41   "41. R became angry at interview CONTENT" , add
label define V045308c    45   "45. R became concerned about sampling purpose or bias:" , add
label define V045308c    50   "50. R could not read Respondent Booklet" , add
label define V045308c    70   "70. R appeared to enjoy the interview (R was 'cooperative" , add
label define V045308d    10   "10. Negative - general" , add
label define V045308d    11   "11. Negative - too long" , add
label define V045308d    12   "12. Negative - too complicated" , add
label define V045308d    13   "13. Negative - boring/tedious/repetitious" , add
label define V045308d    15   "15. R wanted to stop before interview completed. After" , add
label define V045308d    20   "20. R complained and/or interviewer observed that R was" , add
label define V045308d    22   "22. R complained and/or interviewer observed that R was" , add
label define V045308d    30   "30. R expressed (especially repeatedly) doubts/apologies/" , add
label define V045308d    31   "31. R expressed (especially repeatedly) doubts/apologies/" , add
label define V045308d    40   "40. R was agitated or stressed by interview PROCESS" , add
label define V045308d    41   "41. R became angry at interview CONTENT" , add
label define V045308d    45   "45. R became concerned about sampling purpose or bias:" , add
label define V045308d    50   "50. R could not read Respondent Booklet" , add
label define V045308d    70   "70. R appeared to enjoy the interview (R was 'cooperative" , add
label define V045308e    10   "10. Negative - general" , add
label define V045308e    11   "11. Negative - too long" , add
label define V045308e    12   "12. Negative - too complicated" , add
label define V045308e    13   "13. Negative - boring/tedious/repetitious" , add
label define V045308e    15   "15. R wanted to stop before interview completed. After" , add
label define V045308e    20   "20. R complained and/or interviewer observed that R was" , add
label define V045308e    22   "22. R complained and/or interviewer observed that R was" , add
label define V045308e    30   "30. R expressed (especially repeatedly) doubts/apologies/" , add
label define V045308e    31   "31. R expressed (especially repeatedly) doubts/apologies/" , add
label define V045308e    40   "40. R was agitated or stressed by interview PROCESS" , add
label define V045308e    41   "41. R became angry at interview CONTENT" , add
label define V045308e    45   "45. R became concerned about sampling purpose or bias:" , add
label define V045308e    50   "50. R could not read Respondent Booklet" , add
label define V045308e    70   "70. R appeared to enjoy the interview (R was 'cooperative" , add
label define V045308f    10   "10. Negative - general" , add
label define V045308f    11   "11. Negative - too long" , add
label define V045308f    12   "12. Negative - too complicated" , add
label define V045308f    13   "13. Negative - boring/tedious/repetitious" , add
label define V045308f    15   "15. R wanted to stop before interview completed. After" , add
label define V045308f    20   "20. R complained and/or interviewer observed that R was" , add
label define V045308f    22   "22. R complained and/or interviewer observed that R was" , add
label define V045308f    30   "30. R expressed (especially repeatedly) doubts/apologies/" , add
label define V045308f    31   "31. R expressed (especially repeatedly) doubts/apologies/" , add
label define V045308f    40   "40. R was agitated or stressed by interview PROCESS" , add
label define V045308f    41   "41. R became angry at interview CONTENT" , add
label define V045308f    45   "45. R became concerned about sampling purpose or bias:" , add
label define V045308f    50   "50. R could not read Respondent Booklet" , add
label define V045308f    70   "70. R appeared to enjoy the interview (R was 'cooperative" , add
label define V045308g    10   "10. Negative - general" , add
label define V045308g    11   "11. Negative - too long" , add
label define V045308g    12   "12. Negative - too complicated" , add
label define V045308g    13   "13. Negative - boring/tedious/repetitious" , add
label define V045308g    15   "15. R wanted to stop before interview completed. After" , add
label define V045308g    20   "20. R complained and/or interviewer observed that R was" , add
label define V045308g    22   "22. R complained and/or interviewer observed that R was" , add
label define V045308g    30   "30. R expressed (especially repeatedly) doubts/apologies/" , add
label define V045308g    31   "31. R expressed (especially repeatedly) doubts/apologies/" , add
label define V045308g    40   "40. R was agitated or stressed by interview PROCESS" , add
label define V045308g    41   "41. R became angry at interview CONTENT" , add
label define V045308g    45   "45. R became concerned about sampling purpose or bias:" , add
label define V045308g    50   "50. R could not read Respondent Booklet" , add
label define V045308g    70   "70. R appeared to enjoy the interview (R was 'cooperative"